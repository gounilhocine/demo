package com.indezer.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MonthStatsModel {

	private String month;

	private Double prodSize;

	private Double testSize;

	public MonthStatsModel(String month, Double prodSize, Double testSize) {
		super();
		this.month = month;
		this.prodSize = prodSize;
		this.testSize = testSize;
	}
}
