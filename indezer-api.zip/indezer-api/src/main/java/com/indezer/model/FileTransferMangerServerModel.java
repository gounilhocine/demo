package com.indezer.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class FileTransferMangerServerModel implements Serializable {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	private String inAddressServer;

	@NotNull
	private String inSystem;

	@NotNull
	private String outSystem;

	@NotNull
	private String inPortServer;

	@NotNull
	private String inDirecorylServer;

	@NotNull
	private String inUserNameServer;

	@NotNull
	private String inPasswordServer;

	@NotNull
	private String outAddressServer;

	@NotNull
	private String outPortServer;

	@NotNull
	private String outDirecorylServer;

	@NotNull
	private String outUserNameServer;

	@NotNull
	private String outPasswordServer;

	@NotNull
	private String protocol;

	@NotNull
	private String pattern;

	@NotNull
	private Boolean keepCopy;
}
