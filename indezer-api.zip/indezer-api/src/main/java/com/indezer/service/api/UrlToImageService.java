package com.indezer.service.api;

import java.io.File;
import java.time.Instant;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.indezer.api.url.ChromeDriverTools;
import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerEnum.Environment;
import com.indezer.util.IndezerImageUtils;
import com.indezer.util.IndezerMap;
import com.indezer.util.IndezerUtil;

@Service
public class UrlToImageService extends AbstractService {

	@Value("${chrome.driver.path.file}")
	private static String chromeDriverFile;

	@Value("${url.to.image.files.folder}")
	private String urlToImageFiles;

	@Value("${draft.image}")
	private String draftImage;

	public File convertUtlToImage(String pageUrl, String outputFileName, IndezerMap<String, String> options, User user,
			StopWatch watch, String docKey, boolean test) throws Exception {

		ChromeDriverTools.url2Image(pageUrl, outputFileName, options, chromeDriverFile);

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setOperationType(IndezerEnum.OperationType.URL_IMG);
		doc.setDocName(outputFileName);
		doc.setDocKey(docKey);
		doc.setDeleted(false);
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(new File(outputFileName)));
		doc.setDocType(IndezerConstant.IMAGE);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(outputFileName));
		doc.setUser(user);
		user.getAddDocument(doc);
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkImage(outputFileName, draftImage);
			doc.setEnvironment(Environment.TEST);
		} else {
			doc.setEnvironment(Environment.PROD);
			Double credit = user.getCredit();
			if (credit - IndezerUtil.getFileSizeKiloBytes(new File(outputFileName)) <= 0f) {
				user.setCredit(0d);
			} else {
				user.setCredit(IndezerUtil.roundDouble("#.####",
						credit - IndezerUtil.getFileSizeKiloBytes(new File(outputFileName))));
			}
		}
		saveUser(user);
		return new File(outputFileName);
	}
}
