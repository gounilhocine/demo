package com.indezer.service.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.docx4j.jaxb.XPathBinderAssociationIsPartialException;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.indezer.api.Converter;
import com.indezer.api.doc.AutoCadToPDFConverter;
import com.indezer.api.doc.DocToPDFConverter;
import com.indezer.api.doc.DocxToPDFConverter;
import com.indezer.api.doc.OdtToPDFConverter;
import com.indezer.api.doc.PptToPDFConverter;
import com.indezer.api.doc.PptxToPDFConverter;
import com.indezer.api.doc.PubToPDFConverter;
import com.indezer.api.doc.TxtToPDFConverter;
import com.indezer.api.doc.XlsToPDFConverter;
import com.indezer.api.doc.XlsxToPDFConverter;
import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerEnum.DocFileType;
import com.indezer.util.IndezerEnum.Environment;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerImageUtils;
import com.indezer.util.IndezerUtil;

@Service
public class DocConverterService extends AbstractService {

	@Value("${doc.to.pdf.files.folder}")
	private String docToPdfFiles;

	@Value("${draft.pdf}")
	private String draftPdf;

	@Value("${draft.image}")
	private String draftImage;

	@Value("${draft.doc}")
	private String draftDoc;

	/**
	 * @param file
	 * @param fileUrls
	 * @param pdfFileName
	 * @param returnType
	 * @return @throws IOException @throws
	 */
	public File docToPdf(String docFileUrl, File fileTemp, String pdfFileName, String docFileType, String docKey,
			User user, StopWatch watch, Boolean test, String returnType) throws Exception {
		IndezerUtil.createFolder(docToPdfFiles.concat(user.getDirectory()));
		String outputFileName = docToPdfFiles.concat(user.getDirectory().concat(File.separator).concat(pdfFileName));
		String docFile = docToPdfFiles.concat(user.getDirectory().concat(File.separator)
				.concat(pdfFileName.substring(0, pdfFileName.length() - 4)).concat("." + docFileType));
		saveFileFromUrlWithJavaIO(docFile, docFileUrl, fileTemp);
		String outputFileTemp = docToPdfFiles
				.concat(user.getDirectory().concat(File.separator).concat("temp_" + pdfFileName));
		InputStream in = new FileInputStream(fileTemp);
		OutputStream out = new FileOutputStream(outputFileTemp);
		Converter converter = null;
		if (DocFileType.DOC.toString().contentEquals(docFileType)) {
			converter = new DocToPDFConverter(in, out, true, true);
		} else if (DocFileType.DOCX.toString().contentEquals(docFileType)) {
			converter = new DocxToPDFConverter(in, out, true, true);
		} else if (DocFileType.PPT.toString().contentEquals(docFileType)) {
			converter = new PptToPDFConverter(in, out, true, true);
		} else if (DocFileType.PPTX.toString().contentEquals(docFileType)) {
			converter = new PptxToPDFConverter(in, out, true, true);
		} else if (DocFileType.ODT.toString().contentEquals(docFileType)) {
			converter = new OdtToPDFConverter(in, out, true, true);
		} else if (DocFileType.XLS.toString().contentEquals(docFileType)) {
			converter = new XlsToPDFConverter(docFile, outputFileTemp, true, true);
		} else if (DocFileType.XLSX.toString().contentEquals(docFileType)) {
			converter = new XlsxToPDFConverter(docFile, outputFileTemp, true, true);
		} else if (DocFileType.TXT.toString().contentEquals(docFileType)) {
			converter = new TxtToPDFConverter(docFile, outputFileTemp, true, true);
		} else if (DocFileType.PUB.toString().contentEquals(docFileType)) {
			converter = new PubToPDFConverter(docFile, outputFileTemp, true, true);
		} else if (DocFileType.DWG.toString().contentEquals(docFileType)) {
			converter = new AutoCadToPDFConverter(docFile, outputFileTemp, true, true);
		} else if (DocFileType.DXF.toString().contentEquals(docFileType)) {
			converter = new AutoCadToPDFConverter(docFile, outputFileTemp, true, true);
		} else {
			converter = new AutoCadToPDFConverter(docFile, outputFileTemp, true, true);
		}
		converter.convert();
		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setOrigineDoc(docFileType);
		doc.setOperationType(IndezerEnum.OperationType.DOC_PDF);
		doc.setDocKey(docKey);
		doc.setZipFile(false);
		doc.setEncrypt(false);
		doc.setSendByEmail(false);
		doc.setDeleted(false);
		doc.setDocType(IndezerConstant.PDF);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(pdfFileName));
		doc.setUser(user);

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkPdf(outputFileTemp, outputFileName, draftPdf);
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, new File(outputFileName));
		} else { // If prod
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, new File(outputFileName));
		}
		File fout = new File(outputFileName);
		fout = processingFile(pdfFileName, user, fout, doc);
		doc.setDocName(fout.getPath());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(fout));
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		user.getAddDocument(doc);
		saveUser(user);
		// Delete Temp files
		new File(outputFileTemp).delete();
		new File(docFile).delete();
		if (fileTemp != null) {
			fileTemp.delete();
		}
		return fout;
	}

	/**
	 * Merge Docs.
	 * 
	 * @param inputDocs
	 * @param fileTemp
	 * @param docFileName
	 * @param docKey
	 * @param ext
	 * @param user
	 * @param watch
	 * @param test
	 * @param returnType
	 * @return
	 * @throws Exception
	 */
	public File mergeDocs(String[] inputDocs, File fileTemp, String docFileName, String docKey, String ext, User user,
			StopWatch watch, Boolean test, String returnType) throws Exception {
		IndezerUtil.createFolder(docToPdfFiles.concat(user.getDirectory()));
		String outputFileName = docToPdfFiles.concat(user.getDirectory().concat(File.separator).concat(docFileName));
		String docFile = docToPdfFiles.concat(user.getDirectory().concat(File.separator)
				.concat(docFileName.substring(0, docFileName.length() - 4)).concat("." + ext));
		String outputFileTemp = docToPdfFiles
				.concat(user.getDirectory().concat(File.separator).concat("temp_" + docFile));

		// merge files
		File firstDoc = new File(docToPdfFiles.concat(user.getDirectory().concat(File.separator).concat(inputDocs[0])));
		WordprocessingMLPackage w = WordprocessingMLPackage.load(firstDoc);

		// Add other docs
		for (String f : inputDocs) {
			appendDocFile(w, new File(docToPdfFiles.concat(user.getDirectory().concat(File.separator).concat(f))));
		}
		File saved = new File(outputFileTemp);
		w.save(saved);

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setUpdatedAt(Instant.now());
		doc.setOrigineDoc(ext.toUpperCase());
		doc.setOperationType(IndezerEnum.OperationType.MERGE_DOCS);
		doc.setDocKey(docKey);
		doc.setZipFile(false);
		doc.setEncrypt(false);
		doc.setSendByEmail(false);
		doc.setDeleted(false);
		doc.setDocType(ext.toUpperCase());
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(docFile));
		doc.setUser(user);

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkPdf(outputFileTemp, outputFileName, draftDoc);
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, new File(outputFileName));
		} else { // If prod
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, new File(outputFileName));
		}
		File fout = new File(outputFileName);
		fout = processingFile(docFile, user, fout, doc);
		doc.setDocName(fout.getPath());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(fout));
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		user.getAddDocument(doc);
		saveUser(user);
		// Delete Temp files
		new File(outputFileTemp).delete();
		new File(docFile).delete();
		if (fileTemp != null) {
			fileTemp.delete();
		}
		return fout;
	}

	/**
	 * Append Doc File.
	 * 
	 * @param firstDoc
	 * @param second
	 * @throws JAXBException
	 * @throws XPathBinderAssociationIsPartialException
	 * @throws Docx4JException
	 */
	private void appendDocFile(WordprocessingMLPackage firstDoc, File second)
			throws JAXBException, XPathBinderAssociationIsPartialException, Docx4JException {
		List<Object> body = WordprocessingMLPackage.load(second).getMainDocumentPart().getJAXBNodesViaXPath("//w:body",
				false);
		for (Object b : body) {
			List<Object> filhos = ((org.docx4j.wml.Body) b).getContent();
			for (Object k : filhos)
				firstDoc.getMainDocumentPart().addObject(k);
		}
	}

	/**
	 * @param docFileUrl
	 * @param fileTemp
	 * @param docFileName
	 * @param upperCase
	 * @param docKey
	 * @param user
	 * @param watch
	 * @param test
	 * @param returnType
	 * @return
	 * @throws Exception
	 */
	public File splitDoc(String docFileUrl, File fileTemp, String zipFileName, String extention, String pages,
			String docKey, User user, StopWatch watch, Boolean test, String returnType) throws Exception {
		IndezerUtil.createFolder(docToPdfFiles.concat(user.getDirectory()));
		String outputFileName = docToPdfFiles.concat(user.getDirectory().concat(File.separator).concat(zipFileName));
		String docFile = docToPdfFiles.concat(user.getDirectory().concat(File.separator)
				.concat(docFileUrl.substring(0, zipFileName.length() - 4)).concat(".zip"));
		saveFileFromUrlWithJavaIO(docFile, docFileUrl, fileTemp);
		String outputFileTemp = docToPdfFiles
				.concat(user.getDirectory().concat(File.separator).concat("temp_" + zipFileName));

		List<File> splittedFiles = IndezerUtil.splitFiles(docFileUrl, pages);

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setOrigineDoc(extention);
		doc.setOperationType(IndezerEnum.OperationType.SPLIT_DOC);
		doc.setDocKey(docKey);
		doc.setZipFile(false);
		doc.setEncrypt(false);
		doc.setSendByEmail(false);
		doc.setDeleted(false);
		doc.setDocType(extention);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(zipFileName));
		doc.setUser(user);

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkPdf(outputFileTemp, outputFileName, draftDoc);
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, new File(outputFileName));
		} else { // If prod
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, new File(outputFileName));
		}
		File fout = new File(outputFileName);
		fout = processingFile(zipFileName, user, fout, doc);
		doc.setDocName(fout.getPath());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(fout));
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		user.getAddDocument(doc);
		saveUser(user);
		// Delete Temp files
		new File(outputFileTemp).delete();
		new File(docFile).delete();
		if (fileTemp != null) {
			fileTemp.delete();
		}
		return fout;
	}
}
