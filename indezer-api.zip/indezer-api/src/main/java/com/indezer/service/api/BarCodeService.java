package com.indezer.service.api;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.krysalis.barcode4j.HumanReadablePlacement;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoder;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoderRegistry;
import org.krysalis.barcode4j.tools.UnitConv;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerEnum.Environment;
import com.indezer.util.IndezerUtil;

@Service
public class BarCodeService extends AbstractService {

	@Value("${barcode.files.folder}")
	private String barCodeFiles;

	/**
	 * @param barcodeType
	 * @param test
	 * @param code
	 * @param height
	 * @param dpi
	 * @param fontSize
	 * @param imageName
	 * @param encode
	 * @param textPosition
	 * @param docKey
	 * @param user
	 * @param watch
	 * @return
	 * @throws Exception
	 */
	public File create(String barcodeType, boolean test, String code, Double height, Double width, int dpi,
			Double fontSize, String imageName, String textPosition, String docKey, User user, StopWatch watch)
			throws Exception {

		AbstractBarcodeBean bean = getEncoderBean(barcodeType);

		bean.setBarHeight(height);
		bean.setFontName(Font.MONOSPACED);
		bean.setFontSize(fontSize);

		// final int dpi = 120;
		// Configure the barcode generator
		bean.setModuleWidth(UnitConv.in2mm(1.0f / dpi)); // makes the narrow bar
		bean.doQuietZone(false);

		if (StringUtils.isNotBlank(textPosition)) {
			if (StringUtils.equalsAnyIgnoreCase(textPosition, "HRP_BOTTOM")) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_BOTTOM);
			} else if (StringUtils.equalsAnyIgnoreCase(textPosition, "HRP_TOP")) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_TOP);
			} else if (StringUtils.equalsAnyIgnoreCase(textPosition, "HRP_NONE")) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_NONE);
			}
		} else {
			bean.setMsgPosition(HumanReadablePlacement.HRP_NONE);
		}
		bean.setModuleWidth(width);
		// bean.setBarHeight(20.0);
		// bean.setFontSize(5.0);
		bean.setQuietZone(10.0);
		// bean.setChecksumMode(ChecksumMode.CP_ADD);
		// bean.doQuietZone(true);
		// Open output file
		IndezerUtil.createFolder(barCodeFiles.concat(user.getDirectory()));
		File outputFile = new File(barCodeFiles.concat(user.getDirectory().concat(File.separator).concat(imageName)));
		OutputStream out = new FileOutputStream(outputFile);
		// Set up the canvas provider for monochrome JPEG output
		BitmapCanvasProvider canvas = new BitmapCanvasProvider(out, "image/png", dpi, BufferedImage.TYPE_BYTE_BINARY,
				false, 0);

		bean.doQuietZone(false);

		// bean.calcDimensions("message");
		// Generate the barcode
		bean.generateBarcode(canvas, code);
		// Signal end of generation
		canvas.finish();
		out.close();

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setUpdatedAt(Instant.now());
		doc.setOperationType(IndezerEnum.OperationType.BAR_CODE);
		doc.setDocName(imageName);
		doc.setDocKey(docKey);
		doc.setDeleted(false);
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(outputFile));
		doc.setDocType(IndezerConstant.IMAGE_PNG);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(imageName));
		doc.setUser(user);
		user.getAddDocument(doc);
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));

		// If test
		if (test) {
			// Get generated bitmap
			BufferedImage symbol = canvas.getBufferedImage();

			String[] paramArr = new String[] { "www.indezer.com" };
			int fSize = 20; // pixels
			int lineHeight = (int) (fontSize * 1.2);
			Font font = new Font("Arial", Font.PLAIN, fSize);
			int w = symbol.getWidth();
			int h = symbol.getHeight();
			FontRenderContext frc = new FontRenderContext(new AffineTransform(), false, true);
			for (int i = 0; i < paramArr.length; i++) {
				String line = paramArr[i];
				Rectangle2D bounds = font.getStringBounds(line, frc);
				w = (int) Math.ceil(Math.max(w, bounds.getWidth()));
				h += lineHeight;
			}

			// Add padding
			int padding = 20;
			w += 2 * padding;
			h += 3 * padding;

			BufferedImage bitmap = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_BINARY);
			Graphics2D g2d = (Graphics2D) bitmap.getGraphics();
			g2d.setBackground(Color.white);
			g2d.setColor(Color.RED);
			g2d.clearRect(0, 0, bitmap.getWidth(), bitmap.getHeight());
			g2d.setFont(font);

			// Place the barcode symbol
			AffineTransform symbolPlacement = new AffineTransform();
			symbolPlacement.translate(padding, padding);
			g2d.drawRenderedImage(symbol, symbolPlacement);

			// Add text lines (or anything else you might want to add)
			int y = padding + symbol.getHeight() + padding + 15;
			for (int i = 0; i < paramArr.length; i++) {
				String line = paramArr[i];
				y += lineHeight;
				g2d.drawString(line, padding + 20, y);
			}
			g2d.dispose();

			// Encode bitmap as file
			String mime = "image/png";
			OutputStream out2 = new FileOutputStream(outputFile);
			try {
				final BitmapEncoder encoder = BitmapEncoderRegistry.getInstance(mime);
				encoder.encode(bitmap, out2, mime, dpi);
			} finally {
				out2.close();
			}
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, outputFile);
		} else {
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, outputFile);
		}
		saveUser(user);
		return outputFile;
	}




	

	/**
	 * @param barcodeType
	 * @param test
	 * @param codes
	 * @param height
	 * @param dpi
	 * @param fontSize
	 * @param imageName
	 * @param encode
	 * @param textPosition
	 * @param docKey
	 * @param user
	 * @param watch
	 * @return
	 * @throws Exception
	 */
	public File creates(String barcodeType, boolean test, String codes, Double height, Double width, int dpi,
			Double fontSize, String imageName, Boolean encode, String textPosition, String docKey, User user,
			StopWatch watch) throws Exception {

		File imageCode = null;
		String[] codeList = codes.split(",");
		if (codeList.length == 1) {
			imageCode = create(barcodeType, test, codes, height, width, dpi, fontSize, imageName, textPosition, docKey,
					user, watch);
		} else {
			for (String code : codeList) {
				imageCode = create(barcodeType, test, code, height, width, dpi, fontSize, imageName, textPosition,
						docKey, user, watch);
			}
		}
		return imageCode;
	}

}
