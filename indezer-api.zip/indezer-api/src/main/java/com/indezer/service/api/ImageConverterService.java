package com.indezer.service.api;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.time.Instant;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.commons.lang3.StringUtils;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoder;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoderRegistry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerEnum.Environment;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerImageUtils;
import com.indezer.util.IndezerUtil;

@Service
public class ImageConverterService extends AbstractService {

	@Value("${image.converter.files.folder}")
	private String imageConverterFiles;

	
	/**
	 * @param inputPdfFile
	 * @param zipFileName
	 * @param docKey
	 * @param user
	 * @param watch
	 * @param test
	 * @param returnType
	 * @return
	 * @throws Exception
	 */
	public File pdfToImage(File inputPdfFile, String zipFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) throws Exception {
		String dir = getStaticFolderPath(user);
		String zipFilePath = dir.concat(File.separator).concat(zipFileName);
		File zipOutputFile = IndezerImageUtils.generateImagesFromPdf(inputPdfFile, dir, zipFilePath, test, watermark);

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setUpdatedAt(Instant.now());
		doc.setOrigineDoc(IndezerConstant.PDF);
		doc.setOperationType(IndezerEnum.OperationType.SPLIT_PDF);
		doc.setDocKey(docKey);
		doc.setZipFile(false);
		doc.setEncrypt(false);
		doc.setSendByEmail(false);
		doc.setDeleted(false);
		doc.setDocType(IndezerConstant.PDF);
		doc.setExpirationDate(new Date());
		doc.setUser(user);

		// If test
		if (test) {
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, zipOutputFile);
		} else { // If prod
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, zipOutputFile);
		}
		File fout = new File(zipFilePath);
		fout = processingFile(zipOutputFile.getName(), user, fout, doc);
		doc.setDocName(zipOutputFile.getName());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(zipOutputFile));
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(zipFileName));
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		user.getAddDocument(doc);
		saveUser(user);
		return fout;
	}

	
	/**
	 * @param imageUrl
	 * @param destinationFile
	 * @throws IOException
	 * @throws Exception
	 */
	public File convertImage(String imageUrl, String imageName, String extenssion, String docKey, int width, int height,
			User user, StopWatch watch, boolean test) throws Exception {
		InputStream connection;
		BufferedImage bufferedimage = null;
		URL url = new URL(imageUrl);
		if (imageUrl.indexOf("https://") != -1) {
			final SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, getTrustingManager(), new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			connection = url.openStream();
		} else {
			connection = url.openStream();
		}
		bufferedimage = ImageIO.read(connection);
//		if (width == 0) {
//			width = bufferedimage.getWidth();
//		}
//		if (height == 0) {
//			height = bufferedimage.getHeight();
//		}

		IndezerUtil.createFolder(imageConverterFiles.concat(user.getDirectory()));
		File outputFile = new File(
				imageConverterFiles.concat(user.getDirectory().concat(File.separator).concat(imageName)));
		ImageIO.write(bufferedimage, extenssion.toUpperCase(), outputFile);

		// resize
		if (width > 0 && height > 0) {
			IndezerImageUtils.resize(outputFile.toString(), outputFile.toString(), extenssion, width, height);
		}

		if (outputFile.exists()) {
			// save doc
			Document doc = new Document();
			doc.setCreatedAt(Instant.now());
			doc.setOperationType(IndezerEnum.OperationType.IMG_IMG);
			doc.setDocName(imageName);
			doc.setDocKey(docKey);
			doc.setDeleted(false);
			doc.setSize(IndezerUtil.getFileSizeMegaBytes(outputFile));
			doc.setDocType(extenssion.toUpperCase());
			doc.setExpirationDate(new Date());
			doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(imageName));
			doc.setUser(user);
			user.getAddDocument(doc);
			watch.stop();
			doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));

			// If test
			if (test) {
				// Get generated bitmap
				String[] paramArr = new String[] { "www.indezer.com" };
				int fSize = 20; // pixels
				Double fontSize = 18.0;
				int lineHeight = (int) (fontSize * 1.2);
				Font font = new Font("Arial", Font.PLAIN, fSize);
				int w = bufferedimage.getWidth();
				int h = bufferedimage.getHeight();
				FontRenderContext frc = new FontRenderContext(new AffineTransform(), false, true);
				for (int i = 0; i < paramArr.length; i++) {
					String line = paramArr[i];
					Rectangle2D bounds = font.getStringBounds(line, frc);
					w = (int) Math.ceil(Math.max(w, bounds.getWidth()));
					h += lineHeight;
				}

				// Add padding
				int padding = 20;
				w += 2 * padding;
				h += 3 * padding;

				BufferedImage bitmap = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_BINARY);
				Graphics2D g2d = (Graphics2D) bitmap.getGraphics();
				g2d.setBackground(Color.white);
				g2d.setColor(Color.RED);
				g2d.clearRect(0, 0, bitmap.getWidth(), bitmap.getHeight());
				g2d.setFont(font);

				// Place the barcode symbol
				AffineTransform symbolPlacement = new AffineTransform();
				symbolPlacement.translate(padding, padding);
				g2d.drawRenderedImage(bufferedimage, symbolPlacement);

				// Add text lines (or anything else you might want to add)
				int y = padding + bufferedimage.getHeight() + padding + 15;
				for (int i = 0; i < paramArr.length; i++) {
					String line = paramArr[i];
					y += lineHeight;
					g2d.drawString(line, padding + 20, y);
				}
				g2d.dispose();

				// Encode bitmap as file
				String mime = "image/" + extenssion;
				OutputStream out2 = new FileOutputStream(outputFile);
				try {
					final BitmapEncoder encoder = BitmapEncoderRegistry.getInstance(mime);
					int dpi = 120;
					encoder.encode(bitmap, out2, mime, dpi);
				} finally {
					out2.close();
				}
				doc.setEnvironment(Environment.TEST);
			} else {
				doc.setEnvironment(Environment.PROD);
				Double credit = user.getCredit();
				if (credit - IndezerUtil.getFileSizeKiloBytes(outputFile) <= 0f) {
					user.setCredit(0d);
				} else {
					user.setCredit(
							IndezerUtil.roundDouble("#.####", credit - IndezerUtil.getFileSizeKiloBytes(outputFile)));
				}
			}
			saveUser(user);
		}
		return outputFile;
	}
}
