package com.indezer.service.api;

import java.awt.image.BufferedImage;
import java.io.File;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerEnum.Environment;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerImageUtils;
import com.indezer.util.IndezerMap;
import com.indezer.util.IndezerUtil;

@Service
public class PdfConverterService extends AbstractService {

	/**
	 * Merge PDF Files.
	 * 
	 * @param fileUrls
	 * @param pdfFileName
	 * @param watch
	 * @param user
	 * @param docKey
	 * @return
	 * @throws Exception
	 */
	public File mergePdfs(List<File> fileTemps, String pdfFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) throws Exception {
		// Files
		List<File> files = new ArrayList<File>();

		// Directory
		String dir = getStaticFolderPath(user);
		String pdfFile = dir.concat(File.separator).concat(pdfFileName);

		// Merge Files
		PDFMergerUtility pdfMerger = new PDFMergerUtility();
		pdfMerger.setDestinationFileName(pdfFile);
		for (File f : files) {
			pdfMerger.addSource(f);
		}
		pdfMerger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());

		String outputFileTemp = dir.concat(File.separator).concat("temp_" + pdfFileName);
		File outputFile = new File(outputFileTemp);
		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setOperationType(IndezerEnum.OperationType.MERGE_PDF);
		doc.setDocKey(docKey);
		doc.setDeleted(false);
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(outputFile));
		doc.setDocType(IndezerConstant.PDF);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(pdfFileName));
		doc.setUser(user);
		File fout = new File(outputFileTemp);
		fout = processingFile(pdfFileName, user, fout, doc);
		doc.setDocName(fout.getPath());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(fout));
		user.getAddDocument(doc);

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkPdf(outputFileTemp, pdfFileName, watermark);
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, new File(pdfFileName));
		} else {
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, new File(pdfFileName));
		}
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		saveUser(user);

		// Delete pdfs
		for (File f : files) {
			if (f.exists())
				f.delete();
		}
		new File(outputFileTemp).delete();
		return new File(pdfFileName);
	}

	/**
	 * Split PDF file.
	 * 
	 * @param inputTempPdfFile
	 * @param zipFileName
	 * @param upperCase
	 * @param pages
	 * @param docKey
	 * @param user
	 * @param watch
	 * @param test
	 * @param returnType
	 * @return
	 * @throws Exception
	 */
	public File splitPdf(File inputTempPdfFile, String zipFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) throws Exception {

		String dir = getStaticFolderPath(user);

		List<File> outputTempFiles = new ArrayList<>();
		List<File> outputFiles = new ArrayList<>();

		// Loading an existing PDF document
		PDDocument document = PDDocument.load(inputTempPdfFile);

		// Instantiating Splitter class
		Splitter splitter = new Splitter();

		// splitting the pages of a PDF document
		List<PDDocument> Pages = splitter.split(document);

		// Creating an iterator
		Iterator<PDDocument> iterator = Pages.listIterator();

		// Saving each page as an individual document
		int i = 1;
		while (iterator.hasNext()) {
			PDDocument pd = iterator.next();
			String fileName = zipFileName.concat("_") + i + ".pdf";
			outputTempFiles.add(new File(dir.concat(File.separator).concat(fileName)));
			pd.save(dir.concat(File.separator).concat(fileName));
		}
		System.out.println("Multiple PDF’s created");
		document.close();

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setUpdatedAt(Instant.now());
		doc.setOrigineDoc(IndezerConstant.PDF);
		doc.setOperationType(IndezerEnum.OperationType.SPLIT_PDF);
		doc.setDocKey(docKey);
		doc.setZipFile(false);
		doc.setEncrypt(false);
		doc.setSendByEmail(false);
		doc.setDeleted(false);
		doc.setDocType(IndezerConstant.PDF);
		doc.setExpirationDate(new Date());
		doc.setUser(user);

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkPdf(outputTempFiles, outputFiles, watermark);
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, outputTempFiles);
		} else { // If prod
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, outputTempFiles);
		}
		File fout = new File(dir.concat(File.separator).concat(zipFileName));
		// fout = processingFile(outputFiles, user, fout, doc);
		doc.setDocName(fout.getPath());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(fout));
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(zipFileName));
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		user.getAddDocument(doc);
		saveUser(user);
		// Delete Temp files
		outputTempFiles.forEach(f -> {
			f.deleteOnExit();
		});
		return fout;
	}

	/**
	 * @param fileTemps
	 * @param docKey
	 * @param user
	 * @param watch
	 * @param options
	 * @param test
	 * @return
	 */
	public File comparePdfs(List<File> fileTemps, String docKey, User user, StopWatch watch,
			IndezerMap<String, String> options, Boolean test) {
		// TODO Auto-generated method stub
		return null;
	}

	public File pdfToDoc(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch, Boolean test,
			String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

	public File pdfToHtml(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param inputPdfFile
	 * @param docFileName
	 * @param docKey
	 * @param user
	 * @param watch
	 * @param test
	 * @param returnType
	 * @return
	 */
	public File pdfToImage(File inputTempPdfFile, String zipFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) throws Exception {

		String dir = getStaticFolderPath(user);

		List<File> outputTempFiles = new ArrayList<>();
		List<File> outputFiles = new ArrayList<>();

		PDDocument document = PDDocument.load(inputTempPdfFile);
		PDFRenderer pdfRenderer = new PDFRenderer(document);
		for (int page = 0; page < document.getNumberOfPages(); ++page) {
			BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);
			String fileName = zipFileName.concat("_") + page + 1 + "." + IndezerConstant.PNG;
			ImageIOUtil.writeImage(bim, String.format(fileName), 300);
			outputTempFiles.add(new File(dir.concat(File.separator).concat(fileName)));
		}
		document.close();
		System.out.println("PDF is converted");

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setUpdatedAt(Instant.now());
		doc.setOrigineDoc(IndezerConstant.PDF);
		doc.setOperationType(IndezerEnum.OperationType.PDF_IMAGE);
		doc.setDocKey(docKey);
		doc.setZipFile(false);
		doc.setEncrypt(false);
		doc.setSendByEmail(false);
		doc.setDeleted(false);
		doc.setDocType(IndezerConstant.IMAGE);
		doc.setExpirationDate(new Date());
		doc.setUser(user);

		// If test
		if (test) {
			IndezerImageUtils.addImageWatermarkPdf(outputTempFiles, outputFiles, watermark);
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, outputTempFiles);
		} else { // If prod
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, outputTempFiles);
		}
		File fout = new File(dir.concat(File.separator).concat(zipFileName));
		// fout = processingFile(outputFiles, user, fout, doc);
		doc.setDocName(fout.getPath());
		if (StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
			doc.setTransferFile(true);
		} else {
			doc.setTransferFile(false);
		}
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(fout));
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(zipFileName));
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));
		user.getAddDocument(doc);
		saveUser(user);
		// Delete Temp files
		outputTempFiles.forEach(f -> {
			f.deleteOnExit();
		});
		return fout;

	}

	public File getPagesFromPdf(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

	public File deletePagesFromPdf(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

	public File addBarCodeToPdf(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

	public File readBarCodeFromPdf(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

	public File addQRCodeToPdf(File inputPdfFile, String docFileName, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}

}
