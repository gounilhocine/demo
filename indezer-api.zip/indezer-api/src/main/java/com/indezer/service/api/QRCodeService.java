package com.indezer.service.api;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.time.Instant;
import java.util.Date;
import java.util.Hashtable;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.StringUtils;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoder;
import org.krysalis.barcode4j.output.bitmap.BitmapEncoderRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerEnum.Environment;
import com.indezer.util.IndezerUtil;

@Service
public class QRCodeService extends AbstractService {

	private final Logger log = LoggerFactory.getLogger(QRCodeService.class);

	@Value("${qrcode.files.folder}")
	private String qrCodeFiles;

	public File create(String code, int size, String colorCode, String imageName, String docKey, User user,
			StopWatch watch, boolean test) throws Exception {

		// Create the ByteMatrix for the QR-Code that encodes the given String
		Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		BitMatrix byteMatrix = qrCodeWriter.encode(code, BarcodeFormat.QR_CODE, size, size, hintMap);
		// Make the BufferedImage that are to hold the QRCode
		int matrixWidth = byteMatrix.getWidth();
		BufferedImage image = new BufferedImage(matrixWidth, matrixWidth, BufferedImage.TYPE_INT_RGB);
		image.createGraphics();

		IndezerUtil.createFolder(qrCodeFiles.concat(File.separator).concat(user.getDirectory()));
		File outputFile = new File(qrCodeFiles.concat(user.getDirectory().concat(File.separator).concat(imageName)));

		Graphics2D graphics = (Graphics2D) image.getGraphics();
		graphics.fillRect(0, 0, matrixWidth, matrixWidth);
		// Paint and save the image using the ByteMatrix
		if (StringUtils.isEmpty(colorCode)) {
			graphics.setColor(Color.BLACK);
		} else {
			String[] colorCodes = colorCode.split("-");
			graphics.setColor(new Color(Integer.valueOf(colorCodes[0]), Integer.valueOf(colorCodes[1]),
					Integer.valueOf(colorCodes[2])));
		}
		for (int i = 0; i < matrixWidth; i++) {
			for (int j = 0; j < matrixWidth; j++) {
				if (byteMatrix.get(i, j)) {
					graphics.fillRect(i, j, 1, 1);
				}
			}
		}
		ImageIO.write(image, "png", outputFile);

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setUpdatedAt(Instant.now());
		doc.setOperationType(IndezerEnum.OperationType.QR_CODE);
		doc.setDocName(imageName);
		doc.setDocKey(docKey);
		doc.setDeleted(false);
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(outputFile));
		doc.setDocType(IndezerConstant.IMAGE_PNG);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(imageName));
		doc.setUser(user);
		user.getAddDocument(doc);
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));

		// If test
		if (test) {
			// // Get generated bitmap
			Double fontSize = 18.0;
			String[] paramArr = new String[] { "www.indezer.com" };
			int fSize = 20; // pixels
			int lineHeight = (int) (fontSize * 1.2);
			Font font = new Font("Arial", Font.PLAIN, fSize);
			int w = image.getWidth();
			int h = image.getHeight();
			FontRenderContext frc = new FontRenderContext(new AffineTransform(), false, true);
			for (int i = 0; i < paramArr.length; i++) {
				String line = paramArr[i];
				Rectangle2D bounds = font.getStringBounds(line, frc);
				w = (int) Math.ceil(Math.max(w, bounds.getWidth()));
				h += lineHeight;
			}

			// Add padding
			int padding = 20;
			w += 2 * padding;
			h += 3 * padding;

			BufferedImage bitmap = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_BINARY);
			Graphics2D g2d = (Graphics2D) bitmap.getGraphics();
			g2d.setBackground(Color.white);
			g2d.setColor(Color.RED);
			g2d.clearRect(0, 0, bitmap.getWidth(), bitmap.getHeight());
			g2d.setFont(font);

			// Place the barcode symbol
			AffineTransform symbolPlacement = new AffineTransform();
			symbolPlacement.translate(padding, padding);
			g2d.drawRenderedImage(image, symbolPlacement);

			// Add text lines (or anything else you might want to add)
			int y = padding + image.getHeight() + padding;
			for (int i = 0; i < paramArr.length; i++) {
				String line = paramArr[i];
				y += lineHeight;
				g2d.drawString(line, padding + 20, y);
			}
			g2d.dispose();

			// Encode bitmap as file
			String mime = "image/png";
			OutputStream out2 = new FileOutputStream(outputFile);
			try {
				final BitmapEncoder encoder = BitmapEncoderRegistry.getInstance(mime);
				int dpi = 120;
				encoder.encode(bitmap, out2, mime, dpi);
			} finally {
				out2.close();
			}
			doc.setEnvironment(Environment.TEST);
			setTestCreadit(user, outputFile);
		} else {
			doc.setEnvironment(Environment.PROD);
			setProdCredit(user, outputFile);
		}
		saveUser(user);

		log.debug("Convert : OK");
		return outputFile;
	}

}
