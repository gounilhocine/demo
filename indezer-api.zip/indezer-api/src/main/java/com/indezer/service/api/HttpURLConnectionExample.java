package com.indezer.service.api;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

public class HttpURLConnectionExample {

	private static final String USER_AGENT = "Mozilla/5.0";

	private static final String GET_URL = "http://665dev02:9090/jenkins";

	private static final String POST_URL = "http://665dev02:9090/jenkins/me/my-views/view/All/";

	private static final String POST_PARAMS = "login=gouni&password=Progteam20201@";
	
	static String userCredentials = "gouni:Progteam20201@";

	public static void main(String[] args) throws IOException {
		CookieHandler.setDefault( new CookieManager( null, CookiePolicy.ACCEPT_ALL ) );
//		sendGET();
		System.out.println("GET DONE");
		sendPOST();
//		System.out.println("POST DONE");
	}

	private static void sendGET() throws IOException {
		URL obj = new URL(GET_URL);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
		con.setRequestMethod("GET");
		con.setRequestProperty("Content-Type", "application/json;");
		con.setRequestProperty("Accept", "application/json");
		con.setDoOutput(true);
		con.setRequestProperty ("Authorization", basicAuth);
		int responseCode = con.getResponseCode();
		System.out.println("GET Response Code :: " + responseCode);
		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(
					con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			System.out.println(response.toString());
		} else {
			System.out.println("GET request not worked");
		}

	}

	private static void sendPOST() throws IOException {
		URL obj = new URL(POST_URL);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
//		con.setRequestProperty("User-Agent", USER_AGENT);
		String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
		con.setRequestMethod("POST");
		con.setRequestProperty ( "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0" );
		con.setRequestProperty("Content-Type", "application/json;");
		con.setRequestProperty("Accept", "application/json");
		con.setDoOutput(true);
		con.setRequestProperty ("Authorization", basicAuth);
		// For POST only - START
		con.setDoOutput(true);
		OutputStream os = con.getOutputStream();
		os.write(POST_PARAMS.getBytes());
		os.flush();
		os.close();
		// For POST only - END

		int responseCode = con.getResponseCode();
		System.out.println("POST Response Code :: " + responseCode);

		if (responseCode == HttpURLConnection.HTTP_OK) { //success
			BufferedReader in = new BufferedReader(new InputStreamReader(
					con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			System.out.println(response.toString());
			 BufferedWriter bwr = new BufferedWriter(new FileWriter(new File("c:/demo/pdf/2.html")));
			 bwr.write(response.toString());
			 bwr.flush();
			 bwr.close();
			 
		} else {
			System.out.println("POST request not worked");
		}
	}

}
