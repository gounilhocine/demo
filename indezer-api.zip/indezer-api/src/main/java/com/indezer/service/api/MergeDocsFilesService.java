package com.indezer.service.api;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum;
import com.indezer.util.IndezerUtil;
import com.indezer.util.ReadPdfFileFromUrl;

@Service
public class MergeDocsFilesService {

	@Value("${merge.pdfs.files.folder}")
	private String mergePdfsFiles;

	/**
	 * @param fileUrls
	 * @param docFileName
	 * @param watch
	 * @param user
	 * @param docKey
	 * @return
	 * @throws IOException
	 */
	public File merge(String fileUrls, String docFileName, String docKey, User user, StopWatch watch)
			throws IOException {
		// Files
		List<File> files = new ArrayList<File>();

		// Directory
		String dir = IndezerUtil.createFolder(mergePdfsFiles.concat(UUID.randomUUID().toString()));

		// Save Files
		String[] fileUrlTab = fileUrls.split(",");
		for (String path : fileUrlTab) {
			URL url = new URL(path);
			byte[] a = ReadPdfFileFromUrl.getArrayFromInputStream(url.openStream());
			ReadPdfFileFromUrl.writeContent(a,
					dir.concat(File.separator).concat(UUID.randomUUID().toString()).concat(".pdf"), files);
		}

		// Merge Files
		PDFMergerUtility pdfMerger = new PDFMergerUtility();
		pdfMerger.setDestinationFileName(docFileName);
		PDDocumentInformation documentInformation = new PDDocumentInformation();
		documentInformation.setTitle("Apache PdfBox Merge PDF Documents");
		documentInformation.setCreator("indezer.com");
		documentInformation.setSubject("Merging PDF documents API");
		for (File f : files) {
			pdfMerger.addSource(f);
		}
		pdfMerger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());

		IndezerUtil.createFolder(mergePdfsFiles.concat(user.getDirectory()));
		File outputFile = new File(
				mergePdfsFiles.concat(user.getDirectory().concat(File.separator).concat(docFileName)));

		// save doc
		Document doc = new Document();
		doc.setCreatedAt(Instant.now());
		doc.setOperationType(IndezerEnum.OperationType.MERGE_PDF);
		doc.setDocName(docFileName);
		doc.setDocKey(docKey);
		doc.setDeleted(false);
		doc.setSize(IndezerUtil.getFileSizeMegaBytes(outputFile));
		doc.setDocType(IndezerConstant.PDF);
		doc.setExpirationDate(new Date());
		doc.setUrl(IndezerConstant.INDEZER_WEB_URL.concat(user.getDirectory()).concat("/").concat(docFileName));
		doc.setUser(user);
		user.getAddDocument(doc);
		watch.stop();
		doc.setDuration(String.valueOf(watch.getTotalTimeMillis()).concat(" ms"));

		return outputFile;
	}

}
