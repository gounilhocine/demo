package com.indezer.service.api;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.krysalis.barcode4j.ChecksumMode;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.codabar.CodabarBean;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.impl.datamatrix.DataMatrixBean;
import org.krysalis.barcode4j.impl.fourstate.RoyalMailCBCBean;
import org.krysalis.barcode4j.impl.pdf417.PDF417Bean;
import org.krysalis.barcode4j.impl.postnet.POSTNETBean;
import org.krysalis.barcode4j.impl.upcean.EAN13Bean;
import org.krysalis.barcode4j.impl.upcean.EAN8Bean;
import org.krysalis.barcode4j.impl.upcean.UPCABean;
import org.krysalis.barcode4j.impl.upcean.UPCEBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.indezer.config.jms.EmailMessageProducer;
import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.Email;
import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.datasource.repo.DocumentRepositoty;
import com.indezer.datasource.repo.EmailRepository;
import com.indezer.datasource.repo.UserRepository;
import com.indezer.util.IndezerUtil;

@Component
public abstract class AbstractService {

	@Autowired
	private DocumentRepositoty documentRepositoty;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailRepository emailRepository;

	@Autowired
	private EmailMessageProducer emailMessageProducer;

	@Value("${activemq.queue}")
	protected String emailQueue;

	@Value("${static.path.folder}")
	protected String staticPathDir;

	@Value("${doc.watermark}")
	protected String watermark;

	protected static final Map<String, Object> fileOptions = new HashMap<String, Object>();

	public void saveDoc(Document doc) {
		documentRepositoty.save(doc);
	}

	/**
	 * @param user
	 * @param createdDate
	 * @return
	 */
	public String getStaticFolderPath(User user) {
		String dir = IndezerUtil.getFolderPath(staticPathDir, user, "yyyyMMdd");
		File dayDirectory = new File(dir);
		if (!dayDirectory.exists()) {
			dayDirectory.mkdirs();
			IndezerUtil.directoryProperties(dayDirectory);
		}
		return dir;
	}

	public Optional<User> findByApiKey(String apiKey) {
		return userRepository.findByApiKey(apiKey);
	}

	public void saveUser(User user) {
		user.setDataHasChanged(true);
		userRepository.save(user);
	}

	/**
	 * @param zipFile
	 * @param ownerPassword
	 * @param emailTo
	 */
	public void setFileOptions(Boolean zipFile, String ownerPassword, String emailTo) {
		fileOptions.put("zipFile", zipFile);
		fileOptions.put("ownerPassword", ownerPassword);
		fileOptions.put("emailTo", emailTo);
	}

	
//	protected File processingFile(String pdfFileName, User user, List<File> pdfFileNames, Document doc) throws Exception {
//		
//		File out = new File();
//		// Zip File
//		if (Boolean.parseBoolean(fileOptions.get("zipFile").toString())) {
//			fout = IndezerUtil.zipFile(fout, pdfFileNames);
//			// upadte doc
//			doc.setZipFile(true);
//		}
//		// encrypt File
//		if (StringUtils.isNoneEmpty(fileOptions.get("ownerPassword").toString())) {
//			String f = pdfFileName.substring(0, pdfFileName.length() - 4).concat("_temp.pdf");
//			fout = IndezerUtil.encryptFile(fout, f, fileOptions.get("ownerPassword").toString());
//			// upadte doc
//			doc.setEncrypt(true);
//		}
//		// send by email
//		if (StringUtils.isNoneEmpty(fileOptions.get("emailTo").toString())) {
//			Email email = new Email();
//			email.setAddress(fileOptions.get("emailTo").toString());
//			email.setCreatedAt(Instant.now());
//			email.setUserId(user.getId());
//			Boolean attachedFile = IndezerUtil.getFileSizeMegaBytes(fout) <= 9;
//			email.setAttachedFile(attachedFile);
//			email.setPathFile(fout.getPath());
//			emailRepository.save(email);
//			// upadte doc
//			doc.setSendByEmail(true);
//			// Mq
//			emailMessageProducer.sendTo(emailQueue, email);
//		}
//		return fout;
//		
//	}
	
	
	/**
	 * @param fileName
	 * @param user
	 * @param fout
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	protected File processingFile(String fileName, User user, File fout, Document doc) throws Exception {

		// Zip File
		if (Boolean.parseBoolean(fileOptions.get("zipFile").toString())) {
			String zf = fileName.substring(0, fileName.length() - 4).concat(".zip");
			fout = IndezerUtil.zipFile(fout, zf);
			// upadte doc
			doc.setZipFile(true);
		}
		// encrypt File
		if (StringUtils.isNoneEmpty(fileOptions.get("ownerPassword").toString())) {
			String f = fileName.substring(0, fileName.length() - 4).concat("_temp.pdf");
			fout = IndezerUtil.encryptFile(fout, f, fileOptions.get("ownerPassword").toString());
			// upadte doc
			doc.setEncrypt(true);
		}
		// send by email
		if (StringUtils.isNoneEmpty(fileOptions.get("emailTo").toString())) {
			Email email = new Email();
			email.setAddress(fileOptions.get("emailTo").toString());
			email.setCreatedAt(Instant.now());
			email.setUserId(user.getId());
			Boolean attachedFile = IndezerUtil.getFileSizeMegaBytes(fout) <= 9;
			email.setAttachedFile(attachedFile);
			email.setPathFile(fout.getPath());
			emailRepository.save(email);
			// upadte doc
			doc.setSendByEmail(true);
			// Mq
			emailMessageProducer.sendTo(emailQueue, email);
		}
		return fout;
	}

	/**
	 * @param fileName
	 * @param fileUrl
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public static void saveFileFromUrlWithJavaIO(String fileName, String fileUrl, File file)
			throws MalformedURLException, IOException {
		BufferedInputStream in = null;
		FileOutputStream fout = null;
		try {
			if (StringUtils.isNoneEmpty(fileUrl)) {
				in = new BufferedInputStream(new URL(fileUrl).openStream());
			} else if (file != null) {
				in = new BufferedInputStream(new FileInputStream(file));
			}
			fout = new FileOutputStream(fileName);

			byte data[] = new byte[1024];
			int count;
			while ((count = in.read(data, 0, 1024)) != -1) {
				fout.write(data, 0, count);
			}
		} finally {
			if (in != null)
				in.close();
			if (fout != null)
				fout.close();
		}
	}

	/**
	 * @param user
	 * @param outputFile
	 */
	public void setTestCreadit(User user, File outputFile) {
		Double credit = user.getTestCredit();
		if (credit - IndezerUtil.getFileSizeMegaBytes(outputFile) <= 0f) {
			user.setTestCredit(0d);
		} else {
			user.setTestCredit(
					IndezerUtil.roundDouble("#.####", credit - IndezerUtil.getFileSizeMegaBytes(outputFile)));
		}
	}

	/**
	 * @param user
	 * @param outputFile
	 */
	public void setTestCreadit(User user, List<File> outputFiles) {
		Double credit = user.getTestCredit();
		Double filesCredit = 0d;
		for (File file : outputFiles) {
			filesCredit += IndezerUtil.getFileSizeMegaBytes(file);
		}
		if (credit - filesCredit <= 0f) {
			user.setTestCredit(0d);
		} else {
			user.setTestCredit(IndezerUtil.roundDouble("#.####", filesCredit));
		}

	}

	/**
	 * @param user
	 * @param outputFile
	 */
	public void setProdCredit(User user, List<File> outputFiles) {
		Double credit = user.getTestCredit();
		Double filesCredit = 0d;
		for (File file : outputFiles) {
			filesCredit += IndezerUtil.getFileSizeMegaBytes(file);
		}
		if (credit - filesCredit <= 0f) {
			user.setCredit(0d);
		} else {
			user.setCredit(IndezerUtil.roundDouble("#.####", filesCredit));
		}

	}

	/**
	 * @param user
	 * @param outputFile
	 */
	public void setProdCredit(User user, File outputFile) {
		Double credit = user.getCredit();
		if (credit - IndezerUtil.getFileSizeKiloBytes(outputFile) <= 0f) {
			user.setCredit(0d);
		} else {
			user.setCredit(IndezerUtil.roundDouble("#.####", credit - IndezerUtil.getFileSizeKiloBytes(outputFile)));
		}
	}

	/**
	 * @param serverReference
	 * @return
	 */
	public RemoteServer getRemoteServerByReference(User user, String reference) {
		for (RemoteServer remoteServer : user.getRemoteServers()) {
			if (remoteServer.getReference().equalsIgnoreCase(reference)) {
				return remoteServer;
			}
		}
		return null;
	}

	/**
	 * @return
	 */
	public static TrustManager[] getTrustingManager() {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}
		} };
		return trustAllCerts;
	}

	/**
	 * @param barcodeType
	 * @return
	 */
	public AbstractBarcodeBean getEncoderBean(String barcodeType) {
		AbstractBarcodeBean bean = null;
		switch (barcodeType) {
		case "CODE39":
			Code39Bean code39 = new Code39Bean();
			code39.setWideFactor(3);
			code39.setDisplayChecksum(true);
			code39.setDisplayStartStop(true);
			code39.setExtendedCharSetEnabled(true);
			code39.setChecksumMode(ChecksumMode.CP_ADD);
			bean = code39;
			break;
		case "CODE128":
			Code128Bean code128 = new Code128Bean();
			bean = code128;
			break;
		case "DATAMATRIX":
			DataMatrixBean dataMatrixBean = new DataMatrixBean();
			bean = dataMatrixBean;
			break;
		case "CODABAR":
			CodabarBean codabar = new CodabarBean();
			codabar.setWideFactor(3);
			bean = codabar;
			break;
		// case "EAN128" :
		// EAN128Bean ean128Bean = new EAN128Bean();
		// bean = ean128Bean;
		// break;
		case "ROYALMAILCBC":
			RoyalMailCBCBean royalMailCBCBean = new RoyalMailCBCBean();
			bean = royalMailCBCBean;
			break;
		// case "ITF14" :
		// ITF14Bean itf14Bean = new ITF14Bean();
		// bean = itf14Bean;
		// break;
		case "PDF417":
			PDF417Bean pdf417Bean = new PDF417Bean();
			bean = pdf417Bean;
			break;
		case "POSTNET":
			POSTNETBean postnetBean = new POSTNETBean();
			bean = postnetBean;
			break;
		case "EAN13":
			EAN13Bean ean13Bean = new EAN13Bean();
			bean = ean13Bean;
			break;
		case "EAN8":
			EAN8Bean ean8Bean = new EAN8Bean();
			bean = ean8Bean;
			break;
		case "UPCA":
			UPCABean upcaBean = new UPCABean();
			bean = upcaBean;
			break;
		case "UPCE":
			UPCEBean upceBean = new UPCEBean();
			bean = upceBean;
			break;
		}
		return bean;
	}
}
