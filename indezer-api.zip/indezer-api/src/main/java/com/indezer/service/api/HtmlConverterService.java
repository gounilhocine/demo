package com.indezer.service.api;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import com.indezer.api.html.HtmlToPdf;
import com.indezer.api.html.HtmlToPdfObject;
import com.indezer.datasource.entity.User;
import com.indezer.dto.HtmlToPdfDto;
import com.indezer.util.IndezerConstant;

@Service
public class HtmlConverterService extends AbstractService {

	/**
	 * Get Domain Name from URL.
	 * 
	 * @param url
	 * @return
	 * @throws URISyntaxException
	 * @throws MalformedURLException
	 */
	public static String getDomainName(String url) throws MalformedURLException {
		URL uri = new URL(url);
		String domain = uri.getHost();
		String protocol = uri.getProtocol();
		int port = uri.getPort();
		if (port == -1) {
			if (protocol.equals("http")) {
				port = 80;
			} else if (protocol.equals("https")) {
				port = 443;
			}
		}
		return domain.startsWith("www.") ? protocol.concat("://").concat(domain.substring(4)).concat(":") + port
				: protocol.concat("://").concat(domain).concat(":") + port;
	}

	private final Logger log = LoggerFactory.getLogger(HtmlConverterService.class);

	private String postParams;

	private String htmlFileName;

	// @Autowired
	// private UserRepositoty userRepositoty;

	private String userCredentials = null;

	@Value("${html.files.folder}")
	private String htmlFiles;

	@Value("${pdf.files.folder}")
	private String pdfFiles;

	public HtmlConverterService() {
	}

	/**
	 * Get response status.
	 * 
	 * @param dto
	 * 
	 * @param htmlUrl
	 * @return
	 * @throws IOException
	 */
	public int checkHtmlUrl(HtmlToPdfDto dto, String htmlUrl) throws IOException {
		URL url = new URL(htmlUrl);
		if (StringUtils.isEmpty(dto.getUserAgent())) {
			dto.setUserAgent(IndezerConstant.USER_AGENT);
		}
		int status = 0;
		if ("http".equalsIgnoreCase(url.getProtocol())) {
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			userCredentials = dto.getAuthUser() + ":" + dto.getAuthPass();
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			con.setRequestProperty("User-Agent", dto.getUserAgent());
			con.setRequestProperty("Content-Type", IndezerConstant.CONTENT_TYPE);
			con.setRequestProperty("Accept", IndezerConstant.CONTENT_TYPE);
			con.setDoOutput(true);
			con.setRequestProperty("Authorization", basicAuth);
			status = con.getResponseCode();
		} else if ("https".equalsIgnoreCase(url.getProtocol())) {
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			status = con.getResponseCode();
		}
		log.debug("CheckHtmlUrl : OK");
		return 200;
	}

	//
	// public int checkHtmlUrl(HtmlToPdfDto dto, String htmlUrl) throws IOException
	// {
	// int status = 0;
	// URLConnection connection = new
	// URL("https://www.google.com").openConnection();
	// connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1;
	// WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95
	// Safari/537.11");
	// connection.connect();
	// return status;
	// }
	/**
	 * @param dto
	 * @param htmlFileName
	 * @return
	 */
	public boolean createPdf(HtmlToPdfDto dto, String htmlFileName, String pdfFileName) {
		CookieManager cookieManager = new CookieManager();
		CookieHandler.setDefault(cookieManager);
		HtmlToPdf.create()
				// .collate(dto.getCollate() != null ? dto.getCollate(): false)
				// .documentTitle(dto.getPdfTitle())
				// .dpi(dto.getDpi() != null ? dto.getDpi(): 0)
				// .imageDpi(dto.getImageDpi() != null ? dto.getDpi(): 0)
				// .marginBottom(dto.getMarginBottom())
				// .marginLeft(dto.getMarginLeft())
				// .marginRight(dto.getMarginRight())
				// .marginTop(dto.getMarginTop())
				// .orientation(dto.getOrientation() != null?
				// PdfOrientation.valueOf(dto.getOrientation())
				// : PdfOrientation.valueOf("PORTRAIT"))
				// .outline(dto.getOutline() != null? dto.getOutline():false)
				// .outlineDepth(dto.getOutlineDepth() != null? dto.getOutlineDepth():0)
				// .pageSize(dto.getPageSize() != null ? PdfPageSize.valueOf(dto.getPageSize())
				// : PdfPageSize.valueOf("A4"))
				// .colorMode(dto.getColorMode() != null?
				// PdfColorMode.valueOf(dto.getColorMode()):PdfColorMode.valueOf("COLOR"))
				// .compression(dto.getCompression() != null? dto.getCompression(): false)
				// .imageQuality(dto.getImageQuality() != null? dto.getImageQuality():94)
				.object(HtmlToPdfObject.forUrl(dto.getHtmlUrl()))
				// .defaultEncoding(dto.getTextEncoding() != null?
				// dto.getTextEncoding():"UTF-8")
				// .enableJavascript(dto.getDisableJavascript() !=null?
				// !dto.getDisableJavascript():false)
				// .useExternalLinks(dto.getDisableExternalLinks() !=null?
				// !dto.getDisableExternalLinks():false)
				// .userStylesheet(dto.getCssUrl())
				//// .session("sessionid 6773D41FDA64744464CE6CD22A9A1A20")
				// .loadImages(dto.getLoadImages() !=null? dto.getLoadImages():true)
				// .zoomFactor(dto.getZoomFactor() !=null? dto.getZoomFactor():1)
				// .pageCount(dto.getPageNumbers() !=null? dto.getPageNumbers():false))
				.convert(pdfFileName);
		log.debug("CreatePdf : OK  ==> " + pdfFileName);
		return true;
	}

	/**
	 * Format HTML code.
	 * 
	 * @param dto
	 * @throws IOException
	 * @throws URISyntaxException
	 */
	private void formatHtml(HtmlToPdfDto dto) throws IOException, URISyntaxException {
		// Parser
		File input = new File(htmlFiles.concat(File.separator).concat(htmlFileName.toString()));
		Document doc = Jsoup.parse(input, "UTF-8");
		Elements links = doc.select("link[href]");
		String url = getDomainName(dto.getHtmlUrl()).concat(File.separator);
		for (Element e : links) {
			String absUrl = e.attr("href");
			if (absUrl != null && !absUrl.startsWith("http") && !absUrl.startsWith("https")) {
				e.attr("href", url + absUrl);
			}
			System.out.println(" CSS : " + url + absUrl);
		}

		// now we process the imgs
		Elements imgs = doc.select("img");
		System.out.println("img count : " + imgs.size());
		for (Element e : imgs) {
			String absUrl = e.attr("src");
			if (absUrl != null && !absUrl.startsWith("http") && !absUrl.startsWith("https")) {
				e.attr("src", url + absUrl);
			}
		}
		FileUtils.writeStringToFile(input, doc.outerHtml(), "UTF-8");
	}

	/**
	 * @param dto
	 * @return
	 */
	private Map<String, String> getOptions(HtmlToPdfDto dto) {
		// TODO
		return null;
	}

	/**
	 * @param dto
	 * @return
	 * @throws Exception
	 */
	public String parseHtmlUrl(HtmlToPdfDto dto) throws Exception {
		if (StringUtils.isEmpty(dto.getUserAgent())) {
			dto.setUserAgent(IndezerConstant.USER_AGENT);
		}
		if (StringUtils.isEmpty(dto.getHtmlPage())) {
			// UrlWebPage
			if (dto.getAuthUser() != null && dto.getAuthPass() != null) {
				userCredentials = dto.getAuthUser() + ":" + dto.getAuthPass();
			}
			// System.setProperty("http.keepAlive", "true");
			postParams = "login=" + dto.getUserPassword() + "&password=" + dto.getOwnerPassword();
			URL url = new URL(dto.getHtmlUrl());

			if (StringUtils.isEmpty(dto.getUserAgent())) {
				dto.setUserAgent(IndezerConstant.USER_AGENT);
			}
			String basicAuth = null;
			if (userCredentials != null) {
				basicAuth = "Basic " + new String(Base64.getEncoder().encode(userCredentials.getBytes()));
			}

			int responseCode = 0;
			if ("http".equalsIgnoreCase(url.getProtocol())) {
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("POST");
				con.setRequestProperty("User-Agent", dto.getUserAgent());
				con.setRequestProperty("Content-Type", IndezerConstant.CONTENT_TYPE);
				con.setRequestProperty("Accept", IndezerConstant.CONTENT_TYPE);
				// con.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
				if (basicAuth != null)
					con.setRequestProperty("Authorization", basicAuth);
				// For POST only - START
				// con.setDoOutput(true);
				OutputStream os = con.getOutputStream();
				os.write(postParams.getBytes());
				os.flush();
				os.close();
				//
				//
				//
				// HttpURLConnection con = (HttpURLConnection) url.openConnection();
				// con.setRequestMethod("POST");
				// userCredentials = dto.getAuthUser() + ":" + dto.getAuthPass();
				// String basicAuth = "Basic " + new
				// String(Base64.getEncoder().encode(userCredentials.getBytes()));
				// con.setRequestProperty("User-Agent", dto.getUserAgent());
				// con.setRequestProperty("Content-Type", IndezerConstant.CONTENT_TYPE);
				// con.setRequestProperty("Accept", IndezerConstant.CONTENT_TYPE);
				// con.setDoOutput(true);
				// con.setRequestProperty("Authorization", basicAuth);
				// status = con.getResponseCode();

				responseCode = con.getResponseCode();
				if (responseCode == HttpURLConnection.HTTP_OK) { // success
					BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
					String inputLine;
					StringBuffer response = new StringBuffer();
					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();
					// print result
					// System.out.println(response.toString());
					htmlFileName = UUID.randomUUID() + ".html";
					BufferedWriter bwr = new BufferedWriter(
							new FileWriter(new File(htmlFiles.concat(File.separator).concat(htmlFileName.toString()))));
					bwr.write(response.toString());
					bwr.flush();
					bwr.close();
				}
			} else if ("https".equalsIgnoreCase(url.getProtocol())) {
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("POST");
				con.setRequestProperty("User-Agent", dto.getUserAgent());
				con.setRequestProperty("Content-Type", IndezerConstant.CONTENT_TYPE);
				con.setRequestProperty("Accept", IndezerConstant.CONTENT_TYPE);
				// con.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
				// con.setDoOutput(true);
				if (basicAuth != null)
					con.setRequestProperty("Authorization", basicAuth);
				// For POST only - START
				con.setDoOutput(true);
				OutputStream os = con.getOutputStream();
				os.write(postParams.getBytes());
				os.flush();
				os.close();
				responseCode = con.getResponseCode();
				if (responseCode == HttpURLConnection.HTTP_OK) { // success
					BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
					String inputLine;
					StringBuffer response = new StringBuffer();
					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();
					// print result
					// System.out.println(response.toString());
					htmlFileName = UUID.randomUUID() + ".html";
					BufferedWriter bwr = new BufferedWriter(
							new FileWriter(new File(htmlFiles.concat(File.separator).concat(htmlFileName.toString()))));
					bwr.write(response.toString());
					bwr.flush();
					bwr.close();
				}
			}
			// get the cookie if need, for login
			// String cookies = con.getHeaderField("Set-Cookie");
			// if (cookies == null) {
			// CookieManager cookieManager = new CookieManager();
			// cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
			//
			// if (CookieHandler.getDefault() != null) {
			// List<HttpCookie> lst = ((CookieManager)
			// CookieHandler.getDefault()).getCookieStore().getCookies();
			//
			// for (HttpCookie cookie : lst) {
			// if (cookie.getName().equals("auth")) {
			// con.setRequestProperty("Cookie", "auth=\"" + cookie.getValue() + "\"");
			// }
			// }
			// }
			// con.setRequestProperty("Cookie", cookies);
			// }

			// Format HTML Code
			formatHtml(dto);
		} else {
			// HtmlPage
			BufferedWriter writer = new BufferedWriter(
					new FileWriter(htmlFiles.concat(File.separator).concat(htmlFileName.toString())));
			writer.write(dto.getHtmlPage());
			writer.close();
		}
		log.debug("ParseHtmlUrl : OK ==> " + htmlFiles.concat(File.separator).concat(htmlFileName.toString()));
		return htmlFileName.toString();
	}

	public File pdfToHtml(File inputPdfFile, String htmlFileName2, String docKey, User user, StopWatch watch,
			Boolean test, String returnType) {
		// TODO Auto-generated method stub
		return null;
	}
}
