package com.indezer.service.api;

import java.net.CookieHandler;
import java.net.CookieManager;

import com.indezer.api.html.HtmlToPdf;
import com.indezer.api.html.HtmlToPdfObject;

public class HtmlPageToPdfTest {
	public static void main(String[] args) {
		CookieManager cookieManager = new CookieManager();  
		CookieHandler.setDefault(cookieManager);
		try {
			boolean success =
					HtmlToPdf.create().object(HtmlToPdfObject.forUrl("c:\\\\demo\\\\pdf\\\\test2.html")
//							.handleErrors(ObjectErrorHandling.IGNORE)
							.pageCount(true)
							)
//							.debugJavascriptWarningsAndErrors(true))
//							.showBackground(true)
//							.useExternalLinks(true))
//							.defaultEncoding("utf8")
//							.authUsername("gouni")
//							.authPassword("Natixis2019*"))
					.convert("c:/demo/pdf/test2.pdf");
			System.out.println("Staus : " + success);
		} catch (Exception e) {
			e.fillInStackTrace();
		}
	}
}
