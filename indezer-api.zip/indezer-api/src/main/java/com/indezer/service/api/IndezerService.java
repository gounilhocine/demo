package com.indezer.service.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.User;
import com.indezer.datasource.repo.DocumentRepositoty;
import com.indezer.datasource.repo.UserRepository;

@Service
public class IndezerService extends AbstractService {

	@Autowired
	private DocumentRepositoty documentRepositoty;

	@Autowired
	private UserRepository userRepository;

	/**
	 * @param documentId
	 */
	public void deleteDocumentByDocKey(String documentId) {
		documentRepositoty.deleteDocumentByDocKey(documentId);

	}

	/**
	 * @param userName
	 * @return
	 */
	public User getUser(String userName) {
		return userRepository.findUserByUserName(userName);
	}

	/**
	 * @param documentId
	 */
	public Document findDocumentByDocKey(String documentId) {
		return documentRepositoty.findDocumentByDocKey(documentId);
	}

	/**
	 * @param doc
	 * @return
	 */
	public Document saveDocument(Document doc) {
		return documentRepositoty.save(doc);
	}
	
	/**
     * Refresh the expired jwt token using a refresh token and device info. The
     * * refresh token is mapped to a specific device and if it is unexpired, can help
     * * generate a new jwt. If the refresh token is inactive for a device or it is expired,
     * * throw appropriate errors.
     */
//    public Optional<String> refreshJwtToken(TokenRefreshRequest tokenRefreshRequest) {
//        String requestRefreshToken = tokenRefreshRequest.getRefreshToken();
//        return Optional.of(findByApiKey(requestRefreshToken)
//                .map(refreshToken -> {
//                    refreshTokenService.verifyExpiration(refreshToken);
//                    userDeviceService.verifyRefreshAvailability(refreshToken);
//                    refreshTokenService.increaseCount(refreshToken);
//                    return refreshToken;
//                })
//                .map(RefreshToken::getUserDevice)
//                .map(UserDevice::getUser)
//                .map(User::getId).map(this::generateTokenFromUserId))
//                .orElseThrow(() -> new TokenRefreshException(requestRefreshToken, "Missing refresh token in database.Please login again"));
//    }
}
