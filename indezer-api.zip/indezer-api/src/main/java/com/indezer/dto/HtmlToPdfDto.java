package com.indezer.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HtmlToPdfDto implements Serializable {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -9051308529378639652L;
	private String htmlUrl; // OK
	private String htmlPage;// OK
	private String pdfName;// OK
	private String customUnit;
	private String userAgent;// OK
	private String acceptLang;
	private String textEncoding;
	private String ttl;
	private Boolean collate;// OK
	private String encryption;
	private String ownerPassword;
	private String userPassword;
	private String authUser;// OK
	private String authPass;// OK
	private String inline;
	private String force;
	private String pageSize;// OK
	private String colorMode;// OK
	private Boolean compression;// OK
	private Integer imageQuality;// OK
	private Boolean pageNumbers;// OK
	private String pageWidth;
	private String pageHeight;
	private String orientation;// OK
	private Boolean outline;// OK
	private Integer outlineDepth;// OK
	private String marginTop;// OK
	private String marginBottom;// OK
	private String marginLeft;// OK
	private String marginRight;// OK
	private String headerSpacing;

	private String headerText;
	private String headerAlign;
	private String headerUrl;
	private String headerHtml;

	private String footerSpacing;
	private String footerText;
	private String footerAlign;
	private String footerUrl;
	private String footerHtml;
	private String viewport;
	private String cssUrl;// OK
	private Boolean disableExternalLinks;// OK
	private String disableIntegerernalLinks;
	private String keepImagesTogether;
	private Boolean disableJavascript;// OK
	private String delay;
	private Integer dpi;// OK
	private Integer imageDpi;// OK
	private Boolean loadImages;// OK
	private Float zoomFactor;// OK
	private String watermarkUrl;
	private String watermarkOffsetX;
	private String watermarkOffsetY;
	private String watermarkOpacity;
	private String watermarkInBackground;
	private String pdfTitle;// OK
	private String pdfSubject;
	private String pdfCreator;
	private String pdfAuthor;
	private String pdfCreationDate;

	public HtmlToPdfDto() {
	}

	public HtmlToPdfDto(String htmlUrl, String htmlPage, String pdfName, String customUnit, String userAgent, String acceptLang, String textEncoding, String ttl, Boolean collate, String encryption, String ownerPassword, String userPassword, String authUser, String authPass, String inline, String force, String pageSize, String colorMode, Boolean compression, Integer imageQuality, Boolean pageNumbers, String pageWidth, String pageHeight, String orientation, Boolean outline, Integer outlineDepth, String marginTop, String marginBottom, String marginLeft, String marginRight, String headerSpacing, String headerText, String headerAlign, String headerUrl, String headerHtml, String footerSpacing, String footerText, String footerAlign, String footerUrl, String footerHtml, String viewport, String cssUrl, Boolean disableExternalLinks, String disableIntegerernalLinks, String keepImagesTogether, Boolean disableJavascript, String delay, Integer dpi, Integer imageDpi, Boolean loadImages, Float zoomFactor, String watermarkUrl, String watermarkOffsetX, String watermarkOffsetY, String watermarkOpacity, String watermarkInBackground, String pdfTitle, String pdfSubject, String pdfCreator, String pdfAuthor, String pdfCreationDate) {
		super();
		this.htmlUrl = htmlUrl;
		this.htmlPage = htmlPage;
		this.pdfName = pdfName;
		this.customUnit = customUnit;
		this.userAgent = userAgent;
		this.acceptLang = acceptLang;
		this.textEncoding = textEncoding;
		this.ttl = ttl;
		this.collate = collate;
		this.encryption = encryption;
		this.ownerPassword = ownerPassword;
		this.userPassword = userPassword;
		this.authUser = authUser;
		this.authPass = authPass;
		this.inline = inline;
		this.force = force;
		this.pageSize = pageSize;
		this.colorMode = colorMode;
		this.compression = compression;
		this.imageQuality = imageQuality;
		this.pageNumbers = pageNumbers;
		this.pageWidth = pageWidth;
		this.pageHeight = pageHeight;
		this.orientation = orientation;
		this.outline = outline;
		this.outlineDepth = outlineDepth;
		this.marginTop = marginTop;
		this.marginBottom = marginBottom;
		this.marginLeft = marginLeft;
		this.marginRight = marginRight;
		this.headerSpacing = headerSpacing;
		this.headerText = headerText;
		this.headerAlign = headerAlign;
		this.headerUrl = headerUrl;
		this.headerHtml = headerHtml;
		this.footerSpacing = footerSpacing;
		this.footerText = footerText;
		this.footerAlign = footerAlign;
		this.footerUrl = footerUrl;
		this.footerHtml = footerHtml;
		this.viewport = viewport;
		this.cssUrl = cssUrl;
		this.disableExternalLinks = disableExternalLinks;
		this.disableIntegerernalLinks = disableIntegerernalLinks;
		this.keepImagesTogether = keepImagesTogether;
		this.disableJavascript = disableJavascript;
		this.delay = delay;
		this.dpi = dpi;
		this.imageDpi = imageDpi;
		this.loadImages = loadImages;
		this.zoomFactor = zoomFactor;
		this.watermarkUrl = watermarkUrl;
		this.watermarkOffsetX = watermarkOffsetX;
		this.watermarkOffsetY = watermarkOffsetY;
		this.watermarkOpacity = watermarkOpacity;
		this.watermarkInBackground = watermarkInBackground;
		this.pdfTitle = pdfTitle;
		this.pdfSubject = pdfSubject;
		this.pdfCreator = pdfCreator;
		this.pdfAuthor = pdfAuthor;
		this.pdfCreationDate = pdfCreationDate;
	}

}
