package com.indezer.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccessDto {

	private String userName;
	private String password;
}
