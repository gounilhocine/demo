package com.indezer.config.jms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.indezer.datasource.entity.Email;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EmailMessageProducer {

	@Autowired
	private JmsTemplate jmsTemplate;

	public void sendTo(String queueName, Email email) {
		jmsTemplate.convertAndSend(queueName, email);
		log.info("Producer> Message Sent");
	}
}
