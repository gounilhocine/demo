package com.indezer.api.exception;

public class HtmlToPdfException extends RuntimeException {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -3948434541680469433L;

	public HtmlToPdfException(String accessKey) {
		super("Access Key not found : " + accessKey);
	}
}
