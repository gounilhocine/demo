package com.indezer.api.service;

import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.commons.lang3.StringUtils;
import org.krysalis.barcode4j.ChecksumMode;
import org.krysalis.barcode4j.HumanReadablePlacement;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.codabar.CodabarBean;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.impl.datamatrix.DataMatrixBean;
import org.krysalis.barcode4j.impl.fourstate.RoyalMailCBCBean;
import org.krysalis.barcode4j.impl.pdf417.PDF417Bean;
import org.krysalis.barcode4j.impl.postnet.POSTNETBean;
import org.krysalis.barcode4j.impl.upcean.EAN13Bean;
import org.krysalis.barcode4j.impl.upcean.EAN8Bean;
import org.krysalis.barcode4j.impl.upcean.UPCABean;
import org.krysalis.barcode4j.impl.upcean.UPCEBean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class BarCodeService {

	private final Logger log = LoggerFactory.getLogger(BarCodeService.class);

	// @Autowired
	// private UserRepositoty userRepositoty;

	public boolean checkAccessKey(String accessKey) {
		// User user = userRepositoty.findByAccessKey(accessKey);
		// if (user != null) {
		// return false;
		// }
		log.debug("CheckAccessKey : OK");
		return true;
	}

	public File create(String barcodeType, String code, Double height, Double width, int dpi, Double fontSize, String imageName, Boolean encode, String textPosition) throws Exception {

		// Create the barcode bean
		AbstractBarcodeBean bean = getEncoderBean(barcodeType);

		bean.setBarHeight(height);
		bean.setFontName(Font.MONOSPACED);
		bean.setFontSize(fontSize);

		// final int dpi = 120;
		// Configure the barcode generator
		bean.setModuleWidth(UnitConv.in2mm(1.0f / dpi)); // makes the narrow bar
		bean.doQuietZone(false);

		if (StringUtils.isNotBlank(textPosition)) {
			if (StringUtils.equalsAnyIgnoreCase(textPosition, "HRP_BOTTOM")) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_BOTTOM);
			} else if (StringUtils.equalsAnyIgnoreCase(textPosition, "HRP_TOP")) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_TOP);
			} else if (StringUtils.equalsAnyIgnoreCase(textPosition, "HRP_NONE")) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_NONE);
			}
		} else {
			bean.setMsgPosition(HumanReadablePlacement.HRP_BOTTOM);
		}
		bean.setModuleWidth(0.5);
		// bean.setBarHeight(20.0);
		// bean.setFontSize(5.0);
		bean.setQuietZone(10.0);
		// bean.setChecksumMode(ChecksumMode.CP_ADD);
		// bean.doQuietZone(true);
		// Open output file
		File outputFile = new File(imageName);
		OutputStream out = new FileOutputStream(outputFile);
		// Set up the canvas provider for monochrome JPEG output
		BitmapCanvasProvider canvas = new BitmapCanvasProvider(out, "image/png", dpi, BufferedImage.TYPE_BYTE_BINARY, false, 0);

		bean.doQuietZone(false);

		bean.calcDimensions("message");
		// Generate the barcode
		bean.generateBarcode(canvas, code);
		// Signal end of generation
		canvas.finish();
		out.close();

		// // Get generated bitmap
		// BufferedImage symbol = canvas.getBufferedImage();
		//
		// String[] paramArr = new String[]{"Barcode4J is cool!"};
		// int fSize = 20; // pixels
		// int lineHeight = (int) (fontSize * 1.2);
		// Font font = new Font("Arial", Font.PLAIN, fSize);
		// int w = symbol.getWidth();
		// int h = symbol.getHeight();
		// FontRenderContext frc = new FontRenderContext(new AffineTransform(), false, true);
		// for (
		// int i = 0;
		// i < paramArr.length;
		// i++) {
		// String line = paramArr[i];
		// Rectangle2D bounds = font.getStringBounds(line, frc);
		// w = (int) Math.ceil(Math.max(w, bounds.getWidth()));
		// h += lineHeight;
		// }
		//
		// // Add padding
		// int padding = 2;
		// w += 2 * padding;
		// h += 3 * padding;
		//
		// BufferedImage bitmap = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_BINARY);
		// Graphics2D g2d = (Graphics2D) bitmap.getGraphics();
		// g2d.setBackground(Color.white);
		// g2d.setColor(Color.black);
		// g2d.clearRect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		// g2d.setFont(font);
		//
		// // Place the barcode symbol
		// AffineTransform symbolPlacement = new AffineTransform();
		// symbolPlacement.translate(padding, padding);
		// g2d.drawRenderedImage(symbol, symbolPlacement);
		//
		// // Add text lines (or anything else you might want to add)
		// int y = padding + symbol.getHeight() + padding;
		// for (
		// int i = 0;
		// i < paramArr.length;
		// i++) {
		// String line = paramArr[i];
		// y += lineHeight;
		// g2d.drawString(line, padding, y);
		// }
		// g2d.dispose();
		//
		// // Encode bitmap as file
		// String mime = "image/png";
		// String outputFile2 = "c:/demo/indezer/barCode33.jpeg";
		// OutputStream out2 = new FileOutputStream(outputFile2);
		// try {
		// final BitmapEncoder encoder = BitmapEncoderRegistry.getInstance(mime);
		// encoder.encode(bitmap, out2, mime, dpi);
		// } finally {
		// out2.close();
		// }

		log.debug("Convert : OK");
		return outputFile;
	}

	// public File create2(String barcodeType, String code, Double height, Double width, int dpi, Double fontSize, String imageName, Boolean encode, String textPosition) throws Exception {
	//
	// Code128Bean code128 = new Code128Bean();
	// code128.setHeight(15f);
	// code128.setModuleWidth(0.3);
	// code128.setQuietZone(10);
	// code128.doQuietZone(true);
	//
	// File outputFile = new File("c:/demo/indezer/barcode444.png");
	//
	// ByteArrayOutputStream baos = new ByteArrayOutputStream();
	// BitmapCanvasProvider canvas = new BitmapCanvasProvider(baos, "image/jpeg", 300, BufferedImage.TYPE_BYTE_BINARY, false, 0);
	// code128.generateBarcode(canvas, "1234567890");
	// canvas.finish();
	//
	// //write to png file
	// FileOutputStream fos = new FileOutputStream(outputFile);
	// fos.write(baos.toByteArray());
	// fos.flush();
	// fos.close();
	//
	// //write to pdf
	// Image png = Image.getInstance(baos.toByteArray());
	// png.setAbsolutePosition(400, 685);
	// png.scalePercent(25);
	//
	//// Document document = new Document(new Rectangle(595, 842));
	//// PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("barcodes.pdf"));
	//// document.open();
	//// document.add(png);
	//// document.close();
	//
	// return outputFile;
	// }

	public File creates(String barcodeType, String codes, Double height, Double width, int dpi, Double fontSize, String imageName, Boolean encode, String textPosition) throws Exception {

		File imageCode = null;
		String[] codeList = codes.split(",");
		if (codeList.length == 1) {
			imageCode = create(barcodeType, codes, height, width, dpi, fontSize, imageName, encode, textPosition);
		} else {
			float i = 0;
			for (String code : codeList) {
				imageCode = create(barcodeType, code, height, width, dpi, fontSize, imageName, encode, textPosition);
				// Add Image to PDF File
//				Document document = new Document();
//				PdfWriter.getInstance(document, new FileOutputStream("c:/demo/indezer/sample1.pdf"));
//				document.open();
//				Path path = imageCode.toPath();
//				byte[] fileContent = Files.readAllBytes(path);
//				Image img = Image.getInstance(fileContent);
//				img.scaleAbsolute(100f+i, 50f );
////				document.add(new Paragraph("Sample 1: This is simple image demo."));
//				document.add(img);
//				document.close();
//				i = i + 50;
			}
		}
		return imageCode;
	}

	/**
	 * @param barcodeType
	 * @return
	 */
	private AbstractBarcodeBean getEncoderBean(String barcodeType) {
		AbstractBarcodeBean bean = null;
		switch (barcodeType) {
			case "CODE39" :
				Code39Bean code39 = new Code39Bean();
				code39.setWideFactor(3);
				code39.setDisplayChecksum(true);
				code39.setDisplayStartStop(true);
				code39.setExtendedCharSetEnabled(true);
				code39.setChecksumMode(ChecksumMode.CP_ADD);
				bean = code39;
				break;
			case "CODE128" :
				Code128Bean code128 = new Code128Bean();
				bean = code128;
				break;
			case "DATAMATRIX" :
				DataMatrixBean dataMatrixBean = new DataMatrixBean();
				bean = dataMatrixBean;
				break;
			case "CODABAR" :
				CodabarBean codabar = new CodabarBean();
				codabar.setWideFactor(3);
				bean = codabar;
				break;
			// case "EAN128" :
			// EAN128Bean ean128Bean = new EAN128Bean();
			// bean = ean128Bean;
			// break;
			case "ROYALMAILCBC" :
				RoyalMailCBCBean royalMailCBCBean = new RoyalMailCBCBean();
				bean = royalMailCBCBean;
				break;
			// case "ITF14" :
			// ITF14Bean itf14Bean = new ITF14Bean();
			// bean = itf14Bean;
			// break;
			case "PDF417" :
				PDF417Bean pdf417Bean = new PDF417Bean();
				bean = pdf417Bean;
				break;
			case "POSTNET" :
				POSTNETBean postnetBean = new POSTNETBean();
				bean = postnetBean;
				break;
			case "EAN13" :
				EAN13Bean ean13Bean = new EAN13Bean();
				bean = ean13Bean;
				break;
			case "EAN8" :
				EAN8Bean ean8Bean = new EAN8Bean();
				bean = ean8Bean;
				break;
			case "UPCA" :
				UPCABean upcaBean = new UPCABean();
				bean = upcaBean;
				break;
			case "UPCE" :
				UPCEBean upceBean = new UPCEBean();
				bean = upceBean;
				break;
		}
		return bean;
	}

}
