package com.indezer.api.util;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class Response {
	private String message;
	private String code;
	private HttpStatus status;
	private String document;
	private String size;
	private String document_id;
	private String timestamp;
    private String error;
}
