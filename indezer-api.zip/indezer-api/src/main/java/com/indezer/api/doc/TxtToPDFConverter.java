package com.indezer.api.doc;

import com.indezer.api.Converter;
import com.zeonpad.pdfcovertor.GenericConvertor;

public class TxtToPDFConverter extends Converter {

	public TxtToPDFConverter(String inFilePath, String outFilePath, boolean showMessages,
			boolean closeStreamsWhenComplete) {
		super(inFilePath, outFilePath, showMessages, closeStreamsWhenComplete);

	}

	@Override
	public void convert() throws Exception {
		loading();
		String iFilePath = inFilePath;
		String oFilePath = outFilePath;
		// Create an Object
		GenericConvertor genericConv = new GenericConvertor();
		// Covert to Pdf
		genericConv.convert(iFilePath, oFilePath);
		finished();
	}
}
