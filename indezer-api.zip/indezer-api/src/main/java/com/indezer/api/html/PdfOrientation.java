package com.indezer.api.html;

public enum PdfOrientation implements WkValue {
    PORTRAIT("Portrait"),
    LANDSCAPE("Landscape");

    private final String wkValue;

    PdfOrientation(String wkValue) {
        this.wkValue = wkValue;
    }

    @Override
    public String getWkValue() {
        return wkValue;
    }
}
