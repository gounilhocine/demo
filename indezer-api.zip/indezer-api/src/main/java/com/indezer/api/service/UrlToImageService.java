package com.indezer.api.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.indezer.url2image.WebImage;

@Service
public class UrlToImageService {

	/**
	 * @param imageUrl
	 * @param destinationFile
	 * @throws IOException
	 */
	public static void convertUtlToImage(String imageUrl, String destinationFile, String distinationDirectory) throws IOException {

		// Call the Web page and convert to Image
		BufferedImage ire;
		ire = WebImage.create(imageUrl, 2000, 2024);
		ImageIO.write(ire, "png", new File(distinationDirectory.concat(File.separator).concat(destinationFile)));

//		URL url = new URL(imageUrl);
//		InputStream is = url.openStream();
//		// OutputStream os = new FileOutputStream(distinationDirectory.concat(File.separator).concat(destinationFile));
//		byte[] b = new byte[2048];
//		int length;
//		StringBuffer response = new StringBuffer();
//		while ((length = is.read(b)) != -1) {
//			response.append(length);
//		}
//		BufferedWriter bwr = new BufferedWriter(new FileWriter(distinationDirectory.concat(File.separator).concat(destinationFile)));
//		is.close();
//		bwr.write(response.toString());
//		bwr.flush();
//		bwr.close();
	}

	@Value("${urlToImageFiles.folder}")
	private String urlToImageFiles;

	/**
	 * @param accessKey
	 * @return
	 */
	public boolean checkAccessKey(String accessKey) { return true; }

	/**
	 * @param path
	 * @return
	 */
	private String createFolder(String path) {
		File dir = new File(urlToImageFiles.concat(File.separator).concat(path));
		if (!dir.exists()) {
			dir.mkdir();
			return dir.toString();
		}
		return null;
	}

	/**
	 * @param url
	 * @param imageFileName
	 * @return
	 * @throws IOException
	 */
	public File urlToImage(String url, String imageFileName) throws IOException {
		// Directory
		String distinationDirectory = createFolder(UUID.randomUUID().toString());
		// convert
		convertUtlToImage(url, imageFileName, distinationDirectory);
		return new File(imageFileName);
	}

}
