package com.indezer.api.pdf;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.docx4j.Docx4J;
import org.docx4j.convert.in.Doc;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;

import com.indezer.api.Converter;

public class PdfToImageConverter extends Converter {

	public PdfToImageConverter(InputStream inStream, OutputStream outStream, boolean showMessages,
			boolean closeStreamsWhenComplete) {
		super(inStream, outStream, showMessages, closeStreamsWhenComplete);
	}

	@Override
	public void convert() throws Exception {
		loading();
		InputStream iStream = inStream;
		WordprocessingMLPackage wordMLPackage = getMLPackage(iStream);
		processing();
		Docx4J.toPDF(wordMLPackage, outStream);
		finished();
	}

	protected WordprocessingMLPackage getMLPackage(InputStream iStream) throws Exception {
		PrintStream originalStdout = System.out;
		// Disable stdout temporarily as Doc convert produces alot of output
		System.setOut(new PrintStream(new OutputStream() {
			@Override
			public void write(int b) {
				// DO NOTHING
			}
		}));
		FileInputStream fileInputStream = (FileInputStream) iStream;
		WordprocessingMLPackage mlPackage = Doc.convert(fileInputStream);
		System.setOut(originalStdout);
		return mlPackage;
	}
}
