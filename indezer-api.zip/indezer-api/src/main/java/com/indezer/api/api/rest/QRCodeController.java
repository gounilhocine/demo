package com.indezer.api.api.rest;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.api.service.QRCodeService;
import com.indezer.api.util.GeneratePdfReport;
import com.indezer.api.util.IndezerConstant;
import com.indezer.api.util.IndezerUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1.0/QRCode")
@Api(tags = {"barCode"})
public class QRCodeController extends AbstractRestHandler {

	@Autowired
	private QRCodeService qRCodeService;

	private boolean accessKeyStatus;

	private String barCodeFileName;

	@Value("${barCodeFiles.folder}")
	private String barCodeFiles;

	@RequestMapping(value = "/create", method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE},
			produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PDF_VALUE})
	@ApiOperation(value = "Create a QR Code.",
			notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "access_key") String accessKey,
			@RequestParam(required = true, name = "code") String code,
			@RequestParam(required = true, name = "size") Integer size,
			@RequestParam(required = false, name = "margin") String margin,
			@RequestParam(required = false, name = "image-name", defaultValue = "qrcode.jpeg") String imageName,
			@RequestParam(required = true, name = "return_type") String returnType) {
		com.indezer.api.util.Response responseStatus = new com.indezer.api.util.Response();
		String errors = "";
		try {
			// step-1 : check access_key
			accessKeyStatus = qRCodeService.checkAccessKey(accessKey);
			if (accessKeyStatus) {
				barCodeFileName = imageName != null ? imageName : UUID.randomUUID() + ".jpeg";
				File imgFile =
						qRCodeService.create(code, size.intValue() , margin, barCodeFiles.concat(barCodeFileName));

				HttpHeaders headers = new HttpHeaders();
				headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
				headers.add("Pragma", "no-cache");
				headers.add("Expires", "0");
				ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(imgFile);
				headers.add("Content-Disposition", "inline; filename=" + imgFile);

				if (org.apache.commons.lang3.StringUtils.equals(returnType, "JSON")) {
					return getResponseMessage(responseStatus, "200", IndezerConstant.BARCODE_CREATED_MESSAGE, HttpStatus.OK, imgFile.getName(), IndezerUtil.getFileSizeKiloBytes(imgFile), UUID.randomUUID().toString(), null);
				} else if (org.apache.commons.lang3.StringUtils.equals(returnType, "IMG")) {
					return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG).body(new InputStreamResource(
							bis));
				}
			} else {
				// access key is KO
				errors = "error occurred";
				return getResponseMessage(responseStatus, "404", IndezerConstant.BAD_REQUEST_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, errors);
			}
		} catch (Exception e) {
			e.fillInStackTrace();
		}
		return null;
	}
	
	/**
	 * @param responseStatus
	 * @param code
	 * @param message
	 * @param badRequest
	 * @param errors
	 * @return
	 */
	private ResponseEntity<?> getResponseMessage(com.indezer.api.util.Response responseStatus, String code,
			String message, HttpStatus badRequest, String doc, String size, String transactionId, String errors) {
		responseStatus.setCode(code);
		responseStatus.setMessage(message);
		responseStatus.setDocument(doc);
		responseStatus.setSize(size);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Instant instant = timestamp.toInstant();
		responseStatus.setTimestamp(instant.toString());
		responseStatus.setStatus(badRequest);
		responseStatus.setDocument_id(transactionId);
		return new ResponseEntity<Object>(responseStatus, HttpStatus.BAD_REQUEST);
	}
}
