package com.indezer.api.util;

public class IndezerConstant {

	public static final String CONTENT_TYPE = "application/json;";

	public static final String USER_AGENT =
			"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0";

	public static final String BAD_REQUEST_MESSAGE = "Year access key is not valid";

	public static final String BAD_URL_OR_CREDENTIALS_MESSAGE = "Check your url and your credentials";

	public static final String PDF_CREATED_MESSAGE = "PDF file is created";
	
	public static final String BARCODE_CREATED_MESSAGE = "BarCode image is created";

	public static final String PDF_NOT_CREATED_MESSAGE = "PDF file is not created. Please try again";

	public static final String ERROR_OCCURRED = "error occurred";

	public static final String BAD_REQUEST_REURN_TYPE_NOT_VALID = "return_type Value is not valid. PLease use {'PDF' or 'JSON'}";

	public static final String TECHNICAL_ERROR = "technical error";

	public static final String PDF_MERGED_MESSAGE = "PDF files is merged";

}
