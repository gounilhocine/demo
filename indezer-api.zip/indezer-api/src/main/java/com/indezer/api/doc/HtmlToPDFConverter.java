package com.indezer.api.doc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.indezer.api.Converter;
import com.lowagie.text.Document;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class HtmlToPDFConverter extends Converter {

	public HtmlToPDFConverter(InputStream inStream, OutputStream outStream, boolean showMessages,
			boolean closeStreamsWhenComplete) {
		super(inStream, outStream, showMessages, closeStreamsWhenComplete);

	}

	// https://www.java67.com/2014/09/how-to-read-write-xlsx-file-in-java-apache-poi-example.html

	@Override
	public void convert() throws Exception {

		FileInputStream input_document = new FileInputStream(new File("C:\\demo\\indezer\\excel2pdf\\demo.xlsx"));

		// Finds the workbook instance for XLSX file
		XSSFWorkbook my_xls_workbook = new XSSFWorkbook(input_document);

		// Return first sheet from the XLSX workbook
		XSSFSheet mySheet = my_xls_workbook.getSheetAt(0);

		// To iterate over the rows
		java.util.Iterator<org.apache.poi.ss.usermodel.Row> rowIterator = mySheet.iterator();
		// We will create output PDF document objects at this point
		Document iText_xls_2_pdf = new Document();
		PdfWriter.getInstance(iText_xls_2_pdf, new FileOutputStream("Excel2PDF_Output.pdf"));
		iText_xls_2_pdf.open();
		// we have two columns in the Excel sheet, so we create a PDF table with two
		// columns
		// Note: There are ways to make this dynamic in nature, if you want to.
		PdfPTable my_table = new PdfPTable(2);
		// We will use the object below to dynamically add new data to the table
		PdfPCell table_cell;
		// Loop through rows.
		while (rowIterator.hasNext()) {
			org.apache.poi.ss.usermodel.Row row = rowIterator.next();
			Iterator<org.apache.poi.ss.usermodel.Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()) {
				org.apache.poi.ss.usermodel.Cell cell = cellIterator.next(); // Fetch CELL
				switch (cell.getCellType()) { // Identify CELL type
				// you need to add more code here based on
				// your requirement / transformations
				case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
					// Push the data from Excel to PDF Cell
					table_cell = new PdfPCell(new Phrase(cell.getStringCellValue()));
					// feel free to move the code below to suit to your needs
					my_table.addCell(table_cell);
					break;
				}
				// next line
			}

		}
		// Finally add the table to PDF document
		iText_xls_2_pdf.add(my_table);
		iText_xls_2_pdf.close();
		// we created our pdf file..
		input_document.close(); // close xls
	}
}
