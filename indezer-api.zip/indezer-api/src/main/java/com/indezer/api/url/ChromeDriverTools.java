package com.indezer.api.url;

import java.io.File;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.indezer.util.IndezerMap;

public class ChromeDriverTools {

	public static void url2Image(String urlPage, String outputFileName, IndezerMap<String, String> settings,
			String chromeDriverPath) throws Exception {
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1400", "--ignore-certificate-errors",
//				"--silent");

		options.addArguments(getArguments(settings), "--ignore-certificate-errors");
		WebDriver driver = new ChromeDriver(options);

		// Get the login page
		driver.get(urlPage);

		if (settings.containsKey("password_login_page_url") && settings.containsKey("username_login_page_url")) {
			driver.findElement(By.xpath("//input[@name='j_username']"))
					.sendKeys(settings.get("username_login_page_url"));
			driver.findElement(By.xpath("//input[@type='password']")).sendKeys(settings.get("password_login_page_url"));
			// Locate the login button and click on it
			driver.findElement(By.xpath("//input[@value='Connexion']")).click();
		}

		if (settings.containsKey("login_page_url")) {
			if (driver.getCurrentUrl().equals(settings.get("login_page_url"))) {
				System.out.println("Incorrect credentials");
				driver.quit();
			} else {
				System.out.println("Successfuly logged in");
			}
		}

		// Take a screenshot of the current page
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File(outputFileName));

		// Logout
		if (settings.containsKey("login_page_url")) {
			driver.findElement(By.id("logout")).click();
		}
		driver.quit();

	}

	/**
	 * @param settings
	 * @return
	 */
	private static String getArguments(IndezerMap<String, String> settings) {
		StringBuilder builder = new StringBuilder();
		for (Entry<String, String> entry : settings.entrySet()) {
			if ("window-size".equalsIgnoreCase(entry.getKey())) {
				builder.append(" --window-size").append(settings.get("screen-width")).append(",")
						.append(settings.get("screen-height"));
			} else if (entry.getValue().equalsIgnoreCase("true")) {
				builder.append(" --").append(entry.getKey());
			}
		}
		return builder.toString();
	}

}
