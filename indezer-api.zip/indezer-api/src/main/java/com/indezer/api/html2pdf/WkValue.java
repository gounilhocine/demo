package com.indezer.api.html2pdf;

public interface WkValue {
    String getWkValue();
}
