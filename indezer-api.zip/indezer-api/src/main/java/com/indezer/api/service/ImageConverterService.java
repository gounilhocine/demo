package com.indezer.api.service;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ImageConverterService {
	

	/**
	 * @return
	 */
	private static TrustManager[] getTrustingManager() {
		TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] certs, String authType) {}
			@Override
			public void checkServerTrusted(X509Certificate[] certs, String authType) {}
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
		}};
		return trustAllCerts;
	}


	@Value("${imageConverter.folder}")
	private String urlToImageFiles;

	/**
	 * @param accessKey
	 * @return
	 */
	public boolean checkAccessKey(String accessKey) { return true; }

	/**
	 * @param imageUrl
	 * @param destinationFile
	 * @throws IOException
	 * @throws Exception
	 */
	public File convertImage(String imageUrl, String destinationFile, String extenssion, int width, int height) throws Exception {
		InputStream connection;
		BufferedImage bufferedimage = null;
		URL url = new URL(imageUrl);
		if (imageUrl.indexOf("https://") != -1) {
			final SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, getTrustingManager(), new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			connection = url.openStream();
		} else {
			connection = url.openStream();
		}
		bufferedimage = ImageIO.read(connection);
		width = bufferedimage.getWidth();
		height = bufferedimage.getHeight();

		String distinationDirectory = createFolder(UUID.randomUUID().toString());
		ImageIO.write(bufferedimage, extenssion, new File(distinationDirectory.concat(destinationFile).concat(".").concat(extenssion)));

		return new File(destinationFile);
	}

	/**
	 * @param path
	 * @return
	 */
	private String createFolder(String path) {
		File dir = new File(urlToImageFiles.concat(File.separator).concat(path));
		if (!dir.exists()) {
			dir.mkdir();
			return dir.toString();
		}
		return null;
	}

}
