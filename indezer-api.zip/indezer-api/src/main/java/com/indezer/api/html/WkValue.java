package com.indezer.api.html;

public interface WkValue {
    String getWkValue();
}
