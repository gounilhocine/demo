package com.indezer.api.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ReadPdfFileFromUrl {
	
	/**
	 * @param inputStream
	 * @return
	 * @throws IOException
	 */
	public static byte[] getArrayFromInputStream(InputStream inputStream) throws IOException {
		byte[] bytes;
		byte[] buffer = new byte[1024];
		try (BufferedInputStream is = new BufferedInputStream(inputStream)) {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			int length;
			while ((length = is.read(buffer)) > -1) {
				bos.write(buffer, 0, length);
			}
			bos.flush();
			bytes = bos.toByteArray();
		}
		return bytes;
	}
	
	/**
	 * @param content
	 * @param fileToWriteTo
	 * @throws IOException
	 */
	public static void writeContent(byte[] content, String fileToWriteTo, List<File> files) throws IOException {
		File file = new File(fileToWriteTo);
		files.add(file);
		try (BufferedOutputStream salida = new BufferedOutputStream(new FileOutputStream(file))) {
			salida.write(content);
			salida.flush();
		}
	}

}
