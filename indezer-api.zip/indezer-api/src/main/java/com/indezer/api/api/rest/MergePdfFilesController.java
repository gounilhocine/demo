package com.indezer.api.api.rest;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.api.service.MergePdfFilesService;
import com.indezer.api.util.GeneratePdfReport;
import com.indezer.api.util.IndezerConstant;
import com.indezer.api.util.IndezerUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1.0/mergePdfs")
@Api(tags = {"mergePdfs"})
public class MergePdfFilesController {
	
	@Autowired
	private MergePdfFilesService mergePdfFilesService;

	private boolean accessKeyStatus;

	private String fileNameMerged;

	@Value("${barCodeFiles.folder}")
	private String barCodeFiles;
	
	/**
	 * @param accessKey
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param textPosition
	 * @param pdfFileName
	 * @param encode
	 * @param returnType
	 * @return
	 */
	@RequestMapping(value = "/convert", method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE},
			produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PDF_VALUE})
	@ApiOperation(value = "Create a BarCode file.",
			notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "access_key") String accessKey,
			@RequestParam(required = true, name = "file-urls") String fileUrls,
			@RequestParam(required = false, name = "pdf-file-name") String pdfFileName,
			@RequestParam(required = true, name = "return_type") String returnType) {
		com.indezer.api.util.Response responseStatus = new com.indezer.api.util.Response();
		String errors = "";
		try {
			// step-1 : check access_key
			accessKeyStatus = mergePdfFilesService.checkAccessKey(accessKey);
			if (accessKeyStatus) {
				fileNameMerged = pdfFileName != null ? pdfFileName : UUID.randomUUID() + ".pdf";
				File pdfFile = mergePdfFilesService.docToPdf(fileUrls, fileNameMerged);
				HttpHeaders headers = new HttpHeaders();
				headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
				headers.add("Pragma", "no-cache");
				headers.add("Expires", "0");
				ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(pdfFile);
				headers.add("Content-Disposition", "inline; filename=" + pdfFile);

				if (org.apache.commons.lang3.StringUtils.equals(returnType, "JSON")) {
					return getResponseMessage(responseStatus, "200", IndezerConstant.PDF_MERGED_MESSAGE, HttpStatus.OK, pdfFile.getName(), IndezerUtil.getFileSizeKiloBytes(pdfFile), UUID.randomUUID().toString(), null);
				} else if (org.apache.commons.lang3.StringUtils.equals(returnType, "PDF")) {
					return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(
							bis));
				}
			} else {
				// access key is KO
				errors = "error occurred";
				return getResponseMessage(responseStatus, "404", IndezerConstant.BAD_REQUEST_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, errors);
			}
		} catch (Exception e) {
			e.fillInStackTrace();
		}
		return null;
	}
	
	/**
	 * @param responseStatus
	 * @param code
	 * @param message
	 * @param badRequest
	 * @param errors
	 * @return
	 */
	private ResponseEntity<?> getResponseMessage(com.indezer.api.util.Response responseStatus, String code,
			String message, HttpStatus badRequest, String doc, String size, String transactionId, String errors) {
		responseStatus.setCode(code);
		responseStatus.setMessage(message);
		responseStatus.setDocument(doc);
		responseStatus.setSize(size);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Instant instant = timestamp.toInstant();
		responseStatus.setTimestamp(instant.toString());
		responseStatus.setStatus(badRequest);
		responseStatus.setDocument_id(transactionId);
		return new ResponseEntity<Object>(responseStatus, HttpStatus.BAD_REQUEST);
	}

}
