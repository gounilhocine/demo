//package com.indezer.api.datasource.entity;
//
//import java.util.Set;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.FetchType;
//import javax.persistence.JoinColumn;
//import javax.persistence.JoinTable;
//import javax.persistence.ManyToMany;
//import javax.persistence.Table;
//import javax.persistence.UniqueConstraint;
//
//import lombok.Getter;
//import lombok.Setter;
//import lombok.ToString;
//
//@Getter
//@Setter
//@ToString
//@Entity
//@Table(name = "User", uniqueConstraints = @UniqueConstraint(columnNames = {"id"}))
//public class User extends BaseEntity {
//
//	/**
//	 * serialVersionUID.
//	 */
//	private static final long serialVersionUID = 137920236030223616L;
//
//	@Column(unique = true, nullable = false, length = 250)
//	private String firstName;
//	
//	@Column(unique = false, nullable = false, length = 50)
//	private String accessKey;
//
//	@Column(unique = false, nullable = false, length = 50)
//	private String lastName;
//
//	@Column(unique = true, nullable = false, length = 50)
//	private String email;
//
//	@Column(unique = false, nullable = true, length = 50)
//	private String phone;
//
//	@Column(unique = false, nullable = false, length = 250)
//	private String password;
//
//	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
//	private Boolean newsLetter;
//
//	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
//	private Boolean newsSellingBuying;
//
//	@Column(unique = false, nullable = true, length = 1, columnDefinition = "boolean default false")
//	private Boolean commentsAdsEnabled;
//
//	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinTable(name = "USERS_ROLES", joinColumns = @JoinColumn(name = "USER_ID", referencedColumnName = "ID"),
//			inverseJoinColumns = @JoinColumn(name = "ROLE_ID", referencedColumnName = "id"))
//	private Set<Role> roles;
//}
