package com.indezer.api.doc;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;

public class PptToPDFConverter extends PptxToPDFConverter {

	private List<XSLFSlide> slides;

	public PptToPDFConverter(InputStream inStream, OutputStream outStream, boolean showMessages,
			boolean closeStreamsWhenComplete) {
		super(inStream, outStream, showMessages, closeStreamsWhenComplete);
	}

	@Override
	protected void drawOntoThisGraphic(int index, Graphics2D graphics) {
		slides.get(index).draw(graphics);
	}

	@Override
	protected int getNumSlides() {
		return slides.size();
	}

	@Override
	protected Color getSlideBGColor(int index) {
		return slides.get(index).getBackground().getFillColor();
	}

	@Override
	protected Dimension processSlides() throws IOException {
		XMLSlideShow ppt = new XMLSlideShow(inStream);
		Dimension dimension = ppt.getPageSize();
		slides = ppt.getSlides();
		return dimension;
	}

}
