package com.indezer.api.api.rest;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.api.service.BarCodeService;
import com.indezer.api.util.GeneratePdfReport;
import com.indezer.api.util.IndezerConstant;
import com.indezer.api.util.IndezerUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1.0/barCode")
@Api(tags = {"barCode"})
public class BarCodeController extends AbstractRestHandler {

	@Autowired
	private BarCodeService barCodeService;

	private boolean accessKeyStatus;

	private String barCodeFileName;

	@Value("${barCodeFiles.folder}")
	private String barCodeFiles;

	@RequestMapping(value = "/create", method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE},
			produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PDF_VALUE})
	@ApiOperation(value = "Create a BarCode file.",
			notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "access_key") String accessKey,
			@RequestParam(required = true, name = "code") String code,
			@RequestParam(required = false, name = "barcode-type") String barcodeType,
			@RequestParam(required = false, name = "heigh") Double heigh,
			@RequestParam(required = false, name = "width") Double width,
			@RequestParam(required = false, name = "dpi") Integer dpi,
			@RequestParam(required = false, name = "font-size") Double fontSize,
			@RequestParam(required = false, name = "text-position") String textPosition,
			@RequestParam(required = false, name = "image-name", defaultValue = "barcode.jpeg") String imageName,
			@RequestParam(required = false, name = "encode", defaultValue = "false") Boolean encode,
			@RequestParam(required = true, name = "return_type") String returnType) {
		com.indezer.api.util.Response responseStatus = new com.indezer.api.util.Response();
		String errors = "";
		try {
			// step-1 : check access_key
			accessKeyStatus = barCodeService.checkAccessKey(accessKey);
			if (accessKeyStatus) {
				barCodeFileName = imageName != null ? imageName : UUID.randomUUID() + ".png";
				dpi = dpi == null ? 120 : dpi;
				File imgFile =
						barCodeService.create(barcodeType, code, heigh, width, dpi, fontSize, barCodeFiles.concat(barCodeFileName), encode, textPosition);
				HttpHeaders headers = new HttpHeaders();
				headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
				headers.add("Pragma", "no-cache");
				headers.add("Expires", "0");
				ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(imgFile);
				headers.add("Content-Disposition", "inline; filename=" + imgFile);

				if (org.apache.commons.lang3.StringUtils.equals(returnType, "JSON")) {
					return getResponseMessage(responseStatus, "200", IndezerConstant.BARCODE_CREATED_MESSAGE, HttpStatus.OK, imgFile.getName(), IndezerUtil.getFileSizeKiloBytes(imgFile), UUID.randomUUID().toString(), null);
				} else if (org.apache.commons.lang3.StringUtils.equals(returnType, "IMG")) {
					return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG).body(new InputStreamResource(
							bis));
				}
			} else {
				// access key is KO
				errors = "error occurred";
				return getResponseMessage(responseStatus, "404", IndezerConstant.BAD_REQUEST_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, errors);
			}
		} catch (Exception e) {
			e.fillInStackTrace();
		}
		return null;
	}
	/**
	 * @param responseStatus
	 * @param code
	 * @param message
	 * @param badRequest
	 * @param errors
	 * @return
	 */
	private ResponseEntity<?> getResponseMessage(com.indezer.api.util.Response responseStatus, String code,
			String message, HttpStatus badRequest, String doc, String size, String transactionId, String errors) {
		responseStatus.setCode(code);
		responseStatus.setMessage(message);
		responseStatus.setDocument(doc);
		responseStatus.setSize(size);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Instant instant = timestamp.toInstant();
		responseStatus.setTimestamp(instant.toString());
		responseStatus.setStatus(badRequest);
		responseStatus.setDocument_id(transactionId);
		return new ResponseEntity<Object>(responseStatus, HttpStatus.BAD_REQUEST);
	}
}
