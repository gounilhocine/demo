package com.indezer.api.util;

import java.io.File;

public class IndezerUtil {

	public static String getFileSizeMegaBytes(File file) {
		return (double) file.length() / (1024 * 1024) + " mb";
	}
	
	public static String getFileSizeKiloBytes(File file) {
		return (double) file.length() / 1024 + "  kb";
	}

	public static String getFileSizeBytes(File file) {
		return file.length() + " bytes";
	}
}
