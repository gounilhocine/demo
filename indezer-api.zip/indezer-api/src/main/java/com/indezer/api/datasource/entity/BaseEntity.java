//package com.indezer.api.datasource.entity;
//
//import java.io.Serializable;
//import java.util.Date;
//
//import javax.persistence.Column;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.MappedSuperclass;
//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;
//
//import lombok.Getter;
//import lombok.Setter;
//import lombok.ToString;
//
//@Getter
//@Setter
//@ToString
//@MappedSuperclass
//public abstract  class BaseEntity implements Serializable {
//
//	/**
//	 * serialVersionUID.
//	 */
//	private static final long serialVersionUID = 1748991677379910421L;
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private Long id;
//
//	@Column(columnDefinition = "DATETIME")
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date createDate;
//
//	@Column(columnDefinition = "DATETIME")
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date updateDate;
//
//}
