package com.indezer.api.service;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.indezer.api.util.ReadPdfFileFromUrl;

@Service
public class MergePdfFilesService {

	@Value("${pdfMergedFiles.folder}")
	private String pdfMergedFiles;

	public boolean checkAccessKey(String accessKey) { return true; }

	/**
	 * @param path
	 * @return
	 */
	private String createFolder(String path) {
		File dir = new File(pdfMergedFiles.concat(File.separator).concat(path));
		if (!dir.exists()) {
			dir.mkdir();
			return path;
		}
		return null;
	}

	/**
	 * @param fileUrls
	 * @param pdfFileName
	 * @return
	 * @throws IOException
	 */
	public File docToPdf(String fileUrls, String pdfFileName) throws IOException {
		// Files
		List<File> files = new ArrayList<File>();

		// Directory
		String dir = pdfMergedFiles.concat(createFolder(UUID.randomUUID().toString()));

		// Save Files
		String[] fileUrlTab = fileUrls.split(",");
		for (String path : fileUrlTab) {
			URL url = new URL(path);
			byte[] a = ReadPdfFileFromUrl.getArrayFromInputStream(url.openStream());
			ReadPdfFileFromUrl.writeContent(a, dir.concat(File.separator).concat(UUID.randomUUID().toString()).concat(".pdf"), files);
		}

		// Merge Files
		PDFMergerUtility pdfMerger = new PDFMergerUtility();
		pdfMerger.setDestinationFileName(pdfFileName);
		PDDocumentInformation documentInformation = new PDDocumentInformation();
		documentInformation.setTitle("Apache PdfBox Merge PDF Documents");
		documentInformation.setCreator("indezer.com");
		documentInformation.setSubject("Merging PDF documents API");
		for (File f : files) {
			pdfMerger.addSource(f);
		}
		pdfMerger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());

		return new File(pdfFileName);
	}

}
