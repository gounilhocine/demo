package com.indezer.api.api.rest;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.api.dto.HtmlToPdfDto;
import com.indezer.api.service.HtmlToPdfService;
import com.indezer.api.util.GeneratePdfReport;
import com.indezer.api.util.IndezerConstant;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1.0/html2pdf/")
@Api(tags = {"html2pdf"})
public class HtmlToPdfController extends AbstractRestHandler {

	@Autowired
	private HtmlToPdfService htmlToPdfService;

	private String htmlFileName;

	private String pdfFileName;

	private boolean pdfCreationOk;

	private boolean accessKeyStatus;

	private int htmlUrlStatus;

	private ClassPathResource pdfFile;

	@Value("${pdfFiles.folder}")
	private String pdfFiles;

	/**
	 * @param ex
	 * @param request
	 * @return
	 */
	// @ExceptionHandler({Exception.class})
	// public ResponseEntity<?> handleAll(Exception ex, WebRequest request) {
	// com.indezer.api.util.ResponseStatus responseStatus = new com.indezer.api.util.ResponseStatus();
	// List<String> errors = new ArrayList<String>();
	// errors.add("error occurred");
	// return getResponseMessage(responseStatus, "400", IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, errors);
	// }

	/**
	 * curl -H "Content-Type: application/json" -X POST "http://localhost:81/api/v1.0/html2pdf/convert?access_key=test&html_url=ee"
	 */

	/**
	 * @param accessKey
	 * @param htmlUrl
	 * @param htmlPage
	 * @param pdfName
	 * @param customUnit
	 * @param userAgent
	 * @param acceptLang
	 * @param textEncoding
	 * @param ttl
	 * @param encryption
	 * @param ownerPassword
	 * @param userPassword
	 * @param authUser
	 * @param authPass
	 * @param inline
	 * @param force
	 * @param pageSize
	 * @param pageNumbers
	 * @param pageWidth
	 * @param pageHeight
	 * @param orientation
	 * @param marginop
	 * @param marginBottom
	 * @param marginLeft
	 * @param marginRight
	 * @param headerSpacing
	 * @param headerText
	 * @param headerAlign
	 * @param headerUrl
	 * @param headerHtml
	 * @param footerSpacing
	 * @param footerText
	 * @param footerAlign
	 * @param footerUrl
	 * @param footerHtml
	 * @param viewport
	 * @param cssUrl
	 * @param disableExternalLinks
	 * @param disableInternalLinks
	 * @param keepImagesTogether
	 * @param disableJavascript
	 * @param delay
	 * @param dpi
	 * @param zoom
	 * @param watermarkUrl
	 * @param watermarkOffsetX
	 * @param watermarkOffsetY
	 * @param watermarkOpacity
	 * @param watermarkInBackground
	 * @param pdfTitle
	 * @param pdfSubject
	 * @param pdfCreator
	 * @param pdfAuthor
	 * @param pdfCreationDate
	 * @param request
	 * @param response
	 * @param ex
	 * @param headers
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/convert", method = RequestMethod.POST, consumes = {MediaType.APPLICATION_JSON_VALUE},
			produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_PDF_VALUE})
	@ApiOperation(value = "Create a pdf file from html.",
			notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "access_key") String accessKey,
			@RequestParam(required = true, name = "html_url") String htmlUrl,
			@RequestParam(required = true, name = "html_page") String htmlPage,
			@RequestParam(required = true, name = "return_type") String returnType,
			// Configuration
			@RequestParam(required = false, name = "pdf_name") String pdfName,
			@RequestParam(required = false, name = "custom_unit") String customUnit,
			@RequestParam(required = false, name = "user_agent") String userAgent,
			@RequestParam(required = false, name = "accept_lang") String acceptLang,
			@RequestParam(required = false, name = "text_encoding") String textEncoding,
			@RequestParam(required = false, name = "ttl") String ttl,
			@RequestParam(required = false, name = "collate") Boolean collate,
			@RequestParam(required = false, name = "encryption") String encryption,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "user_password") String userPassword,
			@RequestParam(required = false, name = "auth_user") String authUser,
			@RequestParam(required = false, name = "auth_pass") String authPass,
			@RequestParam(required = false, name = "inline") String inline,
			@RequestParam(required = false, name = "force") String force,
			// Layout
			@RequestParam(required = false, name = "page_size") String pageSize,
			@RequestParam(required = false, name = "color_mode") String colorMode,
			@RequestParam(required = false, name = "compression") Boolean compression,
			@RequestParam(required = false, name = "imageQuality") Integer imageQuality,
			@RequestParam(required = false, name = "page_numbers") Boolean pageNumbers,
			@RequestParam(required = false, name = "page_width") String pageWidth,
			@RequestParam(required = false, name = "page_height") String pageHeight,
			@RequestParam(required = false, name = "orientation") String orientation,
			@RequestParam(required = false, name = "outline") Boolean outline,
			@RequestParam(required = false, name = "outlineDepth") Integer outlineDepth,
			@RequestParam(required = false, name = "margin_top") String marginop,
			@RequestParam(required = false, name = "margin_bottom") String marginBottom,
			@RequestParam(required = false, name = "margin_left") String marginLeft,
			@RequestParam(required = false, name = "margin_right") String marginRight,
			@RequestParam(required = false, name = "header_spacing") String headerSpacing,
			@RequestParam(required = false, name = "header_text") String headerText,
			@RequestParam(required = false, name = "header_align") String headerAlign,
			@RequestParam(required = false, name = "header_url") String headerUrl,
			@RequestParam(required = false, name = "header_html") String headerHtml,
			@RequestParam(required = false, name = "footer_spacing") String footerSpacing,
			@RequestParam(required = false, name = "footer_text") String footerText,
			@RequestParam(required = false, name = "footer_align") String footerAlign,
			@RequestParam(required = false, name = "footer_url") String footerUrl,
			@RequestParam(required = false, name = "footer_html") String footerHtml,
			@RequestParam(required = false, name = "viewport") String viewport,
			// customization
			@RequestParam(required = false, name = "css_url") String cssUrl,
			@RequestParam(required = false, name = "disable_external_links") Boolean disableExternalLinks,
			@RequestParam(required = false, name = "disable_internal_links") String disableInternalLinks,
			@RequestParam(required = false, name = "keep_images_together") String keepImagesTogether,
			@RequestParam(required = false, name = "disable_javascript") Boolean disableJavascript,
			@RequestParam(required = false, name = "delay") String delay,
			@RequestParam(required = false, name = "dpi") Integer dpi,
			@RequestParam(required = false, name = "image_dpi") Integer imageDpi,
			@RequestParam(required = false, name = "load_images") Boolean loadImages,
			@RequestParam(required = false, name = "zoom_factor") Float zoomFactor,
			@RequestParam(required = false, name = "watermark_url") String watermarkUrl,
			@RequestParam(required = false, name = "watermark_offset_x") String watermarkOffsetX,
			@RequestParam(required = false, name = "watermark_offset_y") String watermarkOffsetY,
			@RequestParam(required = false, name = "watermark_opacity") String watermarkOpacity,
			@RequestParam(required = false, name = "watermark_in_background") String watermarkInBackground,
			// document details
			@RequestParam(required = false, name = "pdf_title") String pdfTitle,
			@RequestParam(required = false, name = "pdf_subject") String pdfSubject,
			@RequestParam(required = false, name = "pdf_creator") String pdfCreator,
			@RequestParam(required = false, name = "pdf_author") String pdfAuthor,
			@RequestParam(required = false, name = "pdf_creation_date") String pdfCreationDate,
			MethodArgumentNotValidException ex) throws IOException {

		com.indezer.api.util.Response responseStatus = new com.indezer.api.util.Response();
		String errors = "";
		try {
			HtmlToPdfDto dto = new HtmlToPdfDto(htmlUrl, htmlPage, pdfName, customUnit, userAgent, acceptLang,
					textEncoding, ttl, collate, encryption, ownerPassword, userPassword, authUser, authPass, inline,
					force, pageSize, colorMode, compression, imageQuality, pageNumbers, pageWidth, pageHeight,
					orientation, outline, outlineDepth, marginop, marginBottom, marginLeft, marginRight, headerSpacing,
					headerText, headerAlign, headerUrl, headerHtml, footerSpacing, footerText, footerAlign, footerUrl,
					footerHtml, viewport, cssUrl, disableExternalLinks, disableInternalLinks, keepImagesTogether,
					disableJavascript, delay, dpi, imageDpi, loadImages, zoomFactor, watermarkUrl, watermarkOffsetX,
					watermarkOffsetY, watermarkOpacity, watermarkInBackground, pdfTitle, pdfSubject, pdfCreator,
					pdfAuthor, pdfCreationDate);
			// step-1 : check access_key
			accessKeyStatus = htmlToPdfService.checkAccessKey(accessKey);
			// Check Return Type Data
			if (!StringUtils.equalsIgnoreCase(returnType, "PDF") && !StringUtils.equalsIgnoreCase(returnType, "JSON")) {
				return getResponseMessage(responseStatus, "404", IndezerConstant.BAD_REQUEST_REURN_TYPE_NOT_VALID, HttpStatus.BAD_REQUEST, errors);
			}
			if (accessKeyStatus) {
				// step-2 : check HTML URL
				htmlUrlStatus = htmlToPdfService.checkHtmlUrl(dto, htmlUrl);
				if (htmlUrlStatus == 200) {
					// step-3 : call, copy & parse HTML code
					htmlFileName = htmlToPdfService.parseHtmlUrl(dto);
					// step-4 : convert HTML code to PDF

					pdfFileName = dto.getPdfName() != null ? dto.getPdfName() : UUID.randomUUID() + ".pdf";
					pdfCreationOk = htmlToPdfService.createPdf(dto, htmlFileName, pdfFiles.concat(pdfFileName));
					// step-5 : send response
					if (pdfCreationOk) {
						if (org.apache.commons.lang3.StringUtils.equals(returnType, "JSON")) {
							return getResponseMessage(responseStatus, "200", IndezerConstant.PDF_CREATED_MESSAGE, HttpStatus.OK, null);
						} else if (org.apache.commons.lang3.StringUtils.equals(returnType, "PDF")) {
							HttpHeaders headers = new HttpHeaders();
							headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
							headers.add("Pragma", "no-cache");
							headers.add("Expires", "0");
							ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(new File(
									pdfFiles.concat(pdfFileName)));
							headers.add("Content-Disposition", "inline; filename=" + pdfFileName);
							return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(
									bis));
						}
					} else {
						// pdfCreationOk is KO
						errors = "error occurred";
						return getResponseMessage(responseStatus, "404", IndezerConstant.PDF_NOT_CREATED_MESSAGE, HttpStatus.BAD_REQUEST, errors);
					}
				} else {
					// htmlUrlStatus is KO
					errors = "error occurred";
					return getResponseMessage(responseStatus, "400", IndezerConstant.BAD_URL_OR_CREDENTIALS_MESSAGE, HttpStatus.BAD_REQUEST, errors);
				}

			} else {
				// access key is KO
				errors = "error occurred";
				return getResponseMessage(responseStatus, "404", IndezerConstant.BAD_REQUEST_MESSAGE, HttpStatus.BAD_REQUEST, errors);
			}
		} catch (Exception e) {
			errors = "error occurred : " + e.fillInStackTrace().toString();
			return getResponseMessage(responseStatus, "500", IndezerConstant.TECHNICAL_ERROR, HttpStatus.INTERNAL_SERVER_ERROR, errors);
		}
		return null;

	}

	/**
	 * @param responseStatus
	 * @param code
	 * @param message
	 * @param badRequest
	 * @param errors
	 * @return
	 */
	private ResponseEntity<?> getResponseMessage(com.indezer.api.util.Response responseStatus, String code,
			String message, HttpStatus badRequest, String errors) {
		responseStatus.setCode(code);
		responseStatus.setMessage(message);
		responseStatus.setStatus(badRequest);
		responseStatus.setError(errors);
		return new ResponseEntity<Object>(responseStatus, HttpStatus.BAD_REQUEST);
	}

}
