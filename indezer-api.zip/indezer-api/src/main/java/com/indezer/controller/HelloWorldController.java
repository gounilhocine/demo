package com.indezer.controller;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/v1.0/")
@CrossOrigin()
public class HelloWorldController {

	@RequestMapping({ "/hello" })
	public String hello() {
		return "Hello World";
	}
	
	@RequestMapping({ "/getFile" })
	public String getFile() {
		try {
			URL url = new URL("https://www.cours-gratuit.com/" + URLEncoder.encode("cours-spring/tutoriel-de-spring-pas-a-pas-en-pdf/download?chk=4ffcfbe73a84bf595b0a71f51809903f", StandardCharsets.UTF_8.name()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "File copied";
	}

}
