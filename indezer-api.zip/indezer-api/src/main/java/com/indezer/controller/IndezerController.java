package com.indezer.controller;

import java.io.File;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.config.jms.EmailMessageProducer;
import com.indezer.datasource.entity.Document;
import com.indezer.datasource.entity.Email;
import com.indezer.datasource.entity.User;
import com.indezer.service.api.IndezerService;
import com.indezer.service.auth.UserService;
import com.indezer.util.CreditResponse;
import com.indezer.util.IndezerConstant;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/")
@Api(tags = { "indezer" })
public class IndezerController extends AbstractRestHandler {

	@Autowired
	protected UserService userDetailsService;

	@Autowired
	protected IndezerService indezerService;

	@Value("${barcode.files.folder}")
	private String barCodeFiles;

	@Value("${html.files.folder}")
	private String htmlPdfFiles;

	@Value("${qrcode.files.folder}")
	private String qrCodeFiles;

	@Value("${merge.pdfs.files.folder}")
	private String mergePdfsFiles;

	@Value("${merge.docs.files.folder}")
	private String mergeDocsFiles;

	@Value("${url.to.image.files.folder}")
	private String urlToImageFiles;

	@Value("${image.converter.files.folder}")
	private String imageConverterFiles;

	@Value("${doc.to.pdf.files.folder}")
	private String docToPdfFiles;

	@RequestMapping(value = "/delete", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Delete", notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "document_id") String documentId) {
		com.indezer.util.Response responseStatus = new com.indezer.util.Response();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			User user = userDetailsService.getUser(authentication.getName());
			if (user != null) {
				File docFile = null;
				Document doc = indezerService.findDocumentByDocKey(documentId);
				switch (doc.getOperationType()) {
				case DOC_PDF:
					docFile = new File(docToPdfFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case BAR_CODE:
					docFile = new File(barCodeFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case QR_CODE:
					docFile = new File(qrCodeFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case HTML_PDF:
					docFile = new File(htmlPdfFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case IMG_IMG:
					docFile = new File(
							imageConverterFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case MERGE_PDF:
					docFile = new File(mergePdfsFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case MERGE_DOCS:
					docFile = new File(mergeDocsFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				case URL_IMG:
					docFile = new File(htmlPdfFiles.concat(user.getDirectory().concat("/").concat(doc.getDocName())));
					break;
				default:
					break;
				}
				if (docFile.exists()) {
					// delete
					docFile.delete();
					doc.setDeleted(true);
					indezerService.saveDocument(doc);
					return getResponseMessage(responseStatus, HttpStatus.OK.value(),
							IndezerConstant.DOCUMENT_DELETED_MESSAGE, HttpStatus.OK, doc.getUrl(),
							doc.getSize() + " MB", doc.getDocKey(), null);
				} else {
					return getResponseMessage(responseStatus, HttpStatus.NOT_FOUND.value(),
							IndezerConstant.DOCUMENT_NOT_FOUND, HttpStatus.NOT_FOUND, doc.getUrl(), null,
							doc.getDocKey(), null);
				}
			}
		}
		return null;
	}

	@Autowired
	// private EmailMessageProducer emailMessageProducer;
	//
	// @Value("${activemq.queue}")
	// private String emailQueue;
	//

	/**
	 * @param documentId
	 * @return
	 */
	@RequestMapping(value = "/credit", method = RequestMethod.GET, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Credit", notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> credit() {
		CreditResponse creditResponse = new CreditResponse();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			User user = userDetailsService.getUser(authentication.getName());
			if (user != null) {
				creditResponse.setTimestamp(new Date());
				creditResponse.setCredit(user.getCredit() + " MB");
				creditResponse.setStatus(HttpStatus.OK.toString());
				creditResponse.setMessage(IndezerConstant.CREDIT_FOUND_MESSAGE);
				return new ResponseEntity<Object>(creditResponse, HttpStatus.OK);
			}
		}
		return null;
	}

	// @JmsListener(destination = "${activemq.queue}", containerFactory =
	// "jmsFactory")
	// @RequestMapping(value = "/sendEmail", method = RequestMethod.POST, consumes =
	// {
	// MediaType.APPLICATION_JSON_VALUE }, produces = {
	// MediaType.APPLICATION_JSON_VALUE,
	// MediaType.APPLICATION_PDF_VALUE })
	// public void sendEmail(Email student) {
	// emailMessageProducer.sendTo(emailQueue, student);
	// log.info("Consumer> " + student);
	// }
}
