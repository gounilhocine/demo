package com.indezer.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;
import java.util.zip.DataFormatException;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;

import com.indezer.datasource.entity.User;
import com.indezer.exception.ResourceNotFoundException;
import com.indezer.service.auth.UserService;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum.AccountType;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;
import com.indezer.util.RestErrorInfo;

/**
 * This class is meant to be extended by all REST resource "controllers". It
 * contains exception mapping and other common REST API functionality
 */
// @ControllerAdvice?
public abstract class AbstractRestHandler implements ApplicationEventPublisherAware {

	protected final Logger log = LoggerFactory.getLogger(this.getClass());
	protected ApplicationEventPublisher eventPublisher;

	@Autowired
	protected UserService userDetailsService;

	protected Response responseStatus = new Response();

	@Value("${static.path.folder}")
	protected String staticPathDir;

	protected static final String DEFAULT_PAGE_SIZE = "100";
	protected static final String DEFAULT_PAGE_NUM = "0";

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(DataFormatException.class)
	public @ResponseBody RestErrorInfo handleDataStoreException(DataFormatException ex, WebRequest request,
			HttpServletResponse response) {
		log.info("Converting Data Store exception to RestResponse : " + ex.getMessage());

		return new RestErrorInfo(ex, "You messed up.");
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(ResourceNotFoundException.class)
	public @ResponseBody RestErrorInfo handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest request,
			HttpServletResponse response) {
		log.info("ResourceNotFoundException handler:" + ex.getMessage());

		return new RestErrorInfo(ex, "Sorry I couldn't find it.");
	}

	/**
	 * @param docFileUrl
	 * @param file
	 * @param responseStatus
	 * @param user
	 * @param fileTemp
	 * @param ext
	 * @return
	 * @throws IOException
	 * @throws MalformedURLException
	 */
	protected ResponseEntity<?> checkFileSize(String docFileUrl, MultipartFile file, Response responseStatus, User user,
			File fileTemp, String ext) throws IOException, MalformedURLException {
		if (StringUtils.isEmpty(docFileUrl) && file == null) {
			return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
					IndezerConstant.FILE_OR_URL_REQUIRED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, null);
		} else {
			if (file != null) {
				fileTemp = new File(getStaticFolderPath(user).concat(File.separator)
						.concat("temp_" + UUID.randomUUID() + "." + ext));
				file.transferTo(fileTemp);
				if (IndezerUtil.getFileSizeMegaBytes(fileTemp) > 300) {
					return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
							IndezerConstant.FILE_OUT_SIZE_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
							null);
				}
			} else if (StringUtils.isNoneEmpty(docFileUrl)) {

				URL url = new URL(docFileUrl);
				InputStream in = url.openStream();
				File targetFile = new File(getStaticFolderPath(user).concat(File.separator)
						.concat("temp_" + UUID.randomUUID() + "." + ext));
				OutputStream outStream = new FileOutputStream(targetFile);

				byte[] buffer = new byte[8 * 1024];
				int bytesRead;
				while ((bytesRead = in.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				in.close();
				outStream.close();
				if (IndezerUtil.getFileSizeMegaBytes(targetFile) > 300) {
					targetFile.delete();
					return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
							IndezerConstant.FILE_OUT_SIZE_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
							null);
				}
			}
		}
		return null;
	}

	/**
	 * @param user
	 * @param createdDate
	 * @return
	 */
	public String getStaticFolderPath(User user) {
		String dir = IndezerUtil.getFolderPath(staticPathDir, user, "yyyyMMdd");
		File dayDirectory = new File(dir);
		if (!dayDirectory.exists()) {
			dayDirectory.mkdirs();
			IndezerUtil.directoryProperties(dayDirectory);
		}
		return dir;
	}

	/**
	 * @param serverReference
	 * @param returnType
	 * @param test
	 * @param responseStatus
	 * @param user
	 * @return
	 */
	public ResponseEntity<?> checkAccessToApi(String serverReference, String returnType, Boolean test,
			com.indezer.util.Response responseStatus, User user) {
		// Check returnType
		if (StringUtils.isNotEmpty(returnType) && !checkReturnType(returnType)) {
			return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
					IndezerConstant.NO_CONTENT_RETURN_TYPE_MESSAGE, HttpStatus.NO_CONTENT, null, null, null, null);
		} else if (StringUtils.isNotEmpty(returnType) && StringUtils.isEmpty(serverReference)
				&& ReturnType.TF.toString().equalsIgnoreCase(returnType)) {
			return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
					IndezerConstant.NO_CONTENT_SERVER_REFERENCE_MESSAGE, HttpStatus.NO_CONTENT, null, null, null, null);
		}

		// check credit
		if (!test && !checkCredit(user)) {
			return getResponseMessage(responseStatus, HttpStatus.PAYMENT_REQUIRED.value(),
					IndezerConstant.PAYMENT_REQUIRED_MESSAGE, HttpStatus.PAYMENT_REQUIRED, null, null, null, null);
		}

		// check test credit
		if (test && !checkTestCredit(user)) {
			return getResponseMessage(responseStatus, HttpStatus.NOT_EXTENDED.value(),
					IndezerConstant.PAYMENT_REQUIRED_MESSAGE, HttpStatus.NOT_EXTENDED, null, null, null, null);
		}
		return null;
	}

	/**
	 * @param returnType
	 * @return
	 */
	public boolean checkReturnType(String returnType) {
		return ReturnType.valueOf(returnType) == null ? false : true;
	}

	/**
	 * @param userName
	 * @param imgFile
	 * @return
	 */
	public String getUrlFile(String userName, File imgFile) {
		return IndezerConstant.INDEZER_WEB_URL
				.concat(getUser(userName).getDirectory().concat("/").concat(imgFile.getName()));
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		this.eventPublisher = applicationEventPublisher;
	}

	// todo: replace with exception mapping
	public static <T> T checkResourceFound(final T resource) {
		if (resource == null) {
			throw new ResourceNotFoundException("resource not found");
		}
		return resource;
	}

	/**
	 * @param responseStatus
	 * @param code
	 * @param message
	 * @param status
	 * @param errors
	 * @return
	 */
	public ResponseEntity<?> getResponseMessage(com.indezer.util.Response responseStatus, int code, String message,
			HttpStatus status, String doc, String size, String documentId, String errors) {
		responseStatus.setCode(code);
		responseStatus.setMessage(message);
		responseStatus.setDocument(doc);
		responseStatus.setSize(size);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Instant instant = timestamp.toInstant();
		responseStatus.setTimestamp(instant.toString());
		responseStatus.setStatus(status);
		responseStatus.setError(errors);
		responseStatus.setDocument_id(documentId);
		return new ResponseEntity<Object>(responseStatus, status);
	}

	/**
	 * @param username
	 * @return
	 */
	protected User getUser(String username) {
		return userDetailsService.getUser(username);
	}

	/**
	 * @param user
	 * @return
	 */
	protected boolean checkCredit(User user) {
		return user.getCredit() == 0d ? false : true;
	}

	/**
	 * @param user
	 * @return
	 */
	protected boolean checkTestCredit(User user) {
		return user.getTestCredit() == 0d ? false : true;
	}

	/**
	 * @param user
	 * @return
	 */
	protected boolean checkAccountType(User user) {
		return user.getAccountType() == AccountType.FREE ? false : true;
	}
	
	/**
	 * Get Input File.
	 * 
	 * @param pdfFileUrl
	 * @param pdfFile
	 * @param user
	 * @param inputTempPdfFile
	 * @return
	 * @throws Exception
	 */
	protected ResponseEntity<?> getInputPdfFile(String pdfFileUrl, MultipartFile pdfFile, User user,
			File inputTempPdfFile) throws Exception {
		String dir = getStaticFolderPath(user);
		if (pdfFile != null) {
			inputTempPdfFile = new File(dir.concat(File.separator).concat("temp_" + UUID.randomUUID() + ".pdf"));
			pdfFile.transferTo(inputTempPdfFile);
		} else if (StringUtils.isNoneEmpty(pdfFileUrl)) {
			URL url = new URL(pdfFileUrl);
			InputStream in = url.openStream();
			inputTempPdfFile = new File(dir.concat(File.separator).concat("temp_" + UUID.randomUUID() + ".pdf"));
			OutputStream outStream = new FileOutputStream(inputTempPdfFile);

			byte[] buffer = new byte[8 * 1024];
			int bytesRead;
			while ((bytesRead = in.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}
			in.close();
			outStream.close();
		}

		// Check ext file
		if (!IndezerConstant.PDF.equalsIgnoreCase(FilenameUtils.getExtension(inputTempPdfFile.getName()))) {
			inputTempPdfFile.deleteOnExit();
			return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
					IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, null);
		}

		if (IndezerUtil.getFileSizeMegaBytes(inputTempPdfFile) > 300) {
			inputTempPdfFile.delete();
			return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
					IndezerConstant.FILE_OUT_SIZE_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null, null);
		}
		return null;
	}


}