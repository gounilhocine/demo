package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.service.api.PdfConverterService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum.PdfTODocFileType;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerMap;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/pdf")
@Api(tags = { "PdfConverter" })
public class PdfConverterController extends AbstractRestHandler {

	@Autowired
	private PdfConverterService pdfService;

	/**
	 * Merge PDF Files.
	 * 
	 * @param accessKey
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param textPosition
	 * @param pdfFileName
	 * @param encode
	 * @param returnType
	 * @return
	 */
	@RequestMapping(value = "/mergePdfs", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Merge pdfs files.", notes = "Returns the URL/PDF.")
	public ResponseEntity<?> mergePdfs(@RequestParam(required = true, name = "file_urls") String fileUrls,
			@RequestParam(required = false, name = "pdf_files") MultipartFile[] pdfFiles,
			@RequestParam(required = false, name = "pdf_file_name") String pdfFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Response responseStatus = new Response();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			test = test == null ? false : test;
			List<File> fileTemps = null;

			// set file options
			pdfService.setFileOptions(zipFile, ownerPassword, emailTo);

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check required parameters
			checkPdfsFile(pdfFiles, fileUrls, responseStatus, user, fileTemps);

			pdfFileName = pdfFileName != null ? pdfFileName : UUID.randomUUID() + ".pdf";
			File pdfFile = pdfService.mergePdfs(fileTemps, pdfFileName, docKey, user, watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(pdfFile);
			headers.add("Content-Disposition", "inline; filename=" + pdfFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.PDF_MERGED_MESSAGE,
						HttpStatus.OK, pdfFile.getName(), IndezerUtil.getFileSizeKiloBytes(pdfFile) + "  KB", docKey,
						null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = pdfService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), pdfFile),
							IndezerUtil.getFileSizeMegaBytes(pdfFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(pdfFile.getPath(), pdfFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.PDF_FILE_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), pdfFile),
						IndezerUtil.getFileSizeMegaBytes(pdfFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * Compare PDF Files.
	 * 
	 * @param accessKey
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param textPosition
	 * @param pdfFileName
	 * @param encode
	 * @param returnType
	 * @return
	 */
	@RequestMapping(value = "/comparePdfs", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Merge pdfs files.", notes = "Returns the URL/PDF.")
	public ResponseEntity<?> comparePdfs(@RequestParam(required = true, name = "file_urls") String fileUrls,
			@RequestParam(required = false, name = "pdf_files") MultipartFile[] pdfFiles,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Response responseStatus = new Response();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			IndezerMap<String, String> options = new IndezerMap<String, String>();
			test = test == null ? false : test;
			List<File> fileTemps = null;

			// set file options
			pdfService.setFileOptions(zipFile, ownerPassword, emailTo);

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check required parameters
			checkPdfsFile(pdfFiles, fileUrls, responseStatus, user, fileTemps);

			File outputFile = pdfService.comparePdfs(fileTemps, docKey, user, watch, options, test);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(outputFile);
			headers.add("Content-Disposition", "inline; filename=" + outputFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.COMPARE_PDF_MESSAGE,
						HttpStatus.OK, outputFile.getName(), IndezerUtil.getFileSizeKiloBytes(outputFile) + "  KB",
						docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = pdfService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), outputFile),
							IndezerUtil.getFileSizeMegaBytes(outputFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(outputFile.getPath(), outputFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.COMPARE_PDF_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), outputFile),
						IndezerUtil.getFileSizeMegaBytes(outputFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * Check PDF Files.
	 * 
	 * @param pdfFiles
	 * @param fileUrls
	 * @param responseStatus2
	 * @param user
	 * @param fileTemp
	 * @return
	 */
	private ResponseEntity<?> checkPdfsFile(MultipartFile[] pdfFiles, String fileUrls, Response responseStatus,
			User user, List<File> fileTemps) throws Exception {
		String dir = getStaticFolderPath(user);
		if (pdfFiles != null) {
			int i = 0;
			for (MultipartFile multipartFile : pdfFiles) {
				File fileTemp = new File(
						dir.concat(File.separator).concat("temp_" + i + "_" + UUID.randomUUID() + ".pdf"));
				multipartFile.transferTo(fileTemp);
				fileTemps.add(fileTemp);

				// Check ext file
				if (!IndezerConstant.PDF.equalsIgnoreCase(FilenameUtils.getExtension(fileTemp.getName()))) {
					return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
							IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null,
							null);
				}
				// Check size file
				if (IndezerUtil.getFileSizeMegaBytes(fileTemp) > 300) {
					deleteTempFile(fileTemps);
					return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
							IndezerConstant.FILE_OUT_SIZE_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
							null);
				}
				i++;
			}
		} else if (StringUtils.isNoneEmpty(fileUrls)) {
			int i = 0;
			String[] splitUrls = fileUrls.split(",");
			for (String fUrl : splitUrls) {
				URL url = new URL(fUrl);
				InputStream in = url.openStream();
				File fileTemp = new File(
						dir.concat(File.separator).concat("temp_" + i + "_" + UUID.randomUUID() + ".pdf"));
				OutputStream outStream = new FileOutputStream(fileTemp);
				byte[] buffer = new byte[8 * 1024];
				int bytesRead;
				while ((bytesRead = in.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				in.close();
				outStream.close();
				fileTemps.add(fileTemp);

				// Check ext file
				if (!IndezerConstant.PDF.equalsIgnoreCase(FilenameUtils.getExtension(fileTemp.getName()))) {
					return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
							IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null,
							null);
				}
				// check size file
				if (IndezerUtil.getFileSizeMegaBytes(fileTemp) > 300) {
					deleteTempFile(fileTemps);
					return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
							IndezerConstant.FILE_OUT_SIZE_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
							null);
				}
				i++;
			}
		}
		return null;
	}

	/**
	 * @param fileTemps
	 */
	private void deleteTempFile(List<File> fileTemps) {
		for (File file : fileTemps) {
			file.deleteOnExit();
		}
	}

	/**
	 * Split PDF.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/splitPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Split PDF file.", notes = "Returns the URL/PDF.")
	public ResponseEntity<?> splitPdf(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "zip_file_name") String zipFileName,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			test = test == null ? false : test;
			zipFileName = zipFileName != null ? zipFileName : UUID.randomUUID() + ".zip";
			// set file options
			pdfService.setFileOptions(false, ownerPassword, emailTo);

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check size and type file
			File inputTempPdfFile = new File("");
			getInputPdfFile(pdfFileUrl, pdfFile, user, inputTempPdfFile);

			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;

			File zipFile = pdfService.splitPdf(inputTempPdfFile, zipFileName, docKey, user, watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(zipFile);
			headers.add("Content-Disposition", "inline; filename=" + zipFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.SPLIT_DOC_MESSAGE,
						HttpStatus.OK, getUrlFile(authentication.getName(), zipFile),
						IndezerUtil.getFileSizeMegaBytes(zipFile) + "  MB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = pdfService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), zipFile),
							IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(zipFile.getPath(), zipFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.SPLIT_DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), zipFile),
						IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * PDF to Doc.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/pdfToDoc", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Document.", notes = "Returns the URL/Doc.")
	public ResponseEntity<?> pdfToDoc(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "doc_file_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			test = test == null ? false : test;

			// check size and type file
			File inputPdfFile = new File("");
			getInputPdfFile(pdfFileUrl, pdfFile, user, inputPdfFile);

			if (!PdfTODocFileType.getValues().contains(FilenameUtils.getExtension(docFileName))) {
				return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
						IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, null);
			} else {
				docFileName = docFileName != null ? docFileName
						: UUID.randomUUID() + "." + FilenameUtils.getExtension(docFileName);
			}

			// set file options
			pdfService.setFileOptions(zipFile, ownerPassword, emailTo);

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;

			File outFile = pdfService.pdfToDoc(inputPdfFile, docFileName, docKey, user, watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(outFile);
			headers.add("Content-Disposition", "inline; filename=" + outFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.DOC_CONVERTED_MESSAGE,
						HttpStatus.OK, getUrlFile(authentication.getName(), outFile),
						IndezerUtil.getFileSizeMegaBytes(outFile) + "  MB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = pdfService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), outFile),
							IndezerUtil.getFileSizeMegaBytes(outFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(outFile.getPath(), outFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), outFile),
						IndezerUtil.getFileSizeMegaBytes(outFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * PDF to Image.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/pdfToImage", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Image.", notes = "Returns the URL/zip File/TF.")
	public ResponseEntity<?> pdfToImage(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "zip_file_name") String zipFileName,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			test = test == null ? false : test;
			zipFileName = zipFileName != null ? zipFileName : UUID.randomUUID() + ".zip";
			// set file options
			pdfService.setFileOptions(false, ownerPassword, emailTo);

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check size and type file
			File inputTempPdfFile = new File("");
			getInputPdfFile(pdfFileUrl, pdfFile, user, inputTempPdfFile);

			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;

			File zipFile = pdfService.pdfToImage(inputTempPdfFile, zipFileName, docKey, user, watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(zipFile);
			headers.add("Content-Disposition", "inline; filename=" + zipFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.DOC_CONVERTED_MESSAGE,
						HttpStatus.OK, getUrlFile(authentication.getName(), zipFile),
						IndezerUtil.getFileSizeMegaBytes(zipFile) + "  MB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = pdfService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), zipFile),
							IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(zipFile.getPath(), zipFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), zipFile),
						IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;


	}

	/**
	 * PDF to Html.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/pdfToHtml", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Html.", notes = "Returns the URL/Html.")
	public ResponseEntity<?> pdfToHtml(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "html_file_name") String htmlFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			test = test == null ? false : test;

			// check size and type file
			File inputPdfFile = new File("");
			getInputPdfFile(pdfFileUrl, pdfFile, user, inputPdfFile);

			if ("HTML".contains(FilenameUtils.getExtension(htmlFileName))) {
				return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
						IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, null);
			} else {
				htmlFileName = htmlFileName != null ? htmlFileName
						: UUID.randomUUID() + "." + FilenameUtils.getExtension(htmlFileName);
			}

			// set file options
			pdfService.setFileOptions(zipFile, ownerPassword, emailTo);

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;

			File outFile = pdfService.pdfToHtml(inputPdfFile, htmlFileName, docKey, user, watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(outFile);
			headers.add("Content-Disposition", "inline; filename=" + outFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.DOC_CONVERTED_MESSAGE,
						HttpStatus.OK, getUrlFile(authentication.getName(), outFile),
						IndezerUtil.getFileSizeMegaBytes(outFile) + "  MB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = pdfService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), outFile),
							IndezerUtil.getFileSizeMegaBytes(outFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(outFile.getPath(), outFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), outFile),
						IndezerUtil.getFileSizeMegaBytes(outFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * Get Pages From Pdf.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/getPagesFromPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Document.", notes = "Returns the URL/Doc.")
	public ResponseEntity<?> getPagesFromPdf(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "doc_file_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {

		return null;

	}

	/**
	 * Delete Pages From PDF.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/deletePagesFromPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Document.", notes = "Returns the URL/Doc.")
	public ResponseEntity<?> deletePagesFromPdf(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "doc_file_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {

		return null;

	}

	/**
	 * Add BarCode To PDF.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/addBarCodeToPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Document.", notes = "Returns the URL/Doc.")
	public ResponseEntity<?> addBarCodeToPdf(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "doc_file_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {

		return null;

	}

	/**
	 * Read BarCode From PDF.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/readBarCodeFromPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Document.", notes = "Returns the URL/Doc.")
	public ResponseEntity<?> readBarCodeFromPdf(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "doc_file_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {

		return null;

	}

	/**
	 * Read QRCode From PDF.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/addQRCodeToPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to Document.", notes = "Returns the URL/Doc.")
	public ResponseEntity<?> addQRCodeToPdf(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "doc_file_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {

		return null;

	}

}
