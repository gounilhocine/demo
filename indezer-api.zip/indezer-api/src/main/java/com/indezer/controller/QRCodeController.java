package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.service.api.QRCodeService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;
import com.indezer.util.IndezerEnum.ReturnType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1")
@Api(tags = { "barCode" })
public class QRCodeController extends AbstractRestHandler {

	@Autowired
	private QRCodeService qRCodeService;

	private String qrCodeFileName;

	/**
	 * QR Code.
	 * 
	 * @param data
	 * @param size
	 * @param imageName
	 * @param returnType
	 * @param serverReference
	 * @param colorCode
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/qrCode", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Create a QR Code.", notes = "Returns the URL/IMAGE")
	public ResponseEntity<?> qrCode(@RequestParam(required = true, name = "data") String data,
			@RequestParam(required = false, name = "size") Integer size,
			@RequestParam(required = false, name = "output_image_name") String imageName,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "color_code") String colorCode,
			@RequestParam(required = false, name = "test") Boolean test) {
		Response responseStatus = new Response();

		size = size == null ? 400 : size;
		qrCodeFileName = imageName != null ? imageName : UUID.randomUUID() + ".png";
		String docKey = UUID.randomUUID().toString();
		returnType = returnType == null ? ReturnType.JSON.toString() : returnType;
		test = test == null ? false : test;
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// Process
			File imgFile = qRCodeService.create(data, size.intValue(), colorCode, qrCodeFileName, docKey, user, watch,
					test);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(imgFile);
			headers.add("Content-Disposition", "inline; filename=" + imgFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.BARCODE_CREATED_MESSAGE, HttpStatus.OK,
						getUrlFile(authentication.getName(), imgFile),
						IndezerUtil.getFileSizeKiloBytes(imgFile) + " KB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = qRCodeService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), imgFile),
							IndezerUtil.getFileSizeKiloBytes(imgFile) + " KB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(imgFile.getPath(), imgFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.BARCODE_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), imgFile),
						IndezerUtil.getFileSizeKiloBytes(imgFile) + " KB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

}
