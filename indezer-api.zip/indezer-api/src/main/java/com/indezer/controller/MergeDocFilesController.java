package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.datasource.entity.User;
import com.indezer.service.api.MergeDocsFilesService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/merge-docs")
@Api(tags = { "mergeDocs" })
public class MergeDocFilesController extends AbstractRestHandler {

	@Autowired
	private MergeDocsFilesService mergeDocsFilesService;

	private String fileNameMerged;

	/**
	 * @param accessKey
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param textPosition
	 * @param pdfFileName
	 * @param encode
	 * @param returnType
	 * @return
	 */
	@RequestMapping(value = "/do", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Merge pdfs files.", notes = "Returns the URL/PDF.")
	public ResponseEntity<?> merge(@RequestParam(required = true, name = "file_urls") String fileUrls,
			@RequestParam(required = false, name = "pdf_file_name") String pdfFileName,
			@RequestParam(required = true, name = "return_type") String returnType) {
		Response responseStatus = new Response();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = getUser(authentication.getName());
		String docKey = UUID.randomUUID().toString();
		try {
			if (checkAccountType(user)) {
				if (checkCredit(user)) {
					StopWatch watch = new StopWatch();
					watch.start();
					fileNameMerged = pdfFileName != null ? pdfFileName : UUID.randomUUID() + ".doc";
					File pdfFile = mergeDocsFilesService.merge(fileUrls, fileNameMerged, docKey, user, watch);
					HttpHeaders headers = new HttpHeaders();
					headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
					headers.add("Pragma", "no-cache");
					headers.add("Expires", "0");
					ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(pdfFile);
					headers.add("Content-Disposition", "inline; filename=" + pdfFile);

					if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, "JSON")) {
						return getResponseMessage(responseStatus, HttpStatus.OK.value(),
								IndezerConstant.PDF_MERGED_MESSAGE, HttpStatus.OK, pdfFile.getName(),
								IndezerUtil.getFileSizeKiloBytes(pdfFile) + "  KB", docKey, null);
					} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, "PDF")) {
						return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
								.body(new InputStreamResource(bis));
					}
				} else {
					return getResponseMessage(responseStatus, HttpStatus.PAYMENT_REQUIRED.value(),
							IndezerConstant.PAYMENT_REQUIRED_MESSAGE, HttpStatus.PAYMENT_REQUIRED, null, null, null,
							null);
				}
			} else {
				return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
						IndezerConstant.METHOD_NOT_ALLOWED_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
						null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.METHOD_FAILURE.value(), IndezerConstant.ERROR_OCCURRED,
					HttpStatus.METHOD_FAILURE, null, null, null, e.toString());
		}
		return null;
	}

}
