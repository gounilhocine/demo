package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.service.api.BarCodeService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum.BarCodeType;
import com.indezer.util.IndezerEnum.PositionBarCode;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1")
@Api(tags = { "barCode" })
public class BarCodeController extends AbstractRestHandler {

	@Autowired
	private BarCodeService barCodeService;

	private String barCodeFileName;

	/**
	 * BarCode.
	 * 
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param positionText
	 * @param imageName
	 * @param serverReference
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/barCode", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Create a BarCode file.", notes = "Returns the URL/IMAGE")
	public ResponseEntity<?> barCode(@RequestParam(required = true, name = "data") String code,
			@RequestParam(required = false, name = "barcode_type") String barcodeType,
			@RequestParam(required = false, name = "heigh") Double heigh,
			@RequestParam(required = false, name = "width") Double width,
			@RequestParam(required = false, name = "dpi") Integer dpi,
			@RequestParam(required = false, name = "font_size") Double fontSize,
			@RequestParam(required = false, name = "position_text") String positionText,
			@RequestParam(required = false, name = "output_image_name") String imageName,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "test") Boolean test) {
		com.indezer.util.Response responseStatus = new com.indezer.util.Response();
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// Check barcodeType
			if (StringUtils.isNotEmpty(barcodeType) && !checkBarcodeType(barcodeType)) {
				return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
						IndezerConstant.NO_CONTENT_BARCODE_TYPE_MESSAGE, HttpStatus.NO_CONTENT, null, null, null, null);
			}
			// Check positionText
			if (StringUtils.isNotEmpty(positionText) && !checkPositionCodeType(positionText)) {
				return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
						IndezerConstant.NO_CONTENT_POSITION_BARCODE_MESSAGE, HttpStatus.NO_CONTENT, null, null, null,
						null);
			}

			// process
			StopWatch watch = new StopWatch();
			watch.start();
			barCodeFileName = imageName != null ? imageName : UUID.randomUUID() + ".png";
			dpi = dpi == null ? 100 : dpi;
			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;
			heigh = heigh == null ? 15.0 : heigh;
			width = width == null ? 0.4 : width;
			fontSize = fontSize == null ? 4.0 : fontSize;
			test = test == null ? false : test;
			barcodeType = barcodeType == null ? BarCodeType.CODE128.toString() : barcodeType;
			File imgFile = barCodeService.create(barcodeType, test, code, heigh, width, dpi, fontSize, barCodeFileName,
					positionText, docKey, user, watch);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(imgFile);
			headers.add("Content-Disposition", "inline; filename=" + imgFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.BARCODE_CREATED_MESSAGE, HttpStatus.OK,
						getUrlFile(authentication.getName(), imgFile),
						IndezerUtil.getFileSizeKiloBytes(imgFile) + " KB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = barCodeService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), imgFile),
							IndezerUtil.getFileSizeKiloBytes(imgFile) + " KB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(imgFile.getPath(), imgFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.BARCODE_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), imgFile),
						IndezerUtil.getFileSizeKiloBytes(imgFile) + " KB", docKey, null);
			}
		} catch (

		Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * @param barcodeType
	 * @return
	 */
	private boolean checkBarcodeType(String barcodeType) {
		return BarCodeType.valueOf(barcodeType) == null ? false : true;
	}

	/**
	 * @param positionCode
	 * @return
	 */
	private boolean checkPositionCodeType(String positionCode) {
		return PositionBarCode.valueOf(positionCode) == null ? false : true;
	}
}
