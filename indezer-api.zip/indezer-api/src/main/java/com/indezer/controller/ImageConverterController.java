package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.service.api.ImageConverterService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;
import com.indezer.util.IndezerEnum.ReturnType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/image-to-image")
@Api(tags = { "image" })
@CrossOrigin()
public class ImageConverterController extends AbstractRestHandler {

	@Autowired
	private ImageConverterService imageConverterService;
	
	/**
	 * PDF to Image.
	 * 
	 * @param fileUrl
	 * @param pdfFile
	 * @param pdfFileAuthor
	 * @param pdfFileTitle
	 * @param pdfFileSubject
	 * @param returnType
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/pdfToImage", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "PDF to image.", notes = "Returns the URL/Impages.")
	public ResponseEntity<?> pdfToImage(@RequestParam(required = true, name = "pdf_file_url") String pdfFileUrl,
			@RequestParam(required = false, name = "pdf_file") MultipartFile pdfFile,
			@RequestParam(required = false, name = "zip_file_name") String zipFileName,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();
			test = test == null ? false : test;
			zipFileName = zipFileName != null ? zipFileName : UUID.randomUUID() + ".zip";

			// set file options
			imageConverterService.setFileOptions(false, ownerPassword, emailTo);

			// Check rturnType + Credit	
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check size and type file
			File inputPdfFile = new File("");
			getInputPdfFile(pdfFileUrl, pdfFile, user, inputPdfFile);

			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;

			File zipFile = imageConverterService.pdfToImage(inputPdfFile, zipFileName, docKey, user, watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(zipFile);
			headers.add("Content-Disposition", "inline; filename=" + zipFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.DOC_CONVERTED_MESSAGE,
						HttpStatus.OK, getUrlFile(authentication.getName(), zipFile),
						IndezerUtil.getFileSizeMegaBytes(zipFile) + "  MB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = imageConverterService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), zipFile),
							IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(zipFile.getPath(), zipFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), zipFile),
						IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}


	/**
	 * @param accessKey
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param textPosition
	 * @param imageName
	 * @param encode
	 * @param returnType
	 * @return
	 */
	@RequestMapping(value = "/do", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.IMAGE_PNG_VALUE })
	@ApiOperation(value = "Create a BarCode file.", notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "url") String url,
			@RequestParam(required = false, name = "image_name") String imageName,
			@RequestParam(required = true, name = "image_type") String imageType,
			@RequestParam(required = false, name = "image_width") Integer width,
			@RequestParam(required = false, name = "image_height") Integer height,
			@RequestParam(required = true, name = "return_type") String returnType,
			@RequestParam(required = false, name = "test") Boolean test) {
		Response responseStatus = new Response();
		imageName = imageName != null ? imageName : UUID.randomUUID() + "." + imageType;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		User user = getUser(authentication.getName());
		String docKey = UUID.randomUUID().toString();
		test = test == null ? false : test;
		width = width == null ? 0 : width;
		height = height == null ? 0 : height;
		try {
			if (checkCredit(user)) {
				StopWatch watch = new StopWatch();
				watch.start();
				File imageFile = imageConverterService.convertImage(url, imageName, imageType, docKey, width, height,
						user, watch, test);
				HttpHeaders headers = new HttpHeaders();
				headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
				headers.add("Pragma", "no-cache");
				headers.add("Expires", "0");
				if (imageFile.exists()) {
					ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(imageFile);
					headers.add("Content-Disposition", "inline; filename=" + imageFile);
					if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, "JSON")) {
						return getResponseMessage(responseStatus, HttpStatus.OK.value(),
								IndezerConstant.IMAGE_CREATED_MESSAGE, HttpStatus.OK,
								getUrlFile(authentication.getName(), imageFile),
								IndezerUtil.getFileSizeKiloBytes(imageFile) + " KB", docKey, null);
					} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, "IMG")) {
						return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG)
								.body(new InputStreamResource(bis));
					}
				} else {
					return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
							IndezerConstant.ERROR_OCCURRED, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
							IndezerConstant.FILE_NOT_FOUND_MESSAGE);
				}
			} else {
				return getResponseMessage(responseStatus, HttpStatus.PAYMENT_REQUIRED.value(),
						IndezerConstant.PAYMENT_REQUIRED_MESSAGE, HttpStatus.PAYMENT_REQUIRED, null, null, null, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.METHOD_FAILURE.value(), IndezerConstant.ERROR_OCCURRED,
					HttpStatus.METHOD_FAILURE, null, null, null, e.toString());
		}
		return null;
	}
}
