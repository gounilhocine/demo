package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.datasource.entity.User;
import com.indezer.service.api.UrlToImageService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum.ImageType;
import com.indezer.util.IndezerMap;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/capture-website")
@Api(tags = { "Capture" })
public class UrlToImageController extends AbstractRestHandler {

	@Autowired
	private UrlToImageService urlToImageService;

	@RequestMapping(value = "/do", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Create a BarCode file.", notes = "Returns the URL of the new resource in the Location header.")
	public ResponseEntity<?> convert(@RequestParam(required = true, name = "access_key") String accessKey,
			@RequestParam(required = true, name = "page_url") String pageUrl,
			@RequestParam(required = false, name = "login_page_url") String loginPageUrl,
			@RequestParam(required = false, name = "password_login_page_url") String passwordLoginPageUrl,
			@RequestParam(required = false, name = "username_login_page_url") String usernameLoginPageUrl,
			@RequestParam(required = false, name = "output_file_name") String outputFileName,
			@RequestParam(required = false, name = "output_file_format") ImageType outputFileFormat,
			@RequestParam(required = false, name = "screen_width") String screenWidth,
			@RequestParam(required = false, name = "screen_height") String screenHeight,
			@RequestParam(required = false, name = "start_maximized") Boolean startMaximized,
			@RequestParam(required = false, name = "incognito") Boolean incognito,
			@RequestParam(required = false, name = "headless") Boolean headless,
			@RequestParam(required = false, name = "disable_extensions") Boolean disableExtensions,
			@RequestParam(required = false, name = "disable_popup_blocking") Boolean disablePopupBlocking,
			@RequestParam(required = false, name = "make_default_browser") Boolean makeDefaultBrowser,
			@RequestParam(required = false, name = "version") String version,
			@RequestParam(required = false, name = "silent") Boolean silent,
			@RequestParam(required = false, name = "no_sandbox") Boolean noSandbox,
			@RequestParam(required = false, name = "disable_infobars") Boolean disableInfobars,
			@RequestParam(required = false, name = "disable_gpu") Boolean disableGpu,
			@RequestParam(required = false, name = "ignore_certificate") Boolean ignoreCertificate,
			@RequestParam(required = false, name = "test") Boolean test,
			@RequestParam(required = true, name = "return_type") String returnType) {

		Response responseStatus = new Response();

		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			String docKey = UUID.randomUUID().toString();

			IndezerMap<String, String> options = new IndezerMap<String, String>();
			Map<String, String> values = new HashMap<String, String>();
			values.put("login-page-url", loginPageUrl);
			values.put("password-login-page-url", passwordLoginPageUrl);
			values.put("username-login-page-url", usernameLoginPageUrl);
			values.put("start-maximized", startMaximized == null ? "false" : String.valueOf(startMaximized));
			values.put("incognito", incognito == null ? "false" : String.valueOf(incognito));
			values.put("headless", headless == null ? "false" : String.valueOf(headless));
			values.put("disable-extensions", disableExtensions == null ? "false" : String.valueOf(disableExtensions));
			values.put("disable-popup-blocking",
					disablePopupBlocking == null ? "false" : String.valueOf(disablePopupBlocking));
			values.put("make-default-browser",
					makeDefaultBrowser == null ? "false" : String.valueOf(makeDefaultBrowser));
			values.put("version", version);
			values.put("silent", silent == null ? "false" : String.valueOf(silent));
			values.put("no-sandbox", noSandbox == null ? "false" : String.valueOf(noSandbox));
			values.put("disable-infobars", disableInfobars == null ? "false" : String.valueOf(disableInfobars));
			values.put("disable-gpu", disableGpu == null ? "false" : String.valueOf(disableGpu));
			values.put("ignore-certificate", ignoreCertificate == null ? "false" : String.valueOf(ignoreCertificate));
			values.put("screen-width", screenWidth = screenWidth == null ? "1920" : screenWidth);
			values.put("screen-height", screenHeight = screenHeight == null ? "1400" : screenHeight);
			values.put("output-file-name",
					outputFileName = outputFileName == null ? UUID.randomUUID().toString() : outputFileName);
			values.put("output-file-type",
					outputFileFormat == null ? ImageType.PNG.toString() : outputFileFormat.toString());
			String imgFileName = outputFileName.concat(".").concat(outputFileFormat.toString());
			test = test == null ? false : test;
			options.putValues(values);

			File outputFile = urlToImageService.convertUtlToImage(pageUrl, imgFileName, options, user, watch, docKey,
					test);
			if (checkCredit(user)) {
				HttpHeaders headers = new HttpHeaders();
				headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
				headers.add("Pragma", "no-cache");
				headers.add("Expires", "0");
				ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(outputFile);
				headers.add("Content-Disposition", "inline; filename=" + outputFile);

				if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, "JSON")) {
					return getResponseMessage(responseStatus, HttpStatus.OK.value(),
							IndezerConstant.FILE_CREATED_MESSAGE, HttpStatus.OK,
							getUrlFile(authentication.getName(), outputFile),
							IndezerUtil.getFileSizeKiloBytes(outputFile) + " KB", docKey, null);
				} else if (org.apache.commons.lang3.StringUtils.equals(returnType, "IMG")) {
					return ResponseEntity.ok().headers(headers).contentType(MediaType.IMAGE_PNG)
							.body(new InputStreamResource(bis));
				} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, "PDF")) {
					return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
							.body(new InputStreamResource(bis));
				}
			} else {
				return getResponseMessage(responseStatus, HttpStatus.PAYMENT_REQUIRED.value(),
						IndezerConstant.PAYMENT_REQUIRED_MESSAGE, HttpStatus.PAYMENT_REQUIRED, null, null, null, null);
			}

		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.METHOD_FAILURE.value(), IndezerConstant.ERROR_OCCURRED,
					HttpStatus.METHOD_FAILURE, null, null, null, e.toString());
		}
		return null;
	}

}
