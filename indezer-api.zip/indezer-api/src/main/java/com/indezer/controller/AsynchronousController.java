package com.indezer.controller;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.indezer.model.FileTransferMangerServerModel;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/file-transfer-manager")
@CrossOrigin()
public class AsynchronousController extends AbstractRestHandler {

	private static ExecutorService executor = Executors.newFixedThreadPool(10);

	@PostMapping(value = "/", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	@ApiOperation(value = "File Transfer Manager.", notes = "Return confirmation start message.")
	public String fileTransfer(@Valid @RequestBody(required = true) FileTransferMangerServerModel model) {
		executor.execute((
		// Start process

		) -> {
		});
		return null;
	}

}
