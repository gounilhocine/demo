package com.indezer.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.service.api.DocConverterService;
import com.indezer.util.GeneratePdfReport;
import com.indezer.util.IndezerConstant;
import com.indezer.util.IndezerEnum.DocFileType;
import com.indezer.util.IndezerEnum.MergeDocFileType;
import com.indezer.util.IndezerEnum.ReturnType;
import com.indezer.util.IndezerUtil;
import com.indezer.util.Response;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api/v1/doc")
@Api(tags = { "docToPdf" })
public class DocConverterController extends AbstractRestHandler {

	@Autowired
	private DocConverterService docService;

	private String docFileName;

	private Response responseStatus = new Response();

	/**
	 * @param accessKey
	 * @param code
	 * @param barcodeType
	 * @param heigh
	 * @param width
	 * @param dpi
	 * @param fontSize
	 * @param textPosition
	 * @param pdfFileName
	 * @param encode
	 * @param returnType
	 * @return
	 */
	@RequestMapping(value = "/docToPdf", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Create a PDF file from doc File.", notes = "Returns the URL/PDF")
	public ResponseEntity<?> docToPdf(@RequestParam(required = false, name = "doc_file_url") String docFileUrl,
			@RequestParam(required = false, name = "doc_file") MultipartFile docFile,
			@RequestParam(required = false, name = "pdf_name") String pdfFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			StopWatch watch = new StopWatch();
			watch.start();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			File fileTemp = null;
			test = test == null ? false : test;
			zipFile = zipFile == null ? false : zipFile;
			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;
			docFileName = pdfFileName != null ? pdfFileName : UUID.randomUUID() + ".pdf";
			String docKey = UUID.randomUUID().toString();

			// set file options
			docService.setFileOptions(zipFile, ownerPassword, emailTo);

			String ext = null;
			if (StringUtils.isNoneEmpty(docFileUrl)) {
				ext = FilenameUtils.getExtension(docFileUrl);
			} else {
				ext = FilenameUtils.getExtension(docFile.getName());
			}
			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check required parameters
			checkFileSize(docFileUrl, docFile, responseStatus, user, fileTemp, ext);


			if (!DocFileType.getValues().contains(ext.toUpperCase())) {
				return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
						IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, null);
			}


			File pdfFile = docService.docToPdf(docFileUrl, fileTemp, docFileName, ext.toUpperCase(), docKey, user,
					watch, test, returnType);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(pdfFile);
			headers.add("Content-Disposition", "inline; filename=" + pdfFile);

			if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
				return getResponseMessage(responseStatus, HttpStatus.OK.value(), IndezerConstant.DOC_TO_PDF_MESSAGE,
						HttpStatus.OK, getUrlFile(authentication.getName(), pdfFile),
						IndezerUtil.getFileSizeMegaBytes(pdfFile) + "  MB", docKey, null);
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.FILE.toString())) {
				return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
						.body(new InputStreamResource(bis));
			} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.TF.toString())) {
				RemoteServer remoteServer = docService.getRemoteServerByReference(user, serverReference);
				if (remoteServer == null) {
					return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
							IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
							HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), pdfFile),
							IndezerUtil.getFileSizeMegaBytes(pdfFile) + " MB", docKey, null);
				}
				IndezerUtil.copyFileToRemoteServer(pdfFile.getPath(), pdfFile.getName(), remoteServer);
				return getResponseMessage(responseStatus, HttpStatus.OK.value(),
						IndezerConstant.PDF_FILE_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
						getUrlFile(authentication.getName(), pdfFile),
						IndezerUtil.getFileSizeMegaBytes(pdfFile) + " MB", docKey, null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * Merge Documents.
	 * 
	 * @param docFileUrls
	 * @param docFiles
	 * @param docFileName
	 * @param zipFile
	 * @param emailTo
	 * @param ownerPassword
	 * @param returnType
	 * @param serverReference
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/mergeDocs", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Create a PDF file from doc File.", notes = "Returns the URL/PDF")
	public ResponseEntity<?> mergeDocs(@RequestParam(required = false, name = "doc_files_url") String docFileUrls,
			@RequestParam(required = false, name = "doc_files") MultipartFile docFiles,
			@RequestParam(required = false, name = "doc_name") String docFileName,
			@RequestParam(required = false, name = "zip_file") Boolean zipFile,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {
		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			File fileTemp = null;

			// set file options
			docService.setFileOptions(zipFile, ownerPassword, emailTo);

			String[] ext = new String[10];
			String[] inputDocs = null;
			if (StringUtils.isNoneEmpty(docFileUrls)) {
				inputDocs = docFileUrls.split(",");
				int i = 0;
				for (String d : inputDocs) {
					ext[i] = FilenameUtils.getExtension(d);
					if (!MergeDocFileType.getValues().contains(ext[i].toUpperCase())) {
						return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
								IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null,
								null);
					}
					i++;
				}
			} else if (docFiles != null) {
				inputDocs = docFiles.getName().split(",");
				int i = 0;
				for (String d : inputDocs) {
					ext[i] = FilenameUtils.getExtension(d);
					if (!MergeDocFileType.getValues().contains(ext[i].toUpperCase())) {
						return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
								IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null,
								null);
					}
					i++;
				}
			}

			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check required parameters
			checkFileSize(docFileUrls, docFiles, responseStatus, user, fileTemp, ext[0]);

			test = test == null ? false : test;
			zipFile = zipFile == null ? false : zipFile;
			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;
			docFileName = docFileName != null ? docFileName : UUID.randomUUID() + "." + ext[0];

			String docKey = UUID.randomUUID().toString();

			if (checkAccountType(user)) {
				if (checkCredit(user)) {
					StopWatch watch = new StopWatch();
					watch.start();

					File docFile = docService.mergeDocs(inputDocs, fileTemp, docFileName, ext[0], docKey, user, watch,
							test, returnType);
					HttpHeaders headers = new HttpHeaders();
					headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
					headers.add("Pragma", "no-cache");
					headers.add("Expires", "0");
					ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(docFile);
					headers.add("Content-Disposition", "inline; filename=" + docFile);

					if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
						return getResponseMessage(responseStatus, HttpStatus.OK.value(),
								IndezerConstant.MERGE_DOC_MESSAGE, HttpStatus.OK,
								getUrlFile(authentication.getName(), docFile),
								IndezerUtil.getFileSizeMegaBytes(docFile) + "  MB", docKey, null);
					} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType,
							ReturnType.FILE.toString())) {
						return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
								.body(new InputStreamResource(bis));
					} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType,
							ReturnType.TF.toString())) {
						RemoteServer remoteServer = docService.getRemoteServerByReference(user, serverReference);
						if (remoteServer == null) {
							return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
									IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
									HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), docFile),
									IndezerUtil.getFileSizeMegaBytes(docFile) + " MB", docKey, null);
						}
						IndezerUtil.copyFileToRemoteServer(docFile.getPath(), docFile.getName(), remoteServer);
						return getResponseMessage(responseStatus, HttpStatus.OK.value(),
								IndezerConstant.MERGE_DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
								getUrlFile(authentication.getName(), docFile),
								IndezerUtil.getFileSizeMegaBytes(docFile) + " MB", docKey, null);
					}
				}
			} else {
				return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
						IndezerConstant.METHOD_NOT_ALLOWED_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
						null);
			}
		} catch (

		Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}

	/**
	 * Merge Documents.
	 * 
	 * @param docFileUrls
	 * @param docFiles
	 * @param docFileName
	 * @param zipFile
	 * @param emailTo
	 * @param ownerPassword
	 * @param returnType
	 * @param serverReference
	 * @param test
	 * @return
	 */
	@RequestMapping(value = "/splitDoc", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_PDF_VALUE })
	@ApiOperation(value = "Split Doc file.", notes = "Returns the URL/Docs")
	public ResponseEntity<?> splitDoc(@RequestParam(required = false, name = "doc_file_url") String docFileUrl,
			@RequestParam(required = false, name = "doc_file") MultipartFile docFile,
			@RequestParam(required = false, name = "pages") String pages,
			@RequestParam(required = false, name = "zip_file_name") String zipFileName,
			@RequestParam(required = false, name = "email_to") String emailTo,
			@RequestParam(required = false, name = "owner_password") String ownerPassword,
			@RequestParam(required = false, name = "return_type") String returnType,
			@RequestParam(required = false, name = "server_reference") String serverReference,
			@RequestParam(required = false, name = "test") Boolean test) {

		try {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			User user = getUser(authentication.getName());
			File fileTemp = null;

			// set file options
			docService.setFileOptions(false, ownerPassword, emailTo);

			String ext = null;
			if (StringUtils.isNoneEmpty(docFileUrl)) {
				ext = FilenameUtils.getExtension(docFileUrl);
			} else {
				ext = FilenameUtils.getExtension(docFile.getName());
			}
			// Check rturnType + Credit
			checkAccessToApi(serverReference, returnType, test, responseStatus, user);

			// check required parameters
			checkFileSize(docFileUrl, docFile, responseStatus, user, fileTemp, ext);

			test = test == null ? false : test;
			returnType = returnType == null ? ReturnType.JSON.toString() : returnType;
			zipFileName = zipFileName != null ? zipFileName : UUID.randomUUID() + ".zip";

			if (!MergeDocFileType.getValues().contains(ext.toUpperCase())) {
				return getResponseMessage(responseStatus, HttpStatus.BAD_REQUEST.value(),
						IndezerConstant.EXTENSION_NOT_ALLOWED_MESSAGE, HttpStatus.BAD_REQUEST, null, null, null, null);
			}

			String docKey = UUID.randomUUID().toString();

			if (checkAccountType(user)) {
				if (checkCredit(user)) {
					StopWatch watch = new StopWatch();
					watch.start();

					File zipFile = docService.splitDoc(docFileUrl, fileTemp, zipFileName, ext.toUpperCase(), pages,
							docKey, user, watch, test, returnType);
					HttpHeaders headers = new HttpHeaders();
					headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
					headers.add("Pragma", "no-cache");
					headers.add("Expires", "0");
					ByteArrayInputStream bis = GeneratePdfReport.retrieveByteArrayInputStream(zipFile);
					headers.add("Content-Disposition", "inline; filename=" + zipFile);

					if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType, ReturnType.JSON.toString())) {
						return getResponseMessage(responseStatus, HttpStatus.OK.value(),
								IndezerConstant.SPLIT_DOC_MESSAGE, HttpStatus.OK,
								getUrlFile(authentication.getName(), zipFile),
								IndezerUtil.getFileSizeMegaBytes(zipFile) + "  MB", docKey, null);
					} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType,
							ReturnType.FILE.toString())) {
						return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_FORM_URLENCODED)
								.body(new InputStreamResource(bis));
					} else if (org.apache.commons.lang3.StringUtils.equalsIgnoreCase(returnType,
							ReturnType.TF.toString())) {
						RemoteServer remoteServer = docService.getRemoteServerByReference(user, serverReference);
						if (remoteServer == null) {
							return getResponseMessage(responseStatus, HttpStatus.NO_CONTENT.value(),
									IndezerConstant.SERVER_REFREFNCE_NOT_VALID_MESSAGE.concat(serverReference),
									HttpStatus.NO_CONTENT, getUrlFile(authentication.getName(), zipFile),
									IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
						}
						IndezerUtil.copyFileToRemoteServer(zipFile.getPath(), zipFile.getName(), remoteServer);
						return getResponseMessage(responseStatus, HttpStatus.OK.value(),
								IndezerConstant.SPLIT_DOC_TRANSFERED_MESSAGE.concat(serverReference), HttpStatus.OK,
								getUrlFile(authentication.getName(), zipFile),
								IndezerUtil.getFileSizeMegaBytes(zipFile) + " MB", docKey, null);
					}
				}
			} else {
				return getResponseMessage(responseStatus, HttpStatus.METHOD_NOT_ALLOWED.value(),
						IndezerConstant.METHOD_NOT_ALLOWED_MESSAGE, HttpStatus.METHOD_NOT_ALLOWED, null, null, null,
						null);
			}
		} catch (Exception e) {
			return getResponseMessage(responseStatus, HttpStatus.INTERNAL_SERVER_ERROR.value(),
					IndezerConstant.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, e.toString());
		}
		return null;
	}
}
