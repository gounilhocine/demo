package com.indezer.util;

import java.io.Serializable;
import java.util.AbstractMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

public class IndezerMap<K, V> extends AbstractMap<K, V> implements Map<K, V>, Cloneable, Serializable {

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = 1274670553995692165L;

	@Override
	public Set<Entry<K, V>> entrySet() {
		return entrySet();
	}

	@Override
	public V put(K key, V value) {
		if (StringUtils.isNotEmpty((String) key) && StringUtils.isNotEmpty((String) value)) {
			return super.put(key, value);
		}
		return null;
	}

	/**
	 * @param values
	 */
	public void putValues(Map<K, V> values) {
		for (Entry<K, V> entry : values.entrySet()) {
			if (entry.getValue() != null && entry.getKey() != null) {
				super.put(entry.getKey(), entry.getValue());
			}
		}
	}

}
