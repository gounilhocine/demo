package com.indezer.util;

public class IndezerConstant {

	public static final String CONTENT_TYPE = "application/json;";

	public static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0";

	public static final String BAD_REQUEST_MESSAGE = "Year access key is not valid";

	public static final String BAD_URL_OR_CREDENTIALS_MESSAGE = "Check your url and your credentials";

	public static final String PDF_CREATED_MESSAGE = "PDF file is created";

	public static final String BARCODE_CREATED_MESSAGE = "BarCode image is created";

	public static final String INDEZER_WEB_URL = "https://www.indezer.com/";

	public static final String PDF_NOT_CREATED_MESSAGE = "PDF file is not created. Please try again";

	public static final String ERROR_OCCURRED = "error occurred";

	public static final String BAD_REQUEST_REURN_TYPE_NOT_VALID = "return_type Value is not valid. PLease use {'PDF' or 'JSON'}";

	public static final String TECHNICAL_ERROR = "technical error";

	public static final String PDF_MERGED_MESSAGE = "PDF files is merged";

	public static final String IMAGE_PNG = "IMAGE PNG";

	public static final String PAYMENT_REQUIRED_MESSAGE = "You have reached your limit of requests on indezer api. The requested operation requires more resources than the quota allows. Payment is required to complete this operation.";

	public static final String DOCUMENT_DELETED_MESSAGE = "This Document has been deleted successfully";

	public static final String DOCUMENT_NOT_FOUND = "Document not found";

	public static final String CREDIT_FOUND_MESSAGE = "Your credit indezer";

	public static final String IMAGE_CREATED_MESSAGE = "Image is converted";

	public static final String MERGE_PDFS = "MERGE_PDFS";

	public static final String PDF = "PDF";

	public static final String DOC = "DOC";

	public static final String DOCX = "DOCX";

	public static final String PPT = "PPT";

	public static final String PPTX = "PPTX";

	public static final String ODT = "ODT";

	public static final String METHOD_NOT_ALLOWED_MESSAGE = "your account type does not allow you to call thi API. This operation reserved only for Standard and primium accounts";

	public static final String NO_CONTENT_BARCODE_TYPE_MESSAGE = "Check barcode-type parameter value please";

	public static final String NO_CONTENT_POSITION_BARCODE_MESSAGE = "Check position-code parameter value please";

	public static final String DOC_TO_PDF_MESSAGE = "Document is converted";

	public static final String EXTENSION_NOT_ALLOWED_MESSAGE = "The format of the file to be converted is not allowed. please check your request.";

	public static final String XLS = "XLS";

	public static final String XLSX = "XLSX";

	public static final String TXT = "TXT";

	public static final String FILE_CREATED_MESSAGE = "Document is converted";

	public static final String DRAFT_IMAGE = "D:/demo/indezer/doc2pdf/draft.jpg";

	public static final String IMAGE = "IMAGE";

	public static final String FILE_NOT_FOUND_MESSAGE = "File not found. Please check your request file";

	public static final String NO_CONTENT_RETURN_TYPE_MESSAGE = "Check return_type parameter value please";

	public static final String NO_CONTENT_SERVER_REFERENCE_MESSAGE = "The server_reference parameter is mandatory for the return_type=TF";

	public static final String BARCODE_TRANSFERED_MESSAGE = "BarCode image is created and transfered to your server : ";

	public static final String SERVER_REFREFNCE_NOT_VALID_MESSAGE = "Please, check server_reference parameter";

	public static final String FILE_OR_URL_REQUIRED_MESSAGE = "One of these two parameters doc_file_url, doc_file is mandatory";

	public static final String FILE_OUT_SIZE_MESSAGE = "This file is larger than 300 MB";

	public static final String MERGE_DOC_MESSAGE = "Documents are merged";

	public static final String SPLIT_DOC_TRANSFERED_MESSAGE = "Document is splitted and transfered to your server : ";

	public static final String MERGE_DOC_TRANSFERED_MESSAGE = "Documents are merged and transfered to your server : ";

	public static final String SPLIT_DOC_MESSAGE = "Document is splitted";

	public static final String PDF_FILE_TRANSFERED_MESSAGE = "Pdf file is created and transfered to your server : ";

	public static final String DOC_CONVERTED_MESSAGE = "Document is converted";

	public static final String DOC_TRANSFERED_MESSAGE = "Document is converted and transfered to your server : ";

	public static final String COMPARE_PDF_MESSAGE = "Pdf Files are compared";
	
	public static final String COMPARE_PDF_TRANSFERED_MESSAGE = "Pdf Files are compared and transfered to your server : ";

	public static final Object PNG = "PNG";

}
