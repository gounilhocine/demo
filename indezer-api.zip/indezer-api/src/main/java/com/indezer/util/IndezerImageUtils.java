package com.indezer.util;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;

import com.lowagie.text.Image;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

public class IndezerImageUtils {

	/**
	 * @param inputImagePathOroginal
	 * @param outputImagePath
	 * @param width
	 * @param height
	 * @throws IOException
	 */
	public static void resize(String inputImagePathOroginal, String outputImagePath, String extenssion, int width,
			int height) throws IOException {
		BufferedImage img = load(inputImagePathOroginal);
		BufferedImage thumbnail = resize(img, width, height);
		write(thumbnail, outputImagePath, extenssion);
	}

	/**
	 * @throws Exception
	 */
	public static void addImageWatermarkPdf(String inputFileName, String outputFileName, String imageFileName)
			throws Exception {
		PdfReader reader = new PdfReader(inputFileName);
		PdfStamper pdfStamper = new PdfStamper(reader, new FileOutputStream(outputFileName));
		Image image = Image.getInstance(imageFileName);
		for (int i = 1; i <= reader.getNumberOfPages(); i++) {
			PdfContentByte content = pdfStamper.getUnderContent(i);
			Rectangle rec = content.getPdfDocument().getPageSize();
			image.setAbsolutePosition(rec.getWidth() / 2, rec.getHeight() / 2);
			content.addImage(image);
		}
		pdfStamper.close();
	}

	/**
	 * @param sourcePath
	 * @param logoPath
	 * @throws Exception
	 */
	public static void addImageToImage(String sourcePath, String draftImage) throws Exception {
		BufferedImage source = ImageIO.read(new File(sourcePath));
		BufferedImage logo = ImageIO.read(new File(draftImage));
		Graphics g = source.getGraphics();
		g.drawImage(logo, 0, 0, null);
		g.dispose();
	}

	/**
	 * @param localImagePath
	 * @param imageWaterMarkPath
	 * @throws Exception
	 */
	public static void addImageWatermarkImage(String localImagePath, String imageWaterMarkPath) throws Exception {
		BufferedImage image = ImageIO.read(new File(localImagePath));
		BufferedImage overlay = ImageIO.read(new File(imageWaterMarkPath));
		// create the new image, canvas size is the max. of both image sizes
		int w = Math.max(image.getWidth(), overlay.getWidth());
		int h = Math.max(image.getHeight(), overlay.getHeight());
		BufferedImage combined = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		// paint both images, preserving the alpha channels
		Graphics g = combined.getGraphics();
		g.drawImage(image, 0, 0, null);
		g.drawImage(overlay, 500, 200, null);
		ImageIO.write(combined, "PNG", new File(localImagePath));
	}

	/**
	 * @param thumbnail
	 * @throws IOException
	 */
	private static void write(BufferedImage thumbnail, String outputImagePath, String extenssion) throws IOException {
		ImageIO.write(thumbnail, extenssion, new File(outputImagePath));
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(thumbnail, extenssion, baos);
		baos.flush();
		byte[] imageBytes = baos.toByteArray();
	}

	/**
	 * @param img
	 * @return
	 */
	private static BufferedImage resize(BufferedImage img, int width, int height) {
		java.awt.Image scaledImg = img.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
		BufferedImage thumbnail = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		thumbnail.createGraphics().drawImage(scaledImg, 0, 0, null);
		return thumbnail;
	}

	public static BufferedImage scale(BufferedImage src, int w, int h) {
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		int x, y;
		int ww = src.getWidth();
		int hh = src.getHeight();
		int[] ys = new int[h];
		for (y = 0; y < h; y++)
			ys[y] = y * hh / h;
		for (x = 0; x < w; x++) {
			int newX = x * ww / w;
			for (y = 0; y < h; y++) {
				int col = src.getRGB(newX, ys[y]);
				img.setRGB(x, y, col);
			}
		}
		return img;
	}

	public static BufferedImage resize2(BufferedImage src, int width, int height) {
		int targetWidth = width;
		int targetHeight = height;
		float ratio = ((float) src.getHeight() / (float) src.getWidth());
		if (ratio <= 1) { // square or landscape-oriented image
			targetHeight = (int) Math.ceil((float) targetWidth * ratio);
		} else { // portrait image
			targetWidth = Math.round((float) targetHeight / ratio);
		}
		BufferedImage bi = new BufferedImage(targetWidth, targetHeight,
				src.getTransparency() == Transparency.OPAQUE ? BufferedImage.TYPE_INT_RGB
						: BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = bi.createGraphics();
		g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR); // produces
																												// a
																												// balanced
																												// resizing
																												// (fast
																												// and
																												// decent
																												// quality)
		g2d.drawImage(src, 0, 0, targetWidth, targetHeight, null);
		g2d.dispose();
		return bi;
	}

	/**
	 * @param inputImagePathOroginal
	 * @return
	 * @throws IOException
	 */
	private static BufferedImage load(String inputImagePathOroginal) throws IOException {
		File sourceImageFile = new File(inputImagePathOroginal);
		BufferedImage img = ImageIO.read(sourceImageFile);
		return img;
	}

	/**
	 * @param image
	 * @param cornerRadius
	 * @return
	 */
	public static BufferedImage makeRoundedCorner(BufferedImage image, int cornerRadius) {
		int w = image.getWidth();
		int h = image.getHeight();
		BufferedImage output = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);

		Graphics2D g2 = output.createGraphics();

		// This is what we want, but it only does hard-clipping, i.e. aliasing
		// g2.setClip(new RoundRectangle2D ...)

		// so instead fake soft-clipping by first drawing the desired clip shape
		// in fully opaque white with antialiasing enabled...
		g2.setComposite(AlphaComposite.Src);
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setColor(Color.WHITE);
		g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));

		// ... then compositing the image on top,
		// using the white shape from above as alpha source
		g2.setComposite(AlphaComposite.SrcAtop);
		g2.drawImage(image, 0, 0, null);

		g2.dispose();

		return output;
	}

	public static void addImageWatermarkPdf(List<File> outputTempFiles, List<File> outputFiles, String pdfWatermark) {
		// TODO Auto-generated method stub

	}

	/**
	 * Convert Pdf to images.
	 * 
	 * @param inputPdfFile
	 * @param outputFilePath
	 * @return
	 * @throws IOException
	 */
	public static File generateImagesFromPdf(File inputPdfFile, String dir, String zipFilePath, boolean test,
			String watermark) throws Exception {
		PDDocument document = PDDocument.load(inputPdfFile);
		File[] files = new File[document.getNumberOfPages()];
		PDFRenderer pdfRenderer = new PDFRenderer(document);
		for (int page = 0; page < document.getNumberOfPages(); ++page) {
			BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);
			String image = String.format(dir + "/pdf-%d.%s", page + 1, IndezerEnum.ImageType.JPG.toString());
			ImageIOUtil.writeImage(bim, image, 300);
			if (test) {
				IndezerImageUtils.addImageWatermarkImage(image, watermark);
			}
			files[page] = new File(image);
		}
		IndezerUtil.addFilesToZip(new File("temp_" + zipFilePath), files);
		document.close();
		return new File(zipFilePath);
	}
}
