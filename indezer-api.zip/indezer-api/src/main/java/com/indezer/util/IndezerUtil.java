package com.indezer.util;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.RoundingMode;
import java.net.URI;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.imageio.ImageIO;

import org.apache.commons.vfs2.AllFileSelector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.VFS;

import com.indezer.datasource.entity.RemoteServer;
import com.indezer.datasource.entity.User;
import com.indezer.util.IndezerEnum.OperationType;
import com.indezer.util.IndezerEnum.Protocol;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class IndezerUtil {

	/**
	 * @param file
	 * @return
	 */
	public static Double getFileSizeMegaBytes(File file) {
		return roundDouble("#.####", (double) file.length() / (1024 * 1024));
	}

	/**
	 * @param source
	 * @param files
	 */
	public static void addFilesToZip(File source, File[] files) {
		try {
			File tmpZip = File.createTempFile(source.getName(), null);
			tmpZip.delete();
			if (!source.renameTo(tmpZip)) {
				throw new Exception("Could not make temp file (" + source.getName() + ")");
			}
			byte[] buffer = new byte[1024];
			ZipInputStream zin = new ZipInputStream(new FileInputStream(tmpZip));
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(source));

			for (int i = 0; i < files.length; i++) {
				InputStream in = new FileInputStream(files[i]);
				out.putNextEntry(new ZipEntry(files[i].getName()));
				for (int read = in.read(buffer); read > -1; read = in.read(buffer)) {
					out.write(buffer, 0, read);
				}
				out.closeEntry();
				in.close();
			}

			for (ZipEntry ze = zin.getNextEntry(); ze != null; ze = zin.getNextEntry()) {
				out.putNextEntry(ze);
				for (int read = zin.read(buffer); read > -1; read = zin.read(buffer)) {
					out.write(buffer, 0, read);
				}
				out.closeEntry();
			}

			out.close();
			tmpZip.delete();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param in
	 * @param file
	 */
	public static void copyInputStreamToFile(InputStream in, File file) {
		try {
			OutputStream out = new FileOutputStream(file);
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			out.close();
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param inputFile
	 * @param zipFilePath
	 * @return
	 * @throws Exception
	 */
	public static File zipFile(File inputFile, String zipFilePath) throws Exception {
		URI inFileUri = inputFile.toURI();
		FileSystemManager fileSystemManager = VFS.getManager();
		FileObject tarFile = fileSystemManager.resolveFile(inFileUri.toString());
		try {
			FileObject zipFileSystem = fileSystemManager.createFileSystem(tarFile);
			try {
				fileSystemManager.toFileObject(new File(zipFilePath)).copyFrom(zipFileSystem, new AllFileSelector());
			} finally {
				zipFileSystem.close();
			}
		} finally {
			tarFile.close();
		}
		return new File(zipFilePath);
	}

	/**
	 * @param inputFile
	 * @param outputFilePath
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public static File encryptFile(File inputFile, String outputFilePath, String password) throws Exception {
		FileInputStream inFile = new FileInputStream(inputFile);
		FileOutputStream outFile = new FileOutputStream(outputFilePath);

		PBEKeySpec pbeKeySpec = new PBEKeySpec(password.toCharArray());
		SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndTripleDES");
		SecretKey secretKey = secretKeyFactory.generateSecret(pbeKeySpec);

		byte[] salt = new byte[8];
		Random random = new Random();
		random.nextBytes(salt);

		PBEParameterSpec pbeParameterSpec = new PBEParameterSpec(salt, 100);
		Cipher cipher = Cipher.getInstance("PBEWithMD5AndTripleDES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, pbeParameterSpec);
		outFile.write(salt);

		byte[] input = new byte[64];
		int bytesRead;
		while ((bytesRead = inFile.read(input)) != -1) {
			byte[] output = cipher.update(input, 0, bytesRead);
			if (output != null)
				outFile.write(output);
		}

		byte[] output = cipher.doFinal();
		if (output != null)
			outFile.write(output);

		inFile.close();
		outFile.flush();
		outFile.close();
		inputFile.deleteOnExit();
		File fout = new File(outputFilePath);
		fout.renameTo(inputFile);
		return fout;
	}

	/**
	 * @param docFileTYpe
	 * @return
	 */
	public static OperationType getOperationType(String docFileTYpe) {
		switch (docFileTYpe) {
		case IndezerConstant.DOC:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.DOCX:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.PPT:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.PPTX:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.ODT:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.XLS:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.XLSX:
			return IndezerEnum.OperationType.DOC_PDF;
		case IndezerConstant.TXT:
			return IndezerEnum.OperationType.DOC_PDF;
		default:
			break;
		}
		return null;
	}

	/**
	 * 
	 */
	/**
	 * @param fileInputName
	 * @param fileOutputName
	 * @param remoteServer
	 * @throws Exception
	 */
	public static void copyFileToRemoteServer(String fileInputName, String fileOutputName, RemoteServer remoteServer)
			throws Exception {
		JSch jsch = new JSch();
		Session session = jsch.getSession(remoteServer.getUnserName(), remoteServer.getHost(), remoteServer.getPort());
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);
		session.setPassword(remoteServer.getPassword());
		session.connect();
		ChannelSftp sftpChannel = (ChannelSftp) session.openChannel(Protocol.SFTP.toString().toLowerCase());
		sftpChannel.connect();
		sftpChannel.put(fileInputName, remoteServer.getDirectory().concat("/").concat(fileOutputName));
		sftpChannel.disconnect();
		session.disconnect();
	}

	/**
	 * @param patten
	 * @param number
	 * @return
	 */
	public static Double roundDouble(String patten, double number) {
		DecimalFormat df = new DecimalFormat(patten);
		df.setRoundingMode(RoundingMode.HALF_UP);
		String newCredit = df.format(number);
		return Double.valueOf(newCredit.replace(",", "."));
	}

	/**
	 * @param text
	 * @param sourceImageFile
	 * @param destImageFile
	 */
	public static void addTextWatermark(String text, File sourceImageFile, File destImageFile) {
		try {
			BufferedImage sourceImage = ImageIO.read(sourceImageFile);
			Graphics2D g2d = (Graphics2D) sourceImage.getGraphics();

			// initializes necessary graphic properties
			AlphaComposite alphaChannel = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.1f);
			g2d.setComposite(alphaChannel);
			g2d.setColor(Color.RED);
			g2d.setFont(new Font("Arial", Font.BOLD, 24));
			FontMetrics fontMetrics = g2d.getFontMetrics();
			Rectangle2D rect = fontMetrics.getStringBounds(text, g2d);

			// calculates the coordinate where the String is painted
			int centerX = (sourceImage.getWidth() - (int) rect.getWidth()) / 2;
			int centerY = sourceImage.getHeight() / 2;

			// paints the textual watermark
			g2d.drawString(text, centerX, centerY);

			ImageIO.write(sourceImage, "png", destImageFile);
			g2d.dispose();
		} catch (IOException ex) {
			System.err.println(ex);
		}
	}

	/**
	 * @param watermarkImageFile
	 * @param sourceImageFile
	 * @param destImageFile
	 */
	public static void addImageWatermark(File watermarkImageFile, File sourceImageFile, File destImageFile) {
		try {
			BufferedImage sourceImage = ImageIO.read(sourceImageFile);
			BufferedImage watermarkImage = ImageIO.read(watermarkImageFile);

			// initializes necessary graphic properties
			Graphics2D g2d = (Graphics2D) sourceImage.getGraphics();
			AlphaComposite alphaChannel = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f);
			g2d.setComposite(alphaChannel);

			// calculates the coordinate where the image is painted
			int topLeftX = (sourceImage.getWidth() - watermarkImage.getWidth()) / 2;
			int topLeftY = (sourceImage.getHeight() - watermarkImage.getHeight()) / 2;

			// paints the image watermark
			g2d.drawImage(watermarkImage, topLeftX, topLeftY, null);

			ImageIO.write(sourceImage, "png", destImageFile);
			g2d.dispose();

		} catch (IOException ex) {
			System.err.println(ex);
		}
	}

	/**
	 * @param file
	 * @return
	 */
	public static Double getFileSizeKiloBytes(File file) {
		return roundDouble("#.####", (double) file.length() / 1024);
	}

	public static String getFileSizeBytes(File file) {
		return file.length() + " bytes";
	}

	/**
	 * @return
	 */
	public static String getDirectoryName() {
		return UUID.randomUUID().toString();
	}

	/**
	 * @return
	 */
	public static double getTimeMilliSeconds() {
		return TimeUnit.MILLISECONDS.toSeconds(new Date().getTime());
	}

	/**
	 * @param path
	 * @param indezerFolder
	 * @return
	 */
	public static String createFolder(String indezerFolder) {
		File dir = new File(indezerFolder);
		if (!dir.exists()) {
			dir.mkdirs();
			return dir.toString();
		}
		return null;
	}

	/**
	 * @param userDirectory
	 */
	public static void directoryProperties(File userDirectory) {
		userDirectory.setExecutable(true);
		userDirectory.setWritable(true);
		userDirectory.setReadable(true);
	}

	/**
	 * @return
	 */
	public static String getFolderPath(String staticFolder, User user, String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		String dateInString = sdf.format(user.getCreatedAt());
		String path = user.getDirectory() + File.separator + dateInString.substring(0, 4) + File.separator
				+ dateInString.substring(4, 6) + File.separator + dateInString.substring(6, 8);
		return path;
	}

	/**
	 * @param docFileUrl
	 * @param pages
	 * @return
	 */
	public static List<File> splitFiles(String docFileUrl, String pages) {
		// TODO Auto-generated method stub
		return null;
	}

}
