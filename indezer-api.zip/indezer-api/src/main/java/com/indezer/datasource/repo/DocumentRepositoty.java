package com.indezer.datasource.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.indezer.datasource.entity.Document;

@Repository
public interface DocumentRepositoty extends CrudRepository<Document, Long> {

	@Transactional
	@Modifying
	@Query("delete from Document d where d.docKey=:docKey")
	void deleteDocumentByDocKey(String docKey);

	@Query(" select d from Document d where d.docKey=:docKey")
	Document findDocumentByDocKey(String docKey);

}
