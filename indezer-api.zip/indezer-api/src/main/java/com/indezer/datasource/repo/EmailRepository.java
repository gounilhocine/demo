package com.indezer.datasource.repo;

import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import com.indezer.datasource.entity.Email;

@Repository
public interface EmailRepository extends CrudRepository<Email, Long> {

}
