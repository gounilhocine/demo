package com.khoubyari.example.test;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class ConnectLoginPageTest {

	public static void main(String[] args) throws MalformedURLException, IOException {
		String adress = "http://oasis.natixis-life.loc:8080/natixis-core/";
		// create & open connection
		HttpURLConnection connection = (HttpURLConnection) new URL(adress).openConnection();

		// set do output ...
		connection.setDoOutput(true);

		/** variable charset for encoding */
		String CHARSET = "UTF-8";

		// Construct the POST value/key pair data.
		String data = "login=" + URLEncoder.encode("gouni", CHARSET) + "&password=" + URLEncoder.encode("Progteam20201@", CHARSET) + "&remember_me=on";

		byte[] dataBytes = data.getBytes(CHARSET);

		// create output stram to write our creditentials
		OutputStream outputStream = new BufferedOutputStream(connection.getOutputStream());

		// write value/key data to output stream
		outputStream.write(dataBytes);
		outputStream.flush();

		// connect to url
		connection.connect();

		// now we are connected and we can do other stuff get input strem header response code etc....
		int responseCode = connection.getResponseCode();
		System.out.println(responseCode);
		
		
		InputStream is = connection.getInputStream();
		Document doc = Jsoup.parse(is, null, adress);
		System.out.println(doc);

		/**
		 * here we grab cookies (how? - in other story)
		 */

		connection.disconnect();

		//

		
	}

}
