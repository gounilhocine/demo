package com.khoubyari.example.test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;

public class ReadFileFromUrl {
	private static byte[] getArrayFromInputStream(InputStream inputStream) throws IOException {
		byte[] bytes;
		byte[] buffer = new byte[1024];
		try (BufferedInputStream is = new BufferedInputStream(inputStream)) {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			int length;
			while ((length = is.read(buffer)) > -1) {
				bos.write(buffer, 0, length);
			}
			bos.flush();
			bytes = bos.toByteArray();
		}
		return bytes;
	}

	public static void main(String[] args) throws Exception {
		String mergedFileName = "C:\\wamp64\\www\\Merged.pdf";
		File f1 = new File("C:\\wamp64\\www\\1.pdf");
		File f2 = new File("C:\\wamp64\\www\\2.pdf");
		File f3 = new File("C:\\wamp64\\www\\3.pdf");
		List<File> files = new ArrayList<File>();
		files.add(f1);
		files.add(f2);
		files.add(f3);
		mergePDFFiles(files, mergedFileName);
	}
	public static void mergePDFFiles(List<File> files, String mergedFileName) {
		try {
			PDFMergerUtility pdfmerger = new PDFMergerUtility();
			for (File file : files) {
				PDDocument document = PDDocument.load(file);
				pdfmerger.setDestinationFileName(mergedFileName);
				pdfmerger.addSource(file);
				pdfmerger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly());
				document.close();
			}
		} catch (IOException e) {
			e.fillInStackTrace();
		}
	}
	//
	// URL url1 = new URL("http://localhost/1.pdf");
	// URL url2 = new URL("http://localhost/2.pdf");
	//
	// List<InputStream> streams = Arrays.asList(url1.openStream(), url2.openStream());
	// InputStream allStreams = new SequenceInputStream(Collections.enumeration(streams));
	//
	// byte[] content = getArrayFromInputStream(allStreams);
	// writeContent(content, "c:/test/pdf2.pdf");

	private static void writeContent(byte[] content, String fileToWriteTo) throws IOException {
		File file = new File(fileToWriteTo);
		try (BufferedOutputStream stream1 = new BufferedOutputStream(new FileOutputStream(file))) {
			stream1.write(content);
			stream1.flush();
		}
	}
}
