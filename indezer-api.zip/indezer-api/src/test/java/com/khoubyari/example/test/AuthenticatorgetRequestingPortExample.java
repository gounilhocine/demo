package com.khoubyari.example.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

public class AuthenticatorgetRequestingPortExample {
	public static class ClassAuthenticator extends Authenticator {
		@Override
		protected PasswordAuthentication getPasswordAuthentication() {
			this.show();
			String username = "gouni";
			String password = "Progteam20201@";
			return new PasswordAuthentication(username, password.toCharArray());
		}
		void show() { int hostname = getRequestingPort(); System.out.println("Port Requesting :" + hostname); }
	}

	public static void main(String[] args) {

		try {
			ClassAuthenticator obj1 = new ClassAuthenticator();
			Authenticator.setDefault(new ClassAuthenticator());
			URL url = new URL("http://665dev02:9090/jenkins");

			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
			String line;
			System.out.println("Host using url.getHost ::" + url.getHost());
			obj1.getPasswordAuthentication();
			while ((line = in.readLine()) != null) {
				System.out.println(line);
			}
			in.close();
		} catch (MalformedURLException e) {
			System.out.println("Malformed URL: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("I/O Error: " + e.getMessage());
		}
	}
}
