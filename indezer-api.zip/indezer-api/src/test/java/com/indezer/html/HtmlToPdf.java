package com.indezer.html;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;

public class HtmlToPdf {
	
	
	public static void main(String[] args) throws IOException {
		try {
			generatePDFFromHTML("D:\\templates\\WB0TF1117\\dist\\demo.html");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void generatePDFFromHTML(String filename) throws DocumentException, IOException {
	    Document document = new Document();
	    PdfWriter writer = PdfWriter.getInstance(document,
	      new FileOutputStream("D:\\demo\\indezer\\pdf\\output\\pdf.pdf"));
	    document.open();
	    XMLWorkerHelper.getInstance().parseXHtml(writer, document,
	      new FileInputStream(filename));
	    document.close();
	}

}
