package com.indezer.pdf;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.fit.pdfdom.PDFDomTree;

public class PdfToHtml {

	public static void main(String[] args) {
		try {
			generateHTMLFromPDF("D:\\demo\\indezer\\pdf\\input\\demo.pdf");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void generateHTMLFromPDF(String filename) throws IOException, ParserConfigurationException {
		PDDocument pdf = PDDocument.load(new File(filename));
		Writer output = new PrintWriter("D:\\demo\\indezer\\pdf\\output\\pdf.html", "utf-8");
		new PDFDomTree().writeText(pdf, output);
		output.close();
	}

}
