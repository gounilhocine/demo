package com.indezer.jcraft;

import java.util.Properties;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class CopyFileToRemoteServer {
	public static void main(String args[]) {
		sftpsript("D:/demo/indezer/pdf/input/demo.pdf", "/tmp/demo.pdf");
	}

	public static void sftpsript(String input, String output) {

		try {
			String host = "31.207.36.63";
			String user = "root";
			String password = "zxM2RW7RYv";
			JSch jsch = new JSch();
			Session session = jsch.getSession(user, host, 22);
			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.setPassword(password);
			session.connect();
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();
			sftpChannel.put(input, output);
			sftpChannel.disconnect();
			session.disconnect();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
