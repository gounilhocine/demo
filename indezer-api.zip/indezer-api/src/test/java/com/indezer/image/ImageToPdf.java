package com.indezer.image;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;

public class ImageToPdf {

	public static void main(String[] args) {
		try {
			generatePDFFromImage("D:\\demo\\indezer\\pdf\\output\\pdf-1.pdf", "bnp");
		} catch (Exception e) {
		}
	}

	private static void generatePDFFromImage(String filename, String extension)
			throws DocumentException, MalformedURLException, IOException {
		Document document = new Document();
		String input = filename + "." + extension;
		String output = "D:\\demo\\indezer\\pdf\\output\\" + extension + ".pdf";
		FileOutputStream fos = new FileOutputStream(output);

		PdfWriter writer = PdfWriter.getInstance(document, fos);
		writer.open();
		document.open();
		document.add(Image.getInstance((new URL(input))));
		document.close();
		writer.close();
	}
}
