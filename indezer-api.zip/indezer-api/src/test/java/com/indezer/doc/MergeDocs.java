package com.indezer.doc;

	import java.io.File;
	import java.util.List;

	import javax.xml.bind.JAXBException;

	import org.docx4j.dml.CTBlip;
import org.docx4j.jaxb.XPathBinderAssociationIsPartialException;
import org.docx4j.openpackaging.exceptions.Docx4JException;
	import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
	import org.docx4j.openpackaging.parts.Part;
	import org.docx4j.openpackaging.parts.PartName;
	import org.docx4j.openpackaging.parts.WordprocessingML.ImageBmpPart;
	import org.docx4j.openpackaging.parts.WordprocessingML.ImageEpsPart;
	import org.docx4j.openpackaging.parts.WordprocessingML.ImageGifPart;
	import org.docx4j.openpackaging.parts.WordprocessingML.ImageJpegPart;
	import org.docx4j.openpackaging.parts.WordprocessingML.ImagePngPart;
	import org.docx4j.openpackaging.parts.WordprocessingML.ImageTiffPart;
	import org.docx4j.openpackaging.parts.relationships.RelationshipsPart;
	import org.docx4j.openpackaging.parts.relationships.RelationshipsPart.AddPartBehaviour;
	import org.docx4j.relationships.Relationship;

	public class MergeDocs {


	    public static void main(String[] args) throws Docx4JException, JAXBException {

	    	File first = new File("D:\\demo\\indezer\\mergedocs\\1.docx");
	        WordprocessingMLPackage firstDoc = WordprocessingMLPackage.load(first);
	       
	        
	        File second = new File("D:\\demo\\indezer\\mergedocs\\2.docx");
	        File third = new File("D:\\demo\\indezer\\mergedocs\\3.docx");
	        File fourth = new File("D:\\demo\\indezer\\mergedocs\\4.docx");   

	        appendDocFile(firstDoc, second);

	        appendDocFile(firstDoc, third);

	        appendDocFile(firstDoc, fourth);


//	        List<Object> blips = WordprocessingMLPackage.load(fourth).getMainDocumentPart().getJAXBNodesViaXPath("//a:blip", false);
//	        for(Object el : blips){
//	            try {
//
//	                   CTBlip blip = (CTBlip) el;
//	                   RelationshipsPart parts = WordprocessingMLPackage.load(fourth).getMainDocumentPart().getRelationshipsPart();
//	                   Relationship rel = parts.getRelationshipByID(blip.getEmbed());
//	                   Part part = parts.getPart(rel);
//	                   if(part instanceof ImagePngPart)
//	                        System.out.println(((ImagePngPart) part).getBytes()); 
//	                   if(part instanceof ImageJpegPart)
//	                        System.out.println(((ImageJpegPart) part).getBytes()); 
//	                    if(part instanceof ImageBmpPart)
//	                        System.out.println(((ImageBmpPart) part).getBytes()); 
//	                    if(part instanceof ImageGifPart)
//	                        System.out.println(((ImageGifPart) part).getBytes()); 
//	                    if(part instanceof ImageEpsPart)
//	                        System.out.println(((ImageEpsPart) part).getBytes()); 
//	                    if(part instanceof ImageTiffPart)
//	                        System.out.println(((ImageTiffPart) part).getBytes()); 
//	                    Relationship newrel = firstDoc.getMainDocumentPart().addTargetPart(part,AddPartBehaviour.RENAME_IF_NAME_EXISTS);
//	                    blip.setEmbed(newrel.getId());
//	                    firstDoc.getMainDocumentPart().addTargetPart(WordprocessingMLPackage.load(fourth).getParts().getParts().get(new PartName("/word/"+rel.getTarget())));
//	                } catch (Exception ex){
//	                        ex.printStackTrace();
//	                } }

	        File saved = new File("D:\\demo\\indezer\\mergedocs\\merge_3.dotx");
	        firstDoc.save(saved);}

		private static void appendDocFile(WordprocessingMLPackage firstDoc, File second)
				throws JAXBException, XPathBinderAssociationIsPartialException, Docx4JException {
			List body = WordprocessingMLPackage.load(second).getMainDocumentPart().getJAXBNodesViaXPath("//w:body", false);
	        for(Object b : body){
	            List filhos = ((org.docx4j.wml.Body)b).getContent();
	            for(Object k : filhos)
	                firstDoc.getMainDocumentPart().addObject(k);
	        }
		}

}
