package com.indezer.doc;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.usermodel.Paragraph;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

public class SplitDocs {

	public static void main(String[] args) {

		FileInputStream in = null;
		HWPFDocument doc = null;
		XWPFDocument docx = null;
		
		
		XWPFDocument us = null;
		XWPFDocument japan = null;
		FileOutputStream outUs = null;
		FileOutputStream outJapan = null;

		try {
			in = new FileInputStream("D:\\demo\\indezer\\splitdoc\\input.doc");
			doc = new HWPFDocument(in);

			us = new XWPFDocument();
			japan = new XWPFDocument();

			Range range = doc.getRange();

			for (int parIndex = 0; parIndex < range.numParagraphs(); parIndex++) {
				Paragraph paragraph = range.getParagraph(parIndex);

				String text = paragraph.text();
				System.out.println("***Paragraph" + parIndex + ": " + text);

				if ((parIndex >= 1) && (parIndex <= 2)) {
					createParagraphInAnotherDocument(us, text);
				} else if ((parIndex >= 2) && (parIndex <= 3)) {
					createParagraphInAnotherDocument(japan, text);
				}
			}

			outUs = new FileOutputStream("D:\\demo\\indezer\\splitdoc\\1.docx");
			outJapan = new FileOutputStream("D:\\demo\\indezer\\splitdoc\\2.docx");
			us.write(outUs);
			japan.write(outJapan);

			in.close();
			outUs.close();
			outJapan.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static void createParagraphInAnotherDocument(XWPFDocument document, String text) {
		XWPFParagraph newPar = document.createParagraph();
		newPar.createRun().setText(text, 0);
	}

}